---
name: forge-build-from-zero
description: Take a person from an EMPTY ExternalSoul workspace to a complex, installed app using only a Personal Access Token — the Forge's workbench over the PAT API (no repo access, no MCP needed), the full esoul-sdk surface (events, tools, roles and attribute-scoped access, per-app database tables with rules and indexes, ops and streaming routes, background tasks, realtime audiences, machine control over `computer()`, charts, bindings, files, connections), and the CLOSED DEBUGGING LOOP — the box's problem journal that leads every tool answer, the board's Issues tab, `resolve_problem`, parking on issues, VIEW AS personas, headless drives — plus every lesson learned building Stream Lab and the shop with the owner. Triggers on "build me an app in the forge", "I have a PAT, make an app on my workspace", "debug my forge app", "why does the assistant call tools that don't exist", "the preview says stopped / OOM". Read this BEFORE forge-app-builder / forge-realtime-apps when the session has a PAT rather than MCP; it references both.
---

# From an empty workspace to a complex app, with a PAT

You are the only model in this loop. The person has an ExternalSoul workspace and a Personal
Access Token; you have a shell. Everything below is done with `curl` against one endpoint and
a handful of files you keep locally. Nothing is installed until a person has read the diff.

Read in this order: this file (the operating manual) → `reference/pat-and-tools.md` (the exact
HTTP and every tool) → `reference/lessons.md` (what building real apps with the owner taught —
read ALL of it before your first write) → `reference/sdk-docs.md` (the esoul-sdk documentation,
verbatim; the API you write against) → `reference/stream-lab-tour.md` (the reference app that
uses the breadth of the SDK). `forge-app-builder` and `forge-realtime-apps` (separate skills)
cover the same loop over MCP; their design rules apply here unchanged.

## 0. The five rules that outrank everything

1. **Read the ⚠ paragraph first.** Every write/edit/look/test/check answer begins with the
   problems the running app hit since your last call — an op that threw (with its args and
   stack head), a page console error, a task that failed, a compile error, a screenshot defect —
   each with an id like `p_3f2a9c1d`. Fix those before continuing; then
   `resolve_problem {id, note}` with one honest line (the person sees it turn green in the
   board's Issues tab). A fix that did not hold reopens the row ("↩ came back"). Never resolve
   what you did not fix.
2. **Never break the box a person is using.** The workbench is single-tenant and it is their
   live surface. A drive that writes a non-compiling file, stops the sandbox, or reboots the
   preview wedges what they are looking at (it happened: three collisions in one minute, a
   "workbench stopped" card, minutes of "Booting"). Do destructive drives on a separate app,
   or when they say the board is idle, and SAY before any reboot.
3. **`check_app` is the bar, not your local tests.** Local jest runs with `isolatedModules` and
   proves nothing about types; the box's `check_app` runs the sync (which regenerates the app's
   `.esoul/db.d.ts` and migration), the app's tests, the platform's boundary suites and `tsc`.
   Three green is "ready"; a `skipped` gate is not a pass.
4. **Drive it, then believe it.** A screenshot proves layout, not health. Every UI change gets a
   headless drive that collects console errors, throws and failed app calls
   (`reference/page-check.mjs`), as the company AND as a customer persona. "It renders" is not
   "it works".
5. **Say what is on screen, never where to click.** When a tool's job is to show something,
   the APP shows it (switches page, scrolls, highlights) and your answer is one line. A picture
   reaches a chat only as a URL — bytes printed as text is a defect you must never ship.

## 1. Getting to a board

```
export ESOUL_PAT=esoul_pat_…            # the person's token (read+write)
export ESOUL_BASE=https://externalsoul.com
```
- `GET /api/v1/workspaces` → pick the workspace (by NAME the person uses, then its id).
- `GET /api/v1/workspaces/<id>/apps` → is there an app with `applicationType: "forge"`? Its
  `nodeId` is `ESOUL_BOARD`, its `instanceName` (usually `Forge`) is the tool suffix.
- None? `POST /api/v1/workspaces/<id>/apps {applicationType:"forge", instanceName:"Forge"}`
  with an `Idempotency-Key`. The person must connect GitHub in Account settings → GitHub and
  bind the ExternalSoul repository on the board once; a board without it refuses to open a
  workbench and says so — relay that, never work around it.
- Save `reference/wb.sh` locally; every workbench tool is `bash wb.sh <tool> '<json>'`.

## 2. The loop, as it actually runs

```
wb.sh open_workbench '{"pluginId":"my-app","name":"My App","description":"…","icon":"Boxes"}'
wb.sh read_app_file  '{"pluginId":"my-app","path":"app.tsx"}'       # read the scaffold first
# edit LOCALLY in ./my-app/, run its jest locally for speed, then:
wb.sh write_app_file '{"pluginId":"my-app","path":"server.ts","content":"…"}'   # ⚠ + Preview: line
wb.sh preview_app    '{"pluginId":"my-app"}'                                     # once; then hot reload
node reference/page-check.mjs "<preview url>" out.png steps.json                 # console clean?
wb.sh look_at_app    '{"pluginId":"my-app","viewer":"visitor-a?grant=customer&customer=143"}'
wb.sh test_app       '{"pluginId":"my-app"}'      →   wb.sh check_app '{"pluginId":"my-app"}'
wb.sh app_problems   '{"pluginId":"my-app"}'      →   wb.sh resolve_problem '{"pluginId":…,"id":"p_…","note":"…"}'
wb.sh ship_app       '{"pluginId":"my-app","message":"…"}'   # or the app's own repo: Push on the board
```
`open_workbench` merges the platform's `main` into the box: a box behind main lacks new host
functions ("`listAppRoles is not a function`" is that, not your bug) — open again. The preview's
BOOT SCRIPT comes from the platform, not the box: a platform change to the boot (e.g. the
dev-log watcher) reaches a box only after `close_workbench` → `open_workbench` → `preview_app`.

Keep the app's source in a local folder that mirrors the box (`app.tsx`, `server.ts`, `ops.ts`,
`plugin.json`, `ui/*.tsx`, `*.test.ts`); write files one at a time and read the ⚠ line of each
answer. Local jest: `npx jest --rootDir <platform clone> --roots ./my-app` is only available
when you have a clone; with a PAT alone, `test_app` on the box is your unit runner (seconds).

## 3. Designing the app (the SDK's breadth — details in `reference/sdk-docs.md`)

- **Manifest first** (`plugin.json`): `roles` (+ typed `attributes` a grant may carry), per-op
  `access` (public / account / role list), `db` tables with `scope`, `fields`, `indexes`
  (every field a rule or a `where` names MUST be indexed — the compiler refuses otherwise),
  `unique`, and `rules` whose principals may be scoped `{ role, where: { field: "viewer.attr" } }`;
  `tasks`, `routes` (`access: "token"` for machines), `channels` with audiences, `uses`/`provides`.
- **Ops declared once**: `defineOps` (zod) → `handleOp` in `server.ts` → `opTool` in `app.tsx`
  with a `say` that words the result for a person. The op owns the timeline (`ctx.emit`); a tool
  never dispatches the app's event itself. An op reads its bindings, never folds its history.
- **Data**: ask the database the person's question (a `where` over an indexed field, cursor
  paging), never filter in the browser; `db.$transaction` for "one breath or neither";
  compensate what a transaction cannot hold; a json column answers about one row, sales are a
  table.
- **People**: `viewer.kind/role/attrs`; `isCompany(ctx)`-style helpers; a customer sees only rows
  the rule scopes to `viewer.customer`; per-person state (a timeline) is `scope: "user"`.
- **Machines**: `computer(ctx, machineNodeId)` — status / run / runToEnd / readFile / fetchJson /
  python; the machine keeps 8 000 chars of output, so compute THERE and print little; a
  `pending_approval` is a wait, not a failure. Remember the machine in a one-row table so no
  caller has to know a nodeId.
- **Live**: tasks on Inngest (never `void` a promise inside a step; descriptions ≤ 255 chars),
  `notify` on audience channels, `usePluginRealtime` in the UI; a player is a clock over a
  record — nothing asks the server per tick.
- **Pictures**: `chartSvg` for the screen and `renderChartImage` for a URL; in a box there is
  no blob store, so the URL is null — the chart lives on a page of the app, the answer says so.

## 4. Test, drive, and prove — every time

`test_app` after any change to schema/events/ops; a headless drive after any UI change (steps:
select, keys, click, say); `look_at_app` as each persona the app has; `check_app` before you
say "ready". Prove access: the customer persona MUST fail to see another customer's rows —
write that drive so it goes red when it leaks. Prove the machine path with the fake machine in
tests (`esoul-sdk/testing` gives `runOp`, `memoryDb`, `fakeViewer`).

## 5. When the person reports something

Do not ask them to describe it: `app_problems` lists the box's journal AND the board's rows
(open first, with ids). A screenshot from them usually matches a row already there. Fix,
drive, `resolve_problem` with the line they will read. If a row's message is empty or
misleading, that is a second bug — the app must always say WHY (see lessons: "the bridge did
not come up: " with nothing after the colon).

## 6. Shipping

Two paths: `ship_app` opens a pull request on the platform repo (the review boundary), or the
board's Push exports the app to its OWN GitHub repo and the owner installs it by link
(Settings → Apps). Push's commit message carries the resolutions since the last push — write
resolution lines as you would want to read them in a changelog. After a merge that touches a
task, the platform's Inngest sync must be confirmed (`PUT /api/inngest`); if you cannot, say so.

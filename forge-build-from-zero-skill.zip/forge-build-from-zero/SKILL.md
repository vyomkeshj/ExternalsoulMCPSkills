---
name: forge-build-from-zero
description: Take a person from an EMPTY ExternalSoul workspace to a complex, installed app using only a Personal Access Token — the Forge's workbench driven with the `esoul` Python SDK (`esoul.forge` / the `esoul-forge` CLI; raw HTTP as the fallback; no repo access, no MCP needed), the full esoul-sdk surface (events, tools, roles and attribute-scoped access, per-app database tables with rules and indexes, ops and streaming routes, background tasks, realtime audiences, machine control over `computer()`, charts, bindings, files, connections), and the CLOSED DEBUGGING LOOP — the box's problem journal that leads every tool answer, the board's Issues tab, `resolve_problem`, parking on issues, VIEW AS personas, headless drives — plus every lesson learned building Stream Lab and the shop with the owner. Triggers on "build me an app in the forge", "I have a PAT, make an app on my workspace", "debug my forge app", "why does the assistant call tools that don't exist", "the preview says stopped / OOM". Read this BEFORE forge-app-builder / forge-realtime-apps when the session has a PAT rather than MCP; it references both.
---

# From an empty workspace to a complex app, with a PAT

You are the only model in this loop. The person has an ExternalSoul workspace and a Personal
Access Token; you have a shell. Everything below is done with the `esoul` Python package
(`esoul.forge`, or its `esoul-forge` CLI) against the person's Forge board, and a folder of files
you keep locally. Nothing is installed until a person has read the diff.

Read in this order: this file (the operating manual) → `reference/pat-and-tools.md` (the
`esoul.forge` surface in full, the CLI, and the same loop as raw HTTP for a machine without Python) → `reference/lessons.md` (what building real apps with the owner taught —
read ALL of it before your first write) → `reference/sdk-docs.md` (the esoul-sdk documentation,
verbatim; how to write against it) → `reference/sdk-api.md` (EVERY export of `esoul-sdk`,
`esoul-sdk/server`, `esoul-sdk/react` and `esoul-sdk/testing` with its signature and doc,
generated from the package source — look a name up here before you guess its arguments) →
`reference/stream-lab-tour.md` (the reference app that uses the breadth of the SDK). Inside a
workbench the SDK's source itself is readable: `wb.search(name, scope="sdk")` then
`wb.read_platform(path, start=, lines=)`. `forge-app-builder` and `forge-realtime-apps` (separate skills)
cover the same loop over MCP; their design rules apply here unchanged.

## 0. The five rules that outrank everything

1. **Read the ⚠ paragraph first.** Every write/edit/look/test/check answer begins with the
   problems the running app hit since your last call — an op that threw (with its args and
   stack head), a page console error, a task that failed, a compile error, a screenshot defect —
   each with an id like `p_3f2a9c1d`. Fix those before continuing; then
   `wb.resolve(id, note)` (the board tool `resolve_problem`) with one honest line (the person sees it turn green in the
   board's Issues tab). A fix that did not hold reopens the row ("↩ came back"). Never resolve
   what you did not fix.
2. **Never break the box a person is using.** The workbench is single-tenant and it is their
   live surface. A drive that writes a non-compiling file, stops the sandbox, or reboots the
   preview wedges what they are looking at (it happened: three collisions in one minute, a
   "workbench stopped" card, minutes of "Booting"). Do destructive drives on a separate app,
   or when they say the board is idle, and SAY before any reboot.
3. **`check_app` is the bar, not your local tests.** Local jest runs with `isolatedModules` and
   proves nothing about types; the box's `check_app` runs the sync (which regenerates the app's
   `.esoul/db.d.ts` and migration), the app's tests, the platform's boundary suites and `tsc`.
   Three green is "ready"; a `skipped` gate is not a pass.
4. **Drive it, then believe it.** A screenshot proves layout, not health. Every UI change gets a
   drive that collects console errors, throws and failed app calls (`wb.drive`, on the
   platform's browser — nothing to install), as the company AND as a customer persona. "It renders" is not
   "it works".
5. **Say what is on screen, never where to click.** When a tool's job is to show something,
   the APP shows it (switches page, scrolls, highlights) and your answer is one line. A picture
   reaches a chat only as a URL — bytes printed as text is a defect you must never ship.

## 1. Getting to a board

```bash
pip install -U "esoul>=0.18"          # esoul.forge (orient/search/read_window/run/expect) + the esoul-forge CLI
export ESOUL_TOKEN=esoul_pat_…        # the WORKSPACE OWNER's token, read+write
```
```python
from esoul import Esoul
forge = Esoul().forge(workspace="Sparkling Water")   # the workspace by the NAME the person uses
board = forge.board()                                 # never created implicitly
# none yet?  forge.board(create=True) — then the person binds GitHub to it once (Account settings → GitHub)
wb = forge.workbench("my-app", name="My App", icon="Boxes")   # opens: merges the platform's main, scaffolds once
```
A token that is not the workspace owner's is refused (`not_workspace_owner`) — the workbench
spends the owner's GitHub connection and pushes under their name. A read-only token may only
`files/read/journal/issues/look/status`. No `esoul` on the machine? `reference/pat-and-tools.md`
has the same loop as raw HTTP.

## 2. The loop, as it actually runs

Keep the app's source in a local folder that mirrors the box (`app.tsx`, `server.ts`, `ops.ts`,
`plugin.json`, `ui/*.tsx`, `*.test.ts`) — pull the scaffold down first with `wb.files()` +
`wb.read()`. On an app that already exists and that you have not read this conversation, start
with `wb.orient()` (manifest outline, files, README, checkpoints, open issues), find the parts
the ask touches with `wb.search(...)`, and read those with `wb.read_window(path, start=, lines=)`
— the same three verbs exist as board tools (`orient_app`, `search_app_files`, `read_app_file`)
and over MCP (`forge_orient`, `forge_search`, `forge_read`). Then:

```python
r = wb.sync("./my-app")                  # changed files only; ONE checkpoint, ONE health probe, the new problems
if r.preview and r.preview.down: print(r.preview.detail)      # the compiler's own lines — fix first
for p in r.problems: print(p.id, p.source, p.where, p.message, p.detail)

wb.preview()                             # once; after that every sync hot-reloads
d = wb.drive([{"select": ["select[aria-label='Customer']", "143"]}, {"wait": 3000},
              {"say": "section[aria-label='Playback']"}], viewer="visitor-a?grant=customer&customer=143")
assert d.ok, d.problems                  # console errors, throws, failed app calls while it was USED
look = wb.look(viewer="owner"); look.shots["phone-light"].download("./shots")   # then OPEN the pictures
wb.op("find-faults", {"customer": 204}, viewer="owner")      # the running app's own door
t = wb.test()                            # seconds; after any change to schema/events/ops
c = wb.check(); assert c.ok, c.failing   # the whole bar; `skipped` is not a pass
for i in wb.issues(open_only=True): ...  # fix, then: wb.resolve(i.id, "one honest line")
wb.pull_generated("./my-app")            # the box's .esoul/db.d.ts after check, so local types match
```
The same from a shell (`ESOUL_WORKSPACE`, `ESOUL_PLUGIN` set): `esoul-forge sync ./my-app`,
`esoul-forge drive steps.json --viewer …`, `esoul-forge check`, `esoul-forge issues --open`,
`esoul-forge resolve p_… "…"`, `esoul-forge watch` — each exits non-zero when the answer is a failure.

What the SDK enforces so you don't have to remember it:
- `wb.drive` with clicks/keys/select and `wb.close()` answer `board_in_use` while a person's board
  polled the preview in the last 30 s. Don't pass `force=True` without their leave. `wb.status()`
  tells you `board_open` BEFORE you try.
- A second `open`/`check`/`ship` on the same box answers `busy` — the board's chat may be running
  one. Wait; don't retry in a loop.
- `sync` never sends `.esoul/*`; `prune=True` only deletes files a sync wrote.
- A tool name the app does not mint is healed when it is a near miss — `ToolRun.healed_from`
  says so; use the real name next time.

`wb.open()` merges the platform's `main` into the box: a box behind main lacks new host functions
("`listAppRoles is not a function`" is that, not your bug). The preview's BOOT SCRIPT is the
platform's: a boot change reaches a box only after `wb.close()` → `forge.workbench(...)` →
`wb.preview()` — and that is a reboot, which you announce first.

## 3. Designing the app (the SDK's breadth — details in `reference/sdk-docs.md`)

- **Manifest first** (`plugin.json`): `roles` (+ typed `attributes` a grant may carry), per-op
  `access` (public / account / role list), `db` tables with `scope`, `fields`, `indexes`
  (every field a rule or a `where` names MUST be indexed — the compiler refuses otherwise),
  `unique`, and `rules` whose principals may be scoped `{ role, where: { field: "viewer.attr" } }`;
  `tasks`, `routes` (`access: "token"` for machines), `channels` with audiences, `uses`/`provides`.
- **Ops declared once**: `defineOps` (zod) → `handleOp` in `server.ts` → `opTool` in `app.tsx`
  with a `say` that words the result for a person. The op owns the timeline (`ctx.emit`); a tool
  never dispatches the app's event itself. An op reads its bindings, never folds its history.
- **Data**: ask the database the person's question (a `where` over an indexed field, cursor
  paging), never filter in the browser; `db.$transaction` for "one breath or neither";
  compensate what a transaction cannot hold; a json column answers about one row, sales are a
  table.
- **People**: `viewer.kind/role/attrs`; `isCompany(ctx)`-style helpers; a customer sees only rows
  the rule scopes to `viewer.customer`; per-person state (a timeline) is `scope: "user"`.
- **Machines**: `computer(ctx, machineNodeId)` — status / run / runToEnd / readFile / fetchJson /
  python; the machine keeps 8 000 chars of output, so compute THERE and print little; a
  `pending_approval` is a wait, not a failure. Remember the machine in a one-row table so no
  caller has to know a nodeId.
- **Live**: tasks on Inngest (never `void` a promise inside a step; descriptions ≤ 255 chars),
  `notify` on audience channels, `usePluginRealtime` in the UI; a player is a clock over a
  record — nothing asks the server per tick.
- **Pictures**: `chartSvg` for the screen and `renderChartImage` for a URL; in a box there is
  no blob store, so the URL is null — the chart lives on a page of the app, the answer says so.

## 4. Test, drive, and prove — every time

`wb.test()` after any change to schema/events/ops; `wb.drive(steps, viewer=…)` after any UI
change (steps: select, keys, click, wait, say); `wb.look(viewer=…)` as each persona the app has;
`wb.check()` before you say "ready". Prove access: the customer persona MUST fail to see another customer's rows —
write that drive so it goes red when it leaks. Prove the machine path with the fake machine in
tests (`esoul-sdk/testing` gives `runOp`, `memoryDb`, `fakeViewer`).

## 5. When the person reports something

Do not ask them to describe it: `wb.issues()` lists the board's rows (open first, with ids,
outliving restarts) and `wb.journal()` what the box holds now; `wb.watch_issues()` streams new
entries while you work (a round the box could not answer arrives as an `IssueStreamGap` — the app
may not compile). A screenshot from them usually matches a row already there. Fix,
drive, `resolve_problem` with the line they will read. If a row's message is empty or
misleading, that is a second bug — the app must always say WHY (see lessons: "the bridge did
not come up: " with nothing after the colon).

## 6. Shipping

Two paths: `wb.ship(message)` opens a pull request on the platform repo (the review boundary),
or the board's Push exports the app to its OWN GitHub repo and the owner installs it by link
(Settings → Apps). Push's commit message carries the resolutions since the last push — write
resolution lines as you would want to read them in a changelog. After a merge that touches a
task, the platform's Inngest sync must be confirmed (`PUT /api/inngest`); if you cannot, say so.

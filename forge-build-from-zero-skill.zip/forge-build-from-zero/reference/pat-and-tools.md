# The Forge from a PAT: `esoul.forge`, `esoul-forge`, and the raw HTTP beneath them

## `esoul.forge` (esoul ≥ 0.18) — use this

```python
from esoul import Esoul, ForgeError
from esoul.exceptions import APIError        # every refusal: .code, .status, str(e) is the sentence

c = Esoul()                                   # ESOUL_TOKEN (the workspace OWNER's token), ESOUL_BASE_URL optional
forge = c.forge(workspace="Sparkling Water")  # or workspace_id=…; project= when two share a name
board = forge.board(create=False, name=None)  # Board(node_id, instance_name, workspace_id)
wb = forge.workbench("my-app", name="My App", description="…", icon="Boxes")   # open=True by default
```

| call | returns | notes |
|---|---|---|
| `wb.status()` | `WorkbenchStatus(branch, head, preview_url, preview_origin, preview_node_id, preview_alive, frame_age_ms, board_open, busy)` | ask before anything destructive |
| `wb.orient()` | `Orientation(manifest{ok,name,applicationType,declares{ops,tools,routes,tasks,tables,roles…}}, files, readme, checkpoints, head, preview_alive, preview_url, open_issues, issues)`; `.words()` | **first call on an app you have not read** |
| `wb.files()` · `wb.read(path, start=, lines=)` · `wb.read_window(path, start=, lines=)` | `[{path, bytes}]` · `str` · `FileWindow(path, content, start, end, total)` | windows are 1-based; the logs `.esoul/logs/{tests,gates-tests,gates-types,run}.log` are files too |
| `wb.search(query, regex=False, glob=None, scope="app"|"sdk", limit=200)` | `SearchResult(hits[SearchHit(path, line, text)], truncated)` | find before you read; `scope="sdk"` = the SDK's source and docs |
| `wb.read_platform(path, start=, lines=)` | `FileWindow` | only `packages/esoul-sdk/src`, `packages/esoul-sdk/docs`, `src/lib/plugin-sdk-host`, `src/plugins/_fixtures` |
| `wb.history(limit=20)` · `wb.diff(sha=None, start=, end=)` | `[Checkpoint(sha, at, summary)]` · `Diff(range, diff, files, truncated)` | every write is a checkpoint; `diff()` alone = working tree vs head |
| `wb.run(cmd, timeout=120)` | `RunResult(code, output, log, took_ms, timed_out, problems)`; `.ok` | one shell command in the app's dir on the box; refused (`busy`) while check/open/ship run |
| `wb.sync(folder, prune=False, all_files=False)` | `SyncResult(written, deleted, unchanged, before, sha, preview, problems)` | manifest `.esoul-sync.json`; batches of ≤3 MB; never `.esoul/*` |
| `wb.write(path, text, expect=)` · `wb.edit(path, [(find, replace)], expect=)` · `wb.delete(path)` · `wb.restore(sha)` | `SyncResult` | one file at a time (each its own probe); `expect=<sha you read at>` → `StaleBaseError(head)` if the box moved (also on `sync`) |
| `wb.pull_generated(folder)` | `[paths]` | `.esoul/db.d.ts`, migration, rules — after `check` |
| `wb.preview(wait=True)` | `{ok, url, path, tookMs}` | |
| `wb.look(viewer=, intent=, critique=False)` | `LookResult(text, errors, clips, shots{label: Shot}, findings, critique, words, problems)` | `Shot.download(dir)`; open the images |
| `wb.drive(steps, viewer=, force=False)` | `DriveResult(ok, problems, said{selector: text}, ran, shot, stopped_at, took_ms, journal)` | steps: `select [sel, value]`, `keys [sel, key, n]`, `click sel`, `wait ms`, `say sel`; ≤40 |
| `wb.op(name, args, viewer=)` · `wb.route(name, query, viewer=)` · `wb.kick(task, data)` | the app's own answer | straight at the preview's public URL; an op's refusal is a `ForgeError` with `payload` |
| `wb.tool(name, args)` · `wb.state()` | `ToolRun(ok, tool, result, error, events, tools, healed_from, problems)` · the fold | |
| `wb.test()` · `wb.check()` | `TestRun` · `CheckResult(gates, problems)` with `.ok` / `.failing` | `check` takes minutes; `skipped` is not a pass |
| `wb.journal()` · `wb.warnings()` · `wb.issues(open_only=)` | `[Problem]` · `[Problem]` · `[Issue]` | journal = the box now; issues = the board, open first |
| `wb.resolve(id, note)` | — | note: one line, ≤140 |
| `wb.watch_issues(interval=5, timeout=None)` | iterator of `Problem` \| `IssueStreamGap` | reads the preview's journal door directly |
| `wb.commit(msg)` · `wb.ship(msg, force=False, wait=True)` · `wb.close(force=False)` | dicts | `close`/clicking `drive` → `board_in_use` while the board is open |

**Async** (`esoul` ≥ 0.18): `forge = await AsyncEsoul().forge(workspace=…)`, `wb = await
forge.workbench(id)` — every method above as a coroutine, `async for item in wb.watch_issues()`,
`async with wb:` closes its connection pool. Use it for several things at once: `asyncio.gather`
of `wb.op(..., viewer=v)` for each persona (the access proof, simultaneous), a watcher task
streaming problems while you sync and drive, checks across several apps. Not for two long
actions on one box — that answers `busy`.

Codes you will meet: `not_workspace_owner`, `read_only_token`, `workspace_access_denied`,
`board_in_use` (409), `busy` (409), `invalid_request` (a bad path, a generated file, a step the
grammar refuses — the sentence says which), `workbench_failed` (500 — read `wb.journal()`).
`ForgeSchemaError` means the server is newer than your `esoul`: upgrade.

## `esoul-forge` — the same loop in a shell

Verbs: `open status orient search read run diff history sync preview look drive tool op test check issues resolve watch ship close` — `esoul-forge -p <app> orient`, `… search pluginDb --scope sdk`, `… read server.ts --start 40 --lines 30`, `… run 'npx jest server.test.ts'`, `… diff <sha>`.

```bash
export ESOUL_TOKEN=esoul_pat_… ESOUL_WORKSPACE="Sparkling Water" ESOUL_PLUGIN=my-app
esoul-forge open --name "My App" --icon Boxes [--create-board]
esoul-forge status | sync ./my-app [--prune] | preview | look [--viewer …] [--save ./shots]
esoul-forge drive steps.json [--viewer …] [--force] | tool add_note '{"text":"milk"}' | op find-faults '{"customer":204}' [--viewer …]
esoul-forge test | check | issues [--open] | resolve p_… "what you did" | watch | ship [--message …] | close [--force]
```
Non-zero exit: `sync` with problems or a preview DOWN, a drive that was not clean, `test`/`check`
not green, any refusal (2, with `[code]`). `--json` prints the dataclasses.

---

## Underneath: the raw HTTP (a machine without Python)

### The board's tools over `/api/v1/app-tools`

```
POST {BASE}/api/v1/app-tools
Authorization: Bearer {PAT}
Content-Type: application/json
Idempotency-Key: <unique per call>
{ "appId": "<Forge board nodeId>", "toolName": "<tool>_<board instance name>", "arguments": { … } }
→ 200 { "result": <string | object> }
```

The `result` is the SAME text the chat model gets — including the ⚠ problem paragraph at the
top of every changing/observing answer. `look_at_app` returns `{ text, imageUrls }`; download the
URLs and open them. A wrong tool name is a 404 carrying the callable names.

### `wb.sh` (keep this beside you)

```bash
#!/usr/bin/env bash
# wb.sh <tool> '<json args>'   e.g. wb.sh open_workbench '{"pluginId":"sticky-notes"}'
set -uo pipefail
PAT="${ESOUL_PAT:?set ESOUL_PAT}"; BOARD="${ESOUL_BOARD:?set ESOUL_BOARD}"; BASE="${ESOUL_BASE:-https://externalsoul.com}"
TOOL="${1:?tool}"; ARGS="${2:-{\}}"
python3 -c "import json,sys; print(json.dumps({'appId':'$BOARD','toolName':'${TOOL}_'+'${ESOUL_BOARD_NAME:-Forge}','arguments':json.loads(sys.argv[1])}))" "$ARGS" > /tmp/wb-req.json
curl -sS -X POST -H "Authorization: Bearer $PAT" -H "Content-Type: application/json" \
  -H "Idempotency-Key: wb-$$-$(date +%s%N)" --data-binary @/tmp/wb-req.json \
  "$BASE/api/v1/app-tools" --max-time 800 | python3 -c "
import sys,json
try: d=json.load(sys.stdin)
except Exception: print('non-JSON reply'); raise SystemExit(1)
r=d.get('result', d)
print(r if isinstance(r,str) else json.dumps(r,indent=1)[:6000])"
```
A "non-JSON reply" is a 502/504 from the platform (the box's shell did not answer in time —
it is compiling, wedged, or restarting): wait, re-read `app_problems`, do not repeat blindly.
Write one file from a local folder: `wb.sh write_app_file "$(python3 -c 'import json,sys; print(json.dumps({"pluginId":"my-app","path":sys.argv[1],"content":open(sys.argv[2]).read()}))' server.ts ./my-app/server.ts)"`.

### Finding or making the board

- `GET /api/v1/workspaces` (Bearer) → `[{ id, name, … }]`.
- `GET /api/v1/workspaces/{id}/apps` → `{ apps: [{ nodeId, applicationType, instanceName }] }` —
  the board is `applicationType: "forge"`; the suffix is its `instanceName` with spaces as `_`.
- `POST /api/v1/workspaces/{id}/apps` `{ applicationType: "forge", instanceName: "Forge" }` +
  `Idempotency-Key` → `{ nodeId }`. The person binds GitHub to it once (Account settings).
- With Python, don't do this by hand: `Esoul().forge(workspace="…").board(create=True)` (above).

### The typed route `esoul.forge` uses

`POST {BASE}/api/v1/forge/workbench/<action>` with `Authorization: Bearer <owner PAT>`,
`Idempotency-Key`, body `{nodeId: <board>, pluginId, …}`. Actions: `start`, `scaffold`, `status`,
`files`, `read`, `write`, `write-many {files:[{path,content}], deletes?}`, `edit`, `delete`,
`restore`, `preview {background:false}`, `look {viewer?, intent?, critique?}`, `drive {steps,
viewer?, force?}`, `call-tool {tool, args}`, `read-state`, `test`, `gates`, `problems {clear?}`,
`resolve {id, note}`, `commit`, `ship {background:false}`, `stop {force?}`. JSON answers (the
journal as `problems: {problems:[…], total, seq}`); refusals `{error:{code, message}}`; header
`x-esoul-forge-schema: 1`.

### The board tools (the suffix `_<Board>` is implied)

| tool | args | what to read in the answer |
|---|---|---|
| `open_workbench` | `pluginId, name?, description?, icon?` | branch; "platform was N commits behind and has been updated"; the files; the PARK hint |
| `orient_app` | `pluginId` | manifest outline, files, README head, checkpoints, preview, open issues — FIRST on an app you have not read |
| `list_app_files` / `read_app_file` | `pluginId[, path, from, lines]` | a window says `lines a–b of N`; logs live at `.esoul/logs/*.log` |
| `search_app_files` | `pluginId, query, regex?, glob?, scope: app|sdk, limit?` | `path:line: text`, 200 lines cap |
| `read_platform_file` | `pluginId, path, from?, lines?` | the SDK's src + docs, the box's stand-ins, the fixtures; nothing else |
| `app_history` / `diff_app` | `pluginId[, limit]` / `pluginId, sha? \| from?, to?` | checkpoints; what one changed |
| `run_in_app` | `pluginId, cmd, timeoutMs?` | one shell command in the app's dir (≤120 s); tail + `.esoul/logs/run.log`; `busy` while a long action holds the box |
| `write_app_file` | `pluginId, path, content` | ⚠ paragraph; `Preview: live (…)` or `Preview: DOWN — <dev server's own error>`; over the PAT route `expect:<sha>` refuses a stale base (409 `stale_base`) |
| `edit_app_file` | `pluginId, path, edits:[{find, replace}]` | each `find` must match exactly once; nothing half-applies |
| `delete_app_file` / `restore_app {sha}` | | ⚠ + Preview line |
| `preview_app` | `pluginId` | "Starting … a minute or two"; the URL is on the board; hot reload after |
| `look_at_app` | `pluginId, intent?, viewer?, critique?` | ⚠ (incl. screenshot rows with ids) + text + imageUrls; `critique:true` adds confirmed findings with evidence |
| `call_app_tool` | `pluginId, tool, args` | the tool's `say`; events applied to the preview; a near-miss name is healed and named |
| `read_app_state` | `pluginId` | the preview's fold (board tab → store → tool-call fold, in that order of truth) |
| `test_app` / `check_app` | `pluginId` | tests only / the whole bar: sync, tests, platform suites, tsc; `skipped` ≠ pass; each names the log with its WHOLE output |
| `app_problems` | `pluginId, clear?` | the box's journal + warnings + THE BOARD'S ROWS (open first, ids) |
| `resolve_problem` | `pluginId, id, note(≤140)` | "Resolved p_…: note" — the row turns green; recurrence reopens it |
| `commit_app` / `ship_app` / `merge_app` / `close_workbench` | | as named; `ship` refuses on a red gate unless `force:true` |

Personas for `viewer` (look) and `?viewer=` on the preview URL: `owner`, `member`,
`member-readonly`, `visitor-a`, `visitor-b`, `anonymous`, `agent`, `role:<composed role>`, and
a GRANT with attributes: `visitor-a?grant=customer&customer=143` (URL-encode it in a query:
`visitor-a%3Fgrant%3Dcustomer%26customer%3D143`).

## The preview's own doors (curl them directly — the fastest drive there is)

`PREVIEW = https://sb-<id>.vercel.run` (from `preview_app` / the board). The app's node in the
box is `preview-<applicationType>` (e.g. `preview-plugin_stream_lab`).

```
POST {PREVIEW}/internal/plugin-preview/op/<pluginId>/<op>      {"nodeId":"preview-…","args":{…}}   [?viewer=…]
GET  {PREVIEW}/internal/plugin-preview/route/<pluginId>/<route>?nodeId=preview-…[&viewer=…]
POST {PREVIEW}/internal/plugin-preview/kick                     {"name":"<applicationType>/<task>","data":{"workspaceId":"w","nodeId":"preview-…",…}}
GET  {PREVIEW}/internal/plugin-preview/problems?since=0&warnings=1   → the box's journal as JSON (survives a broken app)
GET  {PREVIEW}/internal/plugin-preview/store?nodeId=preview-…&state=1 → the fold
```
An op refusal comes back as `{ok:false, error, code}`; an access refusal as 401/403 with a
code. A 500 HTML page means the app does not compile — read `problems` for the `dev` row.

## The headless drive (`reference/page-check.mjs`)

`node page-check.mjs "<preview url>" out.png steps.json` — needs Node and `puppeteer-core`
with a Chrome for Testing under `~/.cache/puppeteer` (`npx puppeteer browsers install chrome`).
Steps: `{"select":[sel,value]}`, `{"keys":[sel,"ArrowRight",7]}`, `{"click":sel}`,
`{"wait":ms}`, `{"say":sel}` (prints the element's text). Exit 1 on any console error, throw,
or failed/4xx app call — every one printed. Run it as the company and as each customer
persona. Without a browser, drive with the preview's doors above and read `problems`.

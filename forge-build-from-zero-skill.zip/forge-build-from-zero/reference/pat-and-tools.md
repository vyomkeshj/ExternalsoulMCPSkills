# The PAT path: one endpoint, every workbench tool

## The call

```
POST {BASE}/api/v1/app-tools
Authorization: Bearer {PAT}
Content-Type: application/json
Idempotency-Key: <unique per call>
{ "appId": "<Forge board nodeId>", "toolName": "<tool>_<board instance name>", "arguments": { … } }
→ 200 { "result": <string | object> }
```

The `result` is the SAME text the chat model gets — including the ⚠ problem paragraph at the
top of every changing/observing answer. `look_at_app` returns `{ text, imageUrls }`; download the
URLs and open them. A wrong tool name is a 404 carrying the callable names.

### `wb.sh` (keep this beside you)

```bash
#!/usr/bin/env bash
# wb.sh <tool> '<json args>'   e.g. wb.sh open_workbench '{"pluginId":"sticky-notes"}'
set -uo pipefail
PAT="${ESOUL_PAT:?set ESOUL_PAT}"; BOARD="${ESOUL_BOARD:?set ESOUL_BOARD}"; BASE="${ESOUL_BASE:-https://externalsoul.com}"
TOOL="${1:?tool}"; ARGS="${2:-{\}}"
python3 -c "import json,sys; print(json.dumps({'appId':'$BOARD','toolName':'${TOOL}_'+'${ESOUL_BOARD_NAME:-Forge}','arguments':json.loads(sys.argv[1])}))" "$ARGS" > /tmp/wb-req.json
curl -sS -X POST -H "Authorization: Bearer $PAT" -H "Content-Type: application/json" \
  -H "Idempotency-Key: wb-$$-$(date +%s%N)" --data-binary @/tmp/wb-req.json \
  "$BASE/api/v1/app-tools" --max-time 800 | python3 -c "
import sys,json
try: d=json.load(sys.stdin)
except Exception: print('non-JSON reply'); raise SystemExit(1)
r=d.get('result', d)
print(r if isinstance(r,str) else json.dumps(r,indent=1)[:6000])"
```
A "non-JSON reply" is a 502/504 from the platform (the box's shell did not answer in time —
it is compiling, wedged, or restarting): wait, re-read `app_problems`, do not repeat blindly.
Write one file from a local folder: `wb.sh write_app_file "$(python3 -c 'import json,sys; print(json.dumps({"pluginId":"my-app","path":sys.argv[1],"content":open(sys.argv[2]).read()}))' server.ts ./my-app/server.ts)"`.

### Finding or making the board

- `GET /api/v1/workspaces` (Bearer) → `[{ id, name, … }]`.
- `GET /api/v1/workspaces/{id}/apps` → `{ apps: [{ nodeId, applicationType, instanceName }] }` —
  the board is `applicationType: "forge"`; the suffix is its `instanceName` with spaces as `_`.
- `POST /api/v1/workspaces/{id}/apps` `{ applicationType: "forge", instanceName: "Forge" }` +
  `Idempotency-Key` → `{ nodeId }`. The person binds GitHub to it once (Account settings).
- Python, if you prefer: `pip install esoul` → `esoul.Client(pat).workspaces.list()`,
  `.apps.create(workspace_id=…, application_type="forge", instance_name="Forge")`,
  `.apps.call_tool(app_id=board, tool_name="open_workbench_Forge", arguments={…})`.

## The tools (the suffix `_<Board>` is implied)

| tool | args | what to read in the answer |
|---|---|---|
| `open_workbench` | `pluginId, name?, description?, icon?` | branch; "platform was N commits behind and has been updated"; the files; the PARK hint |
| `list_app_files` / `read_app_file` | `pluginId[, path]` | — |
| `write_app_file` | `pluginId, path, content` | ⚠ paragraph; `Preview: live (…)` or `Preview: DOWN — <dev server's own error>` |
| `edit_app_file` | `pluginId, path, edits:[{find, replace}]` | each `find` must match exactly once; nothing half-applies |
| `delete_app_file` / `restore_app {sha}` | | ⚠ + Preview line |
| `preview_app` | `pluginId` | "Starting … a minute or two"; the URL is on the board; hot reload after |
| `look_at_app` | `pluginId, intent?, viewer?, critique?` | ⚠ (incl. screenshot rows with ids) + text + imageUrls; `critique:true` adds confirmed findings with evidence |
| `call_app_tool` | `pluginId, tool, args` | the tool's `say`; events applied to the preview; a near-miss name is healed and named |
| `read_app_state` | `pluginId` | the preview's fold (board tab → store → tool-call fold, in that order of truth) |
| `test_app` / `check_app` | `pluginId` | tests only / the whole bar: sync, tests, platform suites, tsc; `skipped` ≠ pass |
| `app_problems` | `pluginId, clear?` | the box's journal + warnings + THE BOARD'S ROWS (open first, ids) |
| `resolve_problem` | `pluginId, id, note(≤140)` | "Resolved p_…: note" — the row turns green; recurrence reopens it |
| `commit_app` / `ship_app` / `merge_app` / `close_workbench` | | as named; `ship` refuses on a red gate unless `force:true` |

Personas for `viewer` (look) and `?viewer=` on the preview URL: `owner`, `member`,
`member-readonly`, `visitor-a`, `visitor-b`, `anonymous`, `agent`, `role:<composed role>`, and
a GRANT with attributes: `visitor-a?grant=customer&customer=143` (URL-encode it in a query:
`visitor-a%3Fgrant%3Dcustomer%26customer%3D143`).

## The preview's own doors (curl them directly — the fastest drive there is)

`PREVIEW = https://sb-<id>.vercel.run` (from `preview_app` / the board). The app's node in the
box is `preview-<applicationType>` (e.g. `preview-plugin_stream_lab`).

```
POST {PREVIEW}/internal/plugin-preview/op/<pluginId>/<op>      {"nodeId":"preview-…","args":{…}}   [?viewer=…]
GET  {PREVIEW}/internal/plugin-preview/route/<pluginId>/<route>?nodeId=preview-…[&viewer=…]
POST {PREVIEW}/internal/plugin-preview/kick                     {"name":"<applicationType>/<task>","data":{"workspaceId":"w","nodeId":"preview-…",…}}
GET  {PREVIEW}/internal/plugin-preview/problems?since=0&warnings=1   → the box's journal as JSON (survives a broken app)
GET  {PREVIEW}/internal/plugin-preview/store?nodeId=preview-…&state=1 → the fold
```
An op refusal comes back as `{ok:false, error, code}`; an access refusal as 401/403 with a
code. A 500 HTML page means the app does not compile — read `problems` for the `dev` row.

## The headless drive (`reference/page-check.mjs`)

`node page-check.mjs "<preview url>" out.png steps.json` — needs Node and `puppeteer-core`
with a Chrome for Testing under `~/.cache/puppeteer` (`npx puppeteer browsers install chrome`).
Steps: `{"select":[sel,value]}`, `{"keys":[sel,"ArrowRight",7]}`, `{"click":sel}`,
`{"wait":ms}`, `{"say":sel}` (prints the element's text). Exit 1 on any console error, throw,
or failed/4xx app call — every one printed. Run it as the company and as each customer
persona. Without a browser, drive with the preview's doors above and read `problems`.

# esoul-sdk — the complete contract for building ExternalSoul apps (llms-full.txt)

Generated from README.md and docs/. Read it whole. Every rule carries the failure that earned it.

# esoul-sdk

esoul-sdk is a toolkit for building applications on [ExternalSoul](https://externalsoul.com). An
application written with it is compiled into the platform and runs as a native app: it has its own
database tables, its own server endpoints, its own background tasks, its own realtime channel, its
own vocabulary of roles, and a set of tools that agents call from chat, voice, the agent builder
and MCP. Access control is declared in the application's manifest and enforced by the platform at
every entry point; application code does not check permissions itself.

The package provides the types, the manifest schema and validator, the rule compiler, the request
helpers and an in-memory test harness. Inside ExternalSoul the same import names resolve to the
platform's implementations.

## Useful links

- [Getting started](docs/01-getting-started.md)
- [Manifest reference](docs/02-manifest.md)
- [Documentation index](#documentation)
- `llms.txt` and `llms-full.txt` — the documentation in one file, for coding models

## Features

Data model

- Tables are declared in the manifest (`db`) and created on install; migrations are additive-only
- Every query is scoped to the application instance and filtered for the caller by compiled rules
- Rows can be owned by their creator, by the workspace, or by a user across instances
- Fields can be sealed (encrypted at rest, readable only by the row's owner)
- Index kinds for equality, list containment and case-insensitive text search, with cursor paging
- Application state on the workspace timeline as a fold of typed events (replayable, scrubbable)

Access control

- A `viewer` on every entry point: owner, member, visitor, anonymous, agent, or the app itself
- Roles as the application's own words (`customer`, `staff`, …), mapped from the platform's kinds
- Per-surface access levels: `write`, `read`, `public`, `token`, or a list of roles
- Rules scoped by a person's typed attributes — a customer linked to a number sees only rows carrying it
- Roles composed by the workspace owner at runtime, inside an envelope the manifest declares
- Refusals distinguish `login-required` from `forbidden`, so a UI can show a sign-in wall

Server

- Ops: server-side functions with a declared input schema, shared with the derived tools
- Routes: HTTP endpoints mounted per instance, including server-sent event streams
- Token routes: endpoints a machine reaches with a bearer token the application minted
- Background tasks on a durable executor, with steps, retries and concurrency limits
- Webhooks, OAuth connections held by the platform, workspace files and file providers
- Access to other applications through bindings (typed contracts) and workspace tools

Realtime

- Per-instance channels with topics; each topic declares its audience (everyone, one person, one role)
- Tokens are issued per channel, so a subscriber never receives another audience's messages

Tools

- One declaration per op is used by the server, the derived tool and the UI
- Tools run on every surface: typed chat, voice, agent builder, MCP, and the browser

Development

- The Forge: a cloud workbench with a live preview, a persona switcher (*view as*), the application's
  tools callable before installation, tests and the full checks
- An in-memory database built from the manifest, with the same compiled rules production uses
- A validator for the package folder (`esoul-app validate`)

Deployment

- Installed from the application's own GitHub repository at a commit
- Additive migrations applied on install; the install card lists every public surface

## Installation

```bash
npm install --save-dev esoul-sdk
```

Outside ExternalSoul the package gives you types, the manifest validator, the rule compiler and the
test helpers. Functions that need the platform (`pluginDb`, `viewerProfile`, `mintRouteToken`, …)
throw `host only` when called outside it; they are exercised through the test harness or in a
Forge workbench.

Requirements: Node.js 20 or newer, TypeScript 5, React 19 for the UI entry point.

## Concepts

**Application.** A folder containing a manifest (`plugin.json`), a schema (`app.tsx`), a UI, and
optionally a server module (`server.ts`) and tests. The folder name is the application id. The
application type is `plugin_` followed by the id with underscores.

**Manifest.** `plugin.json` declares everything the platform enforces: tables, roles, access levels
of ops, routes and tasks, realtime topics, bindings, connections and dependencies. It is validated
against `schemas/plugin.schema.json`.

**Events and state.** Application state is the result of folding typed events from the workspace
timeline. Each event has a `dataCreator` (mints ids and timestamps) and a `processor` (a pure
reducer). The same events are dispatched by the UI, by tools and by tasks.

**Viewer.** The identity of the caller, resolved by the platform for every op, route, task, tool and
UI render. A viewer has a kind, an account id, a set of ids it has acted under, the application's
role word for it, and whether it may write.

**Op.** A server-side function of the application, called from the UI or from a tool. Its input
schema is declared once with `defineOps`; the server parses with `handleOp` and the tool is derived
with `opTool`.

**Route.** An HTTP endpoint the application mounts at `/api/plugins/<id>/route/<name>`.

**Task.** A background job on the platform's durable executor. A task is kicked by an event, runs
in steps that are memoised across retries, and may dispatch events and publish realtime messages.

**Topic.** A named message stream on the application's realtime channel. Its audience is declared in
the manifest.

**Binding.** A slot the application declares (`uses`) and the workspace owner fills with another
application that provides the named contract.

## Package entry points

| Import | Contents |
|---|---|
| `esoul-sdk` | Schema and event types, `defineOps`, `handleOp`, `opTool`, `definePluginChannel`, `defineBindingEvent`, `checkBinding`, `resolveAppRole`, `chartSvg`, `incompleteStateNotice`, `deterministicReducerId`, `callPluginOp`, `kickPluginTask`, `pluginRouteUrl`, `nanoid`, the manifest schema, `compileEnvelope`, `compileCustomRole` |
| `esoul-sdk/server` | `pluginDb`, `viewerProfile`, `sseStream`, `mintRouteToken`, `readAppState`, `callWorkspaceTool`, `computer`, `emitPluginAppEvent`, `generateAppImage`, `renderChartImage`, `setAppRole`, `listAppRoles`, `defineAppRole`, `removeAppRole`, `getPluginConnectionCredentials`, `pluginFiles`, and the context types (`PluginOpContext`, `PluginRouteContext`, `PluginViewer`, `PluginServerModule`) |
| `esoul-sdk/react` | `useViewer`, `useSignInWall`, `useAppCanEdit`, `usePluginEventDispatch`, `usePluginRealtime`, `useWorkspaceTools`, `usePluginWorkspaceFiles`, `usePluginFileUpload`, `useFileSources`, `useFileSourceEntries`; the types `PluginViewerPublic`, `SignInWall` |
| `esoul-sdk/testing` | `memoryDb`, `fakeViewer`, `runOp`, `fakeApps`, `capture`, `startMockOAuth` |
| `esoul-sdk/schemas/plugin.schema.json` | The JSON Schema of the manifest |
| `esoul-app validate <dir>` | Command-line validator for a package folder |

## Getting started

The recommended way to build an application is the Forge, a workbench inside ExternalSoul. It does
not require a checkout of the platform.

1. Add a **Forge** board to a workspace.
2. Ask the assistant to open a workbench for your application. The platform starts a cloud machine
   with the platform's source, scaffolds the application folder, and shows a live preview on the
   board.
3. Edit files with the board's tools (`write_app_file`, `edit_app_file`). Each change reloads the
   preview and reports its health.
4. Inspect the result: `look_at_app` renders the application on desktop and phone, light and dark,
   as any persona (`owner`, `member`, `visitor-a`, `anonymous`, or a composed role such as
   `role:packer`). `call_app_tool` runs the application's tools before installation. `test_app`
   runs the tests; `check_app` runs the full gate.
5. Push the application to its own GitHub repository from the board, and install it from
   Settings → Apps in any workspace.

From your own editor, `npm install --save-dev esoul-sdk` gives you the same types and the
validator, and lets you run tests locally with `esoul-sdk/testing`.

### Package layout

```
<id>/
  plugin.json            the manifest
  ops.ts                 op input schemas (defineOps)
  app.tsx                the schema: events, state, tools, state description
  ui/<id>-ui.tsx         the React UI ("use client")
  server.ts              ops, routes, webhooks
  <id>.test.ts           tests
  .esoul/                generated: db.d.ts, rules.json, migration.sql
```

## Example: a shop

The reference application is a shop. Anyone with the link may browse the catalogue. A signed-in
customer places orders and sees only their own. Staff see every order of the shop. The owner sets
prices and decides who is staff, and may compose narrower roles at runtime — for example a
*packer* who sees only orders being prepared, never the customer's note, and may only mark them
shipped.

### Manifest

```json
{
  "manifestVersion": 1,
  "id": "shop",
  "name": "Shop",
  "version": "1.0.0",
  "applicationType": "plugin_shop",
  "entry": "app",
  "roles": {
    "vocabulary": ["customer", "staff", "owner"],
    "default": {
      "owner": "owner",
      "member-edit": "staff",
      "member-readonly": "staff",
      "visitor": "customer",
      "anonymous": "customer",
      "agent": "inherit"
    },
    "custom": {
      "models": {
        "Order": { "where": ["status"], "hide": ["note"], "update": { "transitions": "status" } }
      },
      "ops": ["set-order-status"]
    }
  },
  "ops": {
    "browse": { "access": "public" },
    "place-order": { "access": "public", "requires": "account" },
    "list-orders": { "access": "public", "requires": "account" },
    "set-order-status": { "access": ["staff", "owner"] },
    "add-product": {}
  },
  "routes": {
    "order-updates": { "access": "read" }
  },
  "channel": {
    "topics": {
      "catalogue": {},
      "order-status": { "audience": "viewer", "mayAddress": ["staff", "owner"] },
      "new-order": { "audience": "role:staff", "mayAddress": ["customer", "staff", "owner"] }
    }
  },
  "db": {
    "Product": {
      "scope": "instance",
      "fields": { "name": "string", "priceCents": "int", "active": "boolean=true", "tags": "string[]" },
      "indexes": [["active", "createdAt"], { "fields": ["tags"], "kind": "contains" }, { "fields": ["name"], "kind": "text" }],
      "rules": { "read": "anyone", "write": ["owner"] }
    },
    "Order": {
      "scope": "instance",
      "owner": "creator",
      "fields": { "status": "string=new", "totalCents": "int", "lines": "json", "shipTo": "json", "note": "text?" },
      "indexes": [["status"], ["createdAt"]],
      "rules": {
        "read": ["creator", "staff", "owner"],
        "create": { "roles": ["customer", "staff", "owner"], "requires": "account" },
        "update": { "roles": ["staff", "owner"], "creatorMay": ["note"] },
        "delete": ["owner"]
      }
    },
    "Address": {
      "scope": "user",
      "fields": { "label": "string", "lines": "json" },
      "sealed": ["lines"]
    }
  }
}
```

An op with no `access` is `write`: only the owner and edit members may call it. `"access":
"public"` admits anyone who can reach the application, including through a share link;
`"requires": "account"` makes an anonymous call fail with `login-required` instead of `forbidden`.

### Op inputs

```ts
// ops.ts
import { z } from "zod";
import { defineOps } from "esoul-sdk";

export const ORDER_STATUSES = ["new", "preparing", "shipped", "fulfilled", "refunded"] as const;

export const ops = defineOps({
  browse: z.object({}),
  "add-product": z.object({ name: z.string().min(1).max(80), priceCents: z.number().int().min(0) }),
  "place-order": z.object({
    lines: z.array(z.object({ productId: z.string().min(1), qty: z.number().int().min(1).max(99) })).min(1),
    shipTo: z.object({ name: z.string().min(1), street: z.string().min(1), city: z.string().min(1) }),
    note: z.string().max(280).optional(),
  }),
  "list-orders": z.object({}),
  "set-order-status": z.object({
    orderId: z.string().min(1).describe("The order id, as list_orders shows it"),
    status: z.enum(ORDER_STATUSES),
  }),
});
```

### Server

```ts
// server.ts
import "server-only";
import { handleOp } from "esoul-sdk";
import { pluginDb, type PluginOpContext, type PluginServerModule } from "esoul-sdk/server";
import type { ShopDb } from "./.esoul/db";
import { ops } from "./ops";

const db = (ctx: PluginOpContext) => pluginDb<ShopDb>(ctx);

export const pluginServer: PluginServerModule = {
  ops: {
    browse: handleOp(ops, "browse", async (ctx) => {
      const d = await db(ctx);
      return d.product.findMany({ where: { active: true }, orderBy: { createdAt: "asc" }, take: 200 });
    }),

    "add-product": handleOp(ops, "add-product", async (ctx, input) => {
      const d = await db(ctx);
      return d.product.create({ data: { name: input.name, priceCents: input.priceCents, tags: [] } });
    }),

    "place-order": handleOp(ops, "place-order", async (ctx, input) => {
      const d = await db(ctx);
      // Price on the server, from the catalogue.
      const products = await d.product.findMany({ where: { id: { in: input.lines.map((l) => l.productId) } } });
      const totalCents = input.lines.reduce((sum, l) => sum + l.qty * (products.find((p) => p.id === l.productId)?.priceCents ?? 0), 0);
      const order = await d.order.create({ data: { status: "new", totalCents, lines: input.lines, shipTo: input.shipTo, note: input.note } });
      await ctx.notify("new-order", { orderId: order.id });
      return { orderId: order.id, totalCents };
    }),

    "list-orders": handleOp(ops, "list-orders", async (ctx) => {
      const d = await db(ctx);
      return d.order.findMany({ orderBy: { createdAt: "desc" } });
    }),

    "set-order-status": handleOp(ops, "set-order-status", async (ctx, input) => {
      const d = await db(ctx);
      const order = await d.order.update({ where: { id: input.orderId }, data: { status: input.status } });
      await ctx.notify("order-status", { orderId: order.id, status: order.status }, { to: { viewerIds: [order.ownerId] } });
      return order;
    }),
  },
};
```

There is no access check in this file. `pluginDb(ctx)` returns a client scoped to the instance and
filtered for `ctx.viewer`. A customer's `order.findMany` returns their own rows; a staff member's
returns every row of the shop. A customer calling `set-order-status` is refused before the handler
runs, because the manifest opens it to `staff` and `owner` only. A packer — a composed role scoped
to `status: ["preparing"]` — receives only those rows, with `note` blanked, and an update from
`preparing` to anything other than `shipped` is refused with the allowed move named.

### Tools

```ts
// app.tsx (excerpt)
import { opTool } from "esoul-sdk";
import { ops } from "./ops";

toolkitCreator: (identifier) => {
  const base = identifier.instanceName.replace(/[^a-zA-Z0-9]/g, "_");
  const cfg = { pluginId: "shop", nodeId: identifier.nodeId };
  return {
    [`browse_${base}`]: opTool(ops, "browse", {
      ...cfg,
      description: `List the products of "${identifier.instanceName}".`,
      readOnly: true,
      publicSafe: true,
      say: (rows) => ({ text: rows.map((p) => `${p.name} — ${(p.priceCents / 100).toFixed(2)} (id ${p.id})`).join("\n") || "No products." }),
    }),
    [`set_order_status_${base}`]: opTool(ops, "set-order-status", {
      ...cfg,
      description: `Move an order of "${identifier.instanceName}" to a new status.`,
      say: (o) => ({ text: `Order ${o.id} is now ${o.status}.` }),
    }),
  };
},
```

The tool's parameters are the op's input schema; a field the op does not declare is refused with
the field named. The tool runs as the person who invoked it, on every surface.

### UI

```tsx
// ui/shop-ui.tsx (excerpt)
"use client";
import { callPluginOp } from "esoul-sdk";
import { useSignInWall, useViewer } from "esoul-sdk/react";

export function ShopUi({ nodeId }: { nodeId: string }) {
  const viewer = useViewer();           // { kind, userId, role, canEdit, signedIn, customRole, can }
  const wall = useSignInWall();
  const order = async (lines, shipTo) => {
    try {
      return await callPluginOp("shop", "place-order", nodeId, { lines, shipTo });
    } catch (err) {
      wall.raise(err);                   // shows the sign-in wall on `login-required`, rethrows otherwise
    }
  };
  // viewer.can.models.Order.moves tells a packer's screen which buttons to show;
  // the server enforces the same rule regardless.
  …
}
```

### Test

```ts
// shop.test.ts
import { fakeViewer, memoryDb, runOp } from "esoul-sdk/testing";
import manifest from "./plugin.json";
import { pluginServer } from "./server";

const owner = fakeViewer("owner");
const ada = fakeViewer("visitor", { userId: "u_ada", role: "customer" });
const lin = fakeViewer("visitor", { userId: "u_lin", role: "customer" });

it("a customer sees only their own orders", async () => {
  const db = memoryDb(manifest);
  const { result: p } = await runOp(pluginServer, "add-product", { viewer: owner, args: { name: "Tea", priceCents: 350 }, db: db.as(owner) });
  const shipTo = { name: "Ada", street: "Main 1", city: "Brno" };
  await runOp(pluginServer, "place-order", { viewer: ada, args: { lines: [{ productId: p.id, qty: 1 }], shipTo }, db: db.as(ada) });
  const { result } = await runOp(pluginServer, "list-orders", { viewer: lin, args: {}, db: db.as(lin) });
  expect(result).toEqual([]);
});

it("an anonymous caller is asked to sign in", async () => {
  const db = memoryDb(manifest);
  const anon = fakeViewer("anonymous");
  await expect(runOp(pluginServer, "list-orders", { viewer: anon, args: {}, db: db.as(anon) })).rejects.toMatchObject({ code: "login-required" });
});
```

`memoryDb(manifest)` builds an in-memory database from the manifest with the same compiled rules the
platform applies to the real database. `runOp` calls the op with a platform-shaped context and
records what it notified and emitted.

## API reference

### Manifest (`plugin.json`)

| Field | Type | Description |
|---|---|---|
| `manifestVersion` | `1` | Schema version. |
| `id` | string | Application id: lower-case letters, digits, hyphens. Equals the folder name. |
| `name`, `description`, `version`, `icon` | string | Shown in the store and the install card. `version` is semver. |
| `applicationType` | string | `plugin_` + id with underscores. Never changes after release. |
| `entry` | string | The schema module (`app`). |
| `roles.vocabulary` | string[] | The application's role words. |
| `roles.default` | object | Mapping from platform kinds (`owner`, `member-edit`, `member-readonly`, `visitor`, `anonymous`, `agent`) to role words. `"inherit"` for `agent` uses the role of the person it acts for. |
| `roles.describe` | object | One line per role, for the install card. |
| `roles.attributes` | object | Name → `string`, `int` or `boolean`: what a grant may say about a person. Typed when granted; carried on `viewer.attrs`; read by scoped rules as `viewer.<name>`. |
| `roles.custom` | object | The envelope for roles the owner composes: per model, which indexed fields may scope (`where`), which fields may be hidden (`hide`), which fields and transition field may be updated (`update`); `ops` a composed role may be handed; `attributes` a grant may carry. |
| `ops` | object | Op name → `{ access, requires }`. `access`: `write` (default), `read`, `public`, or a list of role words. `requires: "account"` turns an anonymous refusal into `login-required`. |
| `routes` | object | Route name → `{ access }`, additionally `token` for routes reached with a minted bearer token. |
| `kickableTasks` | object | Tasks the browser may kick, with their access level. |
| `pollTasks` | array | `[{ task, everyMinutes }]`: tasks the platform kicks on a schedule (5 to 1440 minutes). |
| `channel.topics` | object | Topic name → `{ audience, mayAddress, description }`. `audience`: `all` (default), `viewer`, or `role:<word>`. `mayAddress`: roles that may publish on the topic. |
| `db` | object | Model name → table declaration (see below). |
| `uses` | object | Slot name → `{ contract, label, optional }`. |
| `provides` | object | Contracts this application provides, with the tools, events and tables each names. |
| `connections` | array | OAuth or API-key connections the platform holds for the application. |
| `webhooks` | string[] | Webhook names handled in `server.ts`. |
| `workspaceTools` | array | Tools of other applications the server side may call. |
| `platformApi` | object | `{ min, max? }`: the platform contract versions the application accepts. |

npm packages the application needs are declared in a `package.json` in the application folder
with a `dependencies` field only.

Table declaration:

| Field | Description |
|---|---|
| `scope` | `instance` (rows belong to this instance), `workspace`, or `user` (rows follow the account across instances). |
| `owner` | `creator` marks each row with the creator's ids so rules can name `creator`. |
| `fields` | Name → type: `string`, `text`, `int`, `float`, `boolean`, `json`, `datetime`, `string[]`, `ref:<Model>`; `?` for optional, `=value` for a default. |
| `unique`, `indexes` | Field groups. An index entry may be `{ fields, kind }` with `kind` `btree` (default), `contains` (list membership) or `text` (case-insensitive substring). |
| `sealed` | Fields encrypted at rest and readable only by the row's owner. |
| `rules` | `read`, `create`, `update`, `delete`: `"anyone"`, a list of principals (`creator`, role words, or a scoped role `{ "role": "customer", "where": { "customer": "viewer.customer" } }`), or `{ roles, requires, creatorMay }`. A scoped role reads only the rows its `where` names, creates inside them, and grants nothing to a holder without the attribute. A model without rules is writable by the owner role only. |

Platform columns on every table: `id`, `workspaceId`, `nodeId`, `ownerId`, `createdBy`,
`createdAt`, `updatedAt`, `deletedAt`.

### `esoul-sdk`

| Export | Description |
|---|---|
| `ApplicationSchema`, `EventDefinition`, `EventTypes`, `ApplicationIdentifier`, `ApplicationPort` | The schema contract: events, `stateCreator`, `toolkitCreator`, `getStateDescription`, `tasks`, `channel`, `reconstructStateFromEventLog`. |
| `defineOps(inputs)` | Declares the input schema of every op once. |
| `handleOp(ops, name, fn)` | Wraps an op handler so it receives parsed input; an undeclared or malformed field is refused as `invalid`, naming the field. |
| `opTool(ops, name, { pluginId, nodeId, description, say, then?, readOnly?, publicSafe? })` | Derives an agent tool from an op. `say` turns the op's result into the tool's text; `readOnly` admits a read-scoped token; `publicSafe` allows use on a public storefront. |
| `definePluginChannel({ applicationType, topics })` | Declares the realtime channel placed on the schema as `channel`. |
| `defineBindingEvent`, `checkBinding`, `bindingsOf` | Bindings: the event that records a slot being filled, the check that a provider satisfies a contract, and the current bindings from state. |
| `resolveAppRole`, `roleKeyFor` | The mapping from platform kinds to role words that the platform itself uses. |
| `compileEnvelope`, `compileCustomRole`, `CustomRoleError` | The compiler for composed roles, for tests that assert on them. |
| `coerceAttr`, `coerceAttrs`, `attrProblem`, `ATTR_TYPES` | Attribute typing: what a typed value becomes, and the sentence for one that does not fit. |
| `chartSvg(spec)` | Renders a time-series chart with panels, markers and gaps to SVG; text is drawn as glyph outlines so it renders on a server without fonts. |
| `incompleteStateNotice`, `missingStateKeys` | For `getStateDescription`: reports a state that did not load instead of describing it as empty. |
| `deterministicReducerId(prefix, seed)` | A stable id for use inside a reducer. |
| `callPluginOp(pluginId, op, nodeId, args?)` | Calls an op from the browser or from a tool. Throws `PluginCallError` carrying `code` (`invalid`, `forbidden`, `login-required`), `detail` and `signInPath`. |
| `kickPluginTask(args)`, `pluginRouteUrl(...)` | Kicks a task; builds a route's URL. |
| `timingSafeEqual`, `nanoid` | Utilities. |

### `esoul-sdk/server`

| Export | Description |
|---|---|
| `PluginServerModule` | `{ ops, routes, webhooks }` exported as `pluginServer` from `server.ts`. |
| `PluginOpContext` | `pluginId`, `opName`, `workspaceId`, `nodeId`, `instanceName`, `viewer`, `args`, `origin`, `cloudConnectionId`, `apps` (bound applications), `notify(topic, data, { to? })`, `emit(eventName, eventData)`. |
| `PluginRouteContext` | The op context plus `request`, `method`, `searchParams`, `canWrite`. Handlers return a `Response`. |
| `PluginViewer` | `kind`, `userId`, `viewerIds`, `role`, `customRole`, `attrs`, `canWrite`, `shareId`, `agent`. |
| `pluginDb<T>(ctx)` | A typed client over the application's tables, scoped and filtered for `ctx.viewer`. Per model: `findMany`, `findUnique`, `count`, `aggregate`, `groupBy`, `create`, `createMany`, `update`, `updateMany`, `upsert`, `delete`, `deleteMany`; `$transaction`. Refusals throw with `code` `forbidden`, `login-required` or `invalid`. |
| `viewerProfile(viewer)` | The caller's own account (`name`, `email`, `picture`), or `null`. |
| `sseStream(fn)` | A server-sent event response for a route. |
| `mintRouteToken(ctx, { route, ttlSeconds?, label? })` | Mints a bearer token for a route declared `"access": "token"`. Returns `{ token, url, expiresAt }`; `url` is built on `ctx.origin`. Expiry is the only revocation; 30 days at most. |
| `readAppState(nodeId)` | The folded state of another application in the workspace. |
| `callWorkspaceTool({ ... })` | Calls a tool of another application, gated by the manifest's `workspaceTools`. |
| `computer(ctx, machineNodeId)` | A paired machine: `status`, `run`, `runToEnd`, `claude`, `claudeToEnd`, `readFile`, `fetchJson`, `python`, `runJson`. Waits are capped and the approval gate is reported. |
| `emitPluginAppEvent(args)` | Appends an event to the application's own timeline from server code. |
| `generateAppImage(ctx, args)` | Generates an image, scales it to web weight, stores it and returns its URL. Refused in a Forge preview. |
| `renderChartImage(ctx, { name, svg })` | Renders an SVG to PNG and returns `{ url }` (installed) or `{ base64 }` (preview). |
| `setAppRole(ctx, { email, role, attrs? })` | The owner gives an account one of the application's role words, or a composed role, with attribute values (`{ customer: "204" }`) validated against `roles.attributes`. Recorded as an event. |
| `listAppRoles(ctx)` | `{ people, roles, custom, envelope }`. |
| `defineAppRole(ctx, definition)`, `removeAppRole(ctx, name)` | The owner composes or removes a role inside `roles.custom`. |
| `getPluginConnectionCredentials(ctx)` | The credentials of the instance's bound connection. |
| `pluginFiles(ctx)`, `filesForOp(ctx)` | Workspace files and file sources from server code. |

### `esoul-sdk/react`

| Hook | Description |
|---|---|
| `useViewer()` | The public viewer: `kind`, `userId`, `role`, `canEdit`, `signedIn`, `attrs`, `customRole`, `can`. `can` lists the ops a composed role may call and, per model, the hidden fields, updatable fields and allowed moves. |
| `useSignInWall()` | `{ needed, reason, signIn, raise, ask, serverSays }`. `raise(err)` shows the wall when `err.code === "login-required"` and rethrows anything else; `ask(call)` attempts a call and returns `null` (wall raised) on `login-required`; `serverSays` is the server's answer so far (`null`, `"account"`, `"no-account"`). |
| `useAppCanEdit()` | Whether the current viewer may write. |
| `usePluginEventDispatch()` | Dispatches one of the application's events from the UI. |
| `usePluginRealtime({ channel, workspaceId, nodeId, topics, enabled? })` | Subscribes to the instance's channel. Returns `{ data, latestData, error, state }`. |
| `useWorkspaceTools(identity)` | Lists and calls tools of other applications from the UI, subject to `workspaceTools`. |
| `usePluginWorkspaceFiles()`, `usePluginFileUpload()`, `useFileSources()`, `useFileSourceEntries()` | Workspace files, upload, and file sources (workspace, Google Drive, providers). |

### `esoul-sdk/testing`

| Export | Description |
|---|---|
| `memoryDb(manifest, options?)` | An in-memory database compiled from the manifest. Starts as the application's own code; `.as(viewer)` returns the same rows as another caller. `$rules` exposes the compiled rules. |
| `fakeViewer(kind, { userId?, viewerIds?, role?, name?, email?, attrs? })` | A viewer of a kind. `name`/`email` are what `viewerProfile` returns for it; `attrs` are what a scoped rule reads. |
| `runOp(server, opName, { viewer, args?, db?, apps?, notifyFails? })` | Calls `pluginServer.ops[opName]` with a platform-shaped context. Returns `{ result, notified, emitted }`; throws the op's refusals. |
| `fakeApps(fixtures)` | Bound applications for `ctx.apps`. |
| `capture()` | A recorder for callbacks. |
| `startMockOAuth(opts?)` | A local OAuth server for connection tests. |

### Command line

```bash
npx esoul-app validate <dir>
```

Exits 0 when the folder is a well-formed application package; otherwise prints each problem.

## Rules

> **Note.** State is a fold of events. A processor must be a pure, idempotent function of
> `(state, event)`. Ids and timestamps are minted in `dataCreator`, never in a processor. An event
> that replaces a whole value carries a collapse key so a burst folds to one event.

> **Note.** Access is declared, not checked. An op, route or task that tests the viewer itself has
> a second answer to a question the platform already answered; the platform's answer is the one
> enforced. Use `viewer.role` and `viewer.can` to decide what a screen shows, not what a request
> may do.

> **Warning.** A task handler is re-run from the top after every step boundary. Every side effect
> — a dispatch, a fetch, an emit, a random id — belongs inside `ctx.step.run`. A side effect outside
> a step runs once per replay.

> **Warning.** Application code imports the platform only through `esoul-sdk`. A relative import
> into the platform's source is refused by the checks and by the install.

> **Note.** `viewer.signedIn` in the UI is the page's estimate. Whether a request needs an account
> is decided by the op; attempt the call and let `useSignInWall().raise` act on `login-required`.

## Documentation

| | |
|---|---|
| [1. Getting started](docs/01-getting-started.md) | The Forge loop, package layout, the smallest complete application |
| [2. The manifest](docs/02-manifest.md) | Every field of `plugin.json` |
| [3. Events and state](docs/03-events-and-state.md) | `dataCreator`, `processor`, collapse keys, replay |
| [4. Tools](docs/04-tools.md) | Tools on every surface; deriving a tool from its op |
| [5. The UI](docs/05-ui.md) | React, hooks, theme, responsive rules |
| [6. The server](docs/06-server.md) | Ops, routes, webhooks, `computer`, charts, calling other applications |
| [7. Background tasks](docs/07-background-tasks.md) | The durable executor, the replay model, concurrency |
| [8. Connections](docs/08-connections.md) | OAuth and API-key connections held by the platform |
| [9. Files](docs/09-files.md) | Workspace files, Drive, file providers |
| [10. Testing](docs/10-testing.md) | The fold contract, ops, tasks and rules as tests |
| [11. Shipping](docs/11-shipping.md) | The repository, review, release, install, dependencies |
| [12. Rules and failures](docs/12-rules.md) | Each rule with the failure it prevents |
| [13. People and access](docs/13-people-and-access.md) | Viewer, roles, access levels, composed roles, the sign-in wall |
| [14. Your own tables](docs/14-database.md) | `db`, rules, scopes, sealed fields, indexes, migrations |
| [15. Realtime](docs/15-realtime.md) | Topics, audiences, addressing |
| [16. Bindings](docs/16-bindings.md) | Slots, contracts, reaching another application |

## Versions

| Version | Changes |
|---|---|
| 0.14.0 | Attribute-scoped access: `roles.attributes` (typed; validated when granted; `viewer.attrs`); scoped rule principals `{ role, where }` with `viewer.<attribute>`, applied to reads, aggregates, updates and deletes and filling or refusing creates, in both database clients; a rule combining `creator` with a scoped role is refused. `compileManifestRules` is the one reader of a manifest's rules. VIEW AS personas carry attributes (`visitor-a?customer=204`). |
| 0.13.0 | Composed roles: `roles.custom` envelope; `defineAppRole`, `removeAppRole`; `setAppRole` with attributes; `listAppRoles` returns composed roles and the envelope. Reads, updates and deletes are narrowed by the composition in both database clients; surfaces not handed to the role are refused; `useViewer().customRole` and `can`. `access: [<roles>]` on a surface. Composed roles are personas in the Forge. |
| 0.12.0 | Token routes: `"access": "token"` and `mintRouteToken`. `ctx.origin` on ops. |
| 0.11.0 | `chartSvg`, `renderChartImage`. `computer().python()` and `runJson()` with `truncated` outputs. `APPROVAL_WAIT`. Table refusals name the constraint. |
| 0.10.0 | `computer(ctx, machineNodeId)`. Server code in a Forge preview reaches the workspace (`callWorkspaceTool`, `readAppState`, `computer`), gated by `workspaceTools`. |
| 0.9.0 | `defineOps`, `handleOp`, `opTool`: one declaration for an op's input, its server parser and its tool. |
| 0.8.0 | `generateAppImage`; `setAppRole` and `listAppRoles`; `useSignInWall().ask()` and `serverSays`. |
| 0.7.0 | Index kinds (`contains`, `text`) and cursor paging; `ctx.emit`; list field defaults; `aggregate`, `groupBy`, `$transaction`, `*Many` documented. |
| 0.6.0 | Tables (`db`, `pluginDb`, rules, scopes, sealed fields, additive migrations). `viewer` on every entry point, roles, access levels, the sign-in wall. Realtime audiences. Bindings. `viewerProfile`. Testing: `memoryDb`, `fakeViewer`, `runOp`. |
| 0.5.0 | Routes, `sseStream`, realtime channels. |
| 0.3.0 | Renamed from `@externalsoul/plugin-sdk`. `readAppState`, `callWorkspaceTool`. The import wall. |
| 0.2.0 | File sources and providers. |



==============================================================================
# 1. Getting started

## What an app is

An ExternalSoul app is a folder. Compiled into the platform, it becomes a native app: it renders
in the same frame as the spreadsheet next to it, its state is a fold of typed events on the
workspace timeline, and its tools are callable from chat, voice, the agent builder and MCP. There
is no dynamic loading and no sandbox at runtime: the review of your submission is the trust
boundary, and this SDK plus the platform's checks make your package correct on arrival.

## The loop

You do not need the repository, a local checkout, or a running platform.

1. In your ExternalSoul workspace, add a **Forge** board.
2. Tell the assistant (or your own Claude over MCP) to **open a workbench** for your app. The
   platform boots a cloud machine holding the platform's source, scaffolds your app folder from
   the template, and shows a **live preview** in the board's frame.
3. Write the files with the board's tools (`write_app_file`, `edit_app_file`). Every change
   hot-reloads into the preview and comes back with the preview's health, the compiler's own
   words if you broke it.
4. **Look** at it (`look_at_app`: desktop and phone, light and dark), **call its tools** before it
   is installed (`call_app_tool`, the events land in the frame), **read its state**
   (`read_app_state`), **run its tests** (`test_app`, seconds) and **the full checks**
   (`check_app`: registry sync, the platform suites, types, the import wall).
5. **Submit** (`ship_app`). The owner reviews the diff, approves, and releases it with one
   script. The board then says "released — add it to a workspace".
6. Add it to a workspace like any other app. Its tools are live everywhere.

From your own editor, `npm install --save-dev esoul-sdk` gives you the same types and the
manifest validator, and lets you write tests locally. The code still runs in the platform.

## Package layout

```
src/plugins/<id>/
  plugin.json                 the manifest (docs/02)
  app.tsx                     the SCHEMA — exports `pluginSchema`; never "use client" (docs/03, 04)
  ui/<id>-ui.tsx              the React UI — "use client" (docs/05)
  server.ts                   only if you declare ops or webhooks (docs/06)
  <id>.test.ts                the fold contract as tests (docs/10)
  <id>-ui.test.tsx            renders the UI once, checks the empty state
  package.json                only if you need an npm package the platform lacks (docs/11)
```

The folder name is the app id: lower-case, hyphens. The application type is `plugin_` plus the
id with underscores (`sticky-notes` → `plugin_sticky_notes`). Neither changes after shipping.

## The smallest complete app

```ts
// app.tsx
import { nanoid, EventTypes, incompleteStateNotice, type ApplicationIdentifier,
  type ApplicationSchema, type EventData, type EventDefinition, type ApplicationPort } from "esoul-sdk";
import { z } from "zod";
import { NotesUi } from "./ui/notes-ui";

export interface NotesData extends ApplicationIdentifier {
  notes: { id: string; text: string; at: number }[];
}

export const notedEvent: EventDefinition<NotesData> = {
  eventName: "plugin_notes_noted",
  type: EventTypes.Client,
  dataCreator: (args) => ({
    eventName: "plugin_notes_noted",
    eventData: { id: args.id ?? nanoid(), text: String(args.text ?? ""), at: args.at ?? Date.now() },
    timestamp: Date.now(),
    workspaceId: args.workspaceId,
    applicationId: args.applicationId || args.nodeId,
    instanceName: args.instanceName,
    chatIdSource: args.chatIdSource,
  }) as EventData<any>,
  processor: (state, event) => {
    const { id, text, at } = event.eventData ?? {};
    if (typeof id !== "string" || typeof text !== "string" || !text.trim()) return state;
    if (state.notes.some((n) => n.id === id)) return state; // replay-safe
    return { ...state, notes: [...state.notes, { id, text: text.trim(), at: typeof at === "number" ? at : 0 }] };
  },
};

export const pluginSchema: ApplicationSchema<NotesData> = {
  applicationType: "plugin_notes",
  description: "Notes on the timeline.",
  reactNode: NotesUi,
  reconstructStateFromEventLog: true,
  events: [notedEvent],
  getPorts: (): ApplicationPort[] => [],
  stateCreator: (identifier) => ({ ...identifier, notes: [] }),
  toolkitCreator: (identifier, forChatId, eventCallback) => {
    const base = identifier.instanceName.replace(/[^a-zA-Z0-9]/g, "_");
    const tools = {
      [`add_note_${base}`]: {
        description: `Add a note to "${identifier.instanceName}". Returns its id.`,
        parameters: z.object({ text: z.string().min(1) }),
        execute: async ({ text }: { text: string }) => {
          const id = nanoid();
          await eventCallback(notedEvent.dataCreator({ ...identifier, applicationId: identifier.nodeId, chatIdSource: forChatId, id, text }));
          return `Added note ${id}.`;
        },
      },
    };
    for (const t of Object.values(tools)) (t as any).onClient = (t as any).execute; // every surface
    return tools;
  },
  getStateDescription: (state) => {
    const notLoaded = incompleteStateNotice({ title: "Notes", instanceName: state?.instanceName, shape: { lists: { notes: state?.notes } } });
    if (notLoaded) return notLoaded;
    return [`## Notes — "${state.instanceName}"`, ...(state.notes.length ? state.notes.slice(-10).map((n) => `- ${n.text} \`id:${n.id}\``) : ["- No notes yet."])].join("\n");
  },
};
```

Every line of that is explained in the next pages. The workbench scaffolds you an equivalent.



==============================================================================
# 2. The manifest — `plugin.json`

Validated by `esoul-app validate <dir>`, by the workbench's checks and at release. The JSON
schema is shipped at `schemas/plugin.schema.json`.

```json
{
  "manifestVersion": 1,
  "id": "sticky-notes",
  "name": "Sticky notes",
  "version": "0.1.0",
  "description": "A wall of paper notes: pin, colour, drag, and let agents add to it.",
  "applicationType": "plugin_sticky_notes",
  "entry": "app",
  "icon": "StickyNote",
  "author": { "name": "Sticky notes", "url": "esoul:user:<your id>" },

  "ops": ["read-notes"],
  "webhooks": ["inbound"],
  "kickableTasks": ["sync"],
  "pollTasks": [{ "task": "refresh", "everyMinutes": 30 }],
  "workspaceTools": ["spreadsheet:add_row", "my_computer:claude_task"],
  "connections": [{ "key": "github", "kind": "oauth2", "label": "GitHub",
    "authorizeUrl": "https://github.com/login/oauth/authorize", "tokenUrl": "https://github.com/login/oauth/access_token",
    "oauthScopes": ["repo"], "clientIdEnv": "GITHUB_CLIENT_ID", "clientSecretEnv": "GITHUB_CLIENT_SECRET" }],
  "fileSources": { "workspace": "read", "providers": ["google-drive"] },
  "platformApi": { "min": "1.1.0" }
}
```

| Field | Rule |
|---|---|
| `id` | lower-case, hyphens; equals the folder name; **never changes** after shipping |
| `name` | what people see in the picker (≤ 80) |
| `version` | semver; bump on every submission |
| `description` | one honest paragraph (≤ 500) |
| `applicationType` | `plugin_` + id with underscores; the platform tells plugins from built-ins by the prefix; **never changes** |
| `entry` | the schema module without extension (`app`) |
| `icon` | a lucide-react name from the curated set (the workbench lists them when yours is wrong); missing → the generic glyph, never a broken tile |
| `author` | stamped by the workbench at scaffold: `url` is `esoul:user:<id>`, and it is what the release script and the id-collision check read. No email — a manifest may become public |
| `ops` | server operations exported by `server.ts` (docs/06) |
| `webhooks` | inbound routes `POST /api/plugins/<id>/webhook/<hook>` served by `server.ts` (docs/06) |
| `kickableTasks` | task names the **browser** may kick (docs/07) |
| `pollTasks` | tasks the platform kicks on a cadence, 5-minute granularity, minimum 5 (docs/07) |
| `roles.attributes` | what a grant may say about a person, typed: `{ "customer": "int" }` — rules scope a role by `viewer.<attribute>` (docs/13) |
| `roles.custom` | the envelope an OWNER composes roles inside at runtime — fields a role may be scoped by / denied / change, transitions, surfaces, attributes (docs/13) |
| `workspaceTools` | the grant wall for calling OTHER apps' tools — `<applicationType>:<tool base name>`; absent = no cross-app access (docs/04, 06) |
| `connections` | OAuth2 / API-key connections the user grants once and the platform holds sealed; **names of env vars, never values** (docs/08) |
| `fileSources` / `fileProviders` | consent to read workspace files and providers; providers you contribute (docs/09) |
| `platformApi` | refuse install outside `[min, max]` of the platform contract version |
| `scopes` | reserved |

Secrets never live in a manifest, and a `package.json` in the folder declares npm dependencies
the platform does not have yet (docs/11).



==============================================================================
# 3. Events and state — the heart of the contract

## The model

An app's state is **the fold of its events**. The platform stores the events (a per-workspace,
per-app log with a sequence number) and derives the state by running your processors over them:
on the client as a person taps, on the server as the canonical fold, again on every replay,
scrub, snapshot, cross-device sync and share redaction. There is no other state. That is what
makes the timeline scrubbable and an agent's action indistinguishable from a person's.

So three things must hold, and the checks and the review look for them:

1. **A processor is pure and idempotent.** Same input, same output, on every replay; the same
   event applied twice leaves the state as after once.
2. **Ids and timestamps are minted in the `dataCreator`, never in a processor.** A processor that
   calls `nanoid()` or `Date.now()` folds differently every replay and breaks time-scrubbing.
3. **A processor refuses what it cannot trust** — returns `state` unchanged rather than throw.
   Malformed payloads exist (a retried webhook, an old client), and a throw in a fold takes the
   whole workspace view down.

## Anatomy of an event

```ts
export const noteTextSetEvent: EventDefinition<StickyNotesData> = {
  eventName: "plugin_sticky_notes_text_set",        // globally unique; prefix with your type
  type: EventTypes.Client,                          // Client = dispatched by UI/tools; Server = from tasks/webhooks
  dataCreator: (args) => ({                         // MINTS the envelope. Called by the UI and by tools.
    eventName: "plugin_sticky_notes_text_set",
    eventData: { noteId: args.noteId, text: String(args.text ?? "").slice(0, 2000), at: args.at ?? Date.now() },
    timestamp: Date.now(),
    workspaceId: args.workspaceId,
    applicationId: args.applicationId || args.nodeId,
    instanceName: args.instanceName,
    chatIdSource: args.chatIdSource,
  }) as EventData<any>,
  processor: (state, event) => {                    // PURE. The fold.
    const d = event.eventData ?? {};
    if (typeof d.noteId !== "string" || typeof d.text !== "string") return state;
    const i = state.notes.findIndex((n) => n.id === d.noteId);
    if (i === -1) return state;                     // an unknown id is ignored, never invented
    const next = [...state.notes]; next[i] = { ...next[i], text: d.text, updatedAt: d.at };
    return { ...state, notes: next };
  },
  // One row on the timeline per typing burst, not one per keystroke (see below).
  collapseConfig: {
    collapseKeyFn: (eventData, ctx) => `${ctx.applicationId}:${(eventData as { noteId?: string }).noteId}:text`,
    collapseWindowMs: 2500,
  },
};
```

`stateCreator(identifier)` returns the empty state — always including the identifier fields
(`{ ...identifier, notes: [] }`), because tools and describers read `instanceName` from it.

## Collapse keys: bursts are one event

A person typing, dragging or resizing produces a burst. Without a collapse key that is a hundred
timeline rows and a scrub that steps through every keystroke. `collapseConfig` merges consecutive
events with the same key inside the window into one. Key by the **entity and the field**
(`<app>:<noteId>:text`), never by the app alone: two notes edited in the same window must not
merge. Whole-replace events (an editor's content, a canvas snapshot) **must** carry a collapse key.

## What is local and what is an event

What the workspace remembers goes through events. What is honestly local to one device — a drag
in progress, text still being typed, which tab is open — stays in component state and lands as
ONE event when done. Never mirror app state into a second store; never write derived data the
fold could recompute.

## Bounds

Cap collections in the processor (`if (state.notes.length >= 300) return state;`) and cap
strings in the `dataCreator`. An app with an unbounded array is an app that one day cannot be
folded.

## `reconstructStateFromEventLog: true`

Set it. It tells the platform your state IS the fold, which is what enables replay-on-load,
snapshot baselines and the durability layers. Every shipped plugin and the scaffold set it.

## Server-typed events

`EventTypes.Server` marks events that only server code emits (a task, a webhook). The UI must
not dispatch them, and the processor still obeys the three rules.

## Durability you get for free

Because your events flow through the platform's dispatch chokepoint, an installed app inherits
the write-ahead log with retry, session stamping, the stale-base write fence, the pagehide flush
that walks every open app, server-side deduplication of re-sent events, one canonical server fold
and the monotonic merge guard. You do nothing for this — except keep the three rules, because
every one of those layers re-runs your processors.



==============================================================================
# 4. Tools — what agents call

A tool is how chat, voice, the agent builder, MCP, a WebMCP page, and other apps' server code act
on your app. **Every UI action has a tool twin**: if a person can do it by hand, an agent can do
it by tool, through the same event. The platform mints your tools per instance as
`<verb>_<instance name>` (spaces and punctuation → underscores).

```ts
toolkitCreator: (identifier, forChatId, eventCallback) => {
  const base = identifier.instanceName.replace(/[^a-zA-Z0-9]/g, "_");
  const idArgs = { ...identifier, applicationId: identifier.nodeId, chatIdSource: forChatId };
  // A tool that dispatches an event of the fold declares its own parameters.
  // Browser surfaces (voice, WebMCP) run `onClient`: the same work — never an
  // empty stub, the voice runtime reports a tool that returns nothing as a SUCCESS.
  const addNote = async (args: { text: string; color?: string }) => {
    const noteId = nanoid();
    await eventCallback(noteAddedEvent.dataCreator({ ...idArgs, noteId, ...args }));
    return `Pinned note ${noteId}.`;
  };
  return {
    [`add_note_${base}`]: {
      description: `Pin a new sticky note on "${identifier.instanceName}". Returns the note's id.`,
      parameters: z.object({ text: z.string().min(1).max(2000), color: z.enum(["butter", "rose", "mint", "sky", "lilac"]).optional() }),
      execute: addNote,
      onClient: addNote,
    },
    // A tool that calls one of YOUR OPS is derived from it: its parameters ARE the
    // op's declared input (ops.ts), and `onClient` is set for you.
    [`read_notes_${base}`]: opTool(ops, "read-notes", {
      pluginId: "sticky-notes",
      nodeId: identifier.nodeId,
      description: `Read every note on "${identifier.instanceName}" with the ids the other tools take.`,
      readOnly: true,
      publicSafe: true,
      say: (s: Pick<StickyNotesData, "notes">) => describeNotes(s),
    }),
  };
},
```

## The two surfaces

- **`execute`** runs on the server: chat, agents, MCP, the workbench's `call_app_tool`.
- **`onClient`** runs in the browser: WebRTC voice, WebMCP. Events dispatch there too, and
  `callPluginOp` rides the session. Setting `onClient = execute` for every tool is the simplest
  correct form; the checks refuse an empty `onClient: () => {}` stub because it makes an agent
  claim work it never did.

## Flags

- `readOnly: true` — a read-scoped token may call it.
- `publicSafe: true` — safe to expose on a public storefront (no writes, no private data).

## Honest results

A tool result is what the model believes happened. Return what you **did**, and refuse what you
could not do: an update to an id that is not on the wall says "No note X — nothing changed", not
"updated". When a check needs server truth (an op) and it is unavailable, say so
("could not verify the id here"). Name what the caller should do next; say where ids come from.

## Server truth from a tool — derive the tool from its op

A tool that must read or change the real state (not the caller's cache) calls one of your
**plugin ops** (docs/06). Declare what the op takes ONCE, in a file both halves import:

```ts
// ops.ts — imported by server.ts AND app.tsx
import { z } from "zod";
import { defineOps } from "esoul-sdk";
export const ops = defineOps({
  "read-notes": z.object({}),
  "add-product": z.object({
    name: z.string().min(1).max(80),
    priceCents: z.number().int().min(0),
    imageUrl: z.string().url().optional().describe("An https picture, from generateAppImage"),
  }),
});
```

Then `handleOp(ops, name, run)` in server.ts parses with it, and `opTool(ops, name, {...})` in
app.tsx mints the tool from it: the tool's `parameters` **are** the op's input, strict, with the
`.describe()` text as the model's parameter help; `say(result, input)` turns the op's answer into
the honest sentence; `then(result, input)` is for anything else the tool does afterwards (an
`eventCallback` onto the fold — prefer `ctx.emit` in the op). `readOnly` / `publicSafe` pass through.

Why it is not optional: `z.object` **strips** what it has no field for. The night an op accepted
`imageUrl` and its hand-written tool did not, the tool answered "Added Earl Grey" and the product
had no picture — nothing failed, the op's own test was green. With a derived tool the field cannot
be missing; with `handleOp` a field the op does not take is refused as `invalid`, naming it and the
fields the op does take, so an agent corrects itself instead of being told the work was done.

`check_app` runs a scanner over every op and tool: an op whose handler is not wrapped in
`handleOp`, or a derived tool naming an op the manifest does not declare, is a red gate with the
fix in the message.

Under the hood a derived tool calls `callPluginOp(pluginId, op, nodeId, args)` — never
`fetch("/api/v1/…")` itself (token-gated, it refuses the tool). In the workbench an op runs over
the preview's own in-memory tables, so a tool that calls one works there too. A failed call throws
a `PluginCallError` carrying the platform's `code` (`forbidden`, `login-required`, `invalid`, …):
pass it to `useSignInWall().raise(err)` in the UI and a `login-required` becomes the sign-in wall
instead of an error. Relay any other error's message; never swallow it.

## Calling other apps

From the UI: `useWorkspaceTools()` (docs/05). From server code: `callWorkspaceTool` (docs/06).
Both are gated by the manifest's `workspaceTools` grants, `"<applicationType>:<tool base>"`, and
both stay inside the app's own workspace.

## Describing the app to agents

`getStateDescription(state)` is what an agent reads about your app every turn. Compact, truthful,
with ids. And **never claim a count or an emptiness you could not read**:

```ts
getStateDescription: (state) => {
  const notLoaded = incompleteStateNotice({ title: "Sticky notes", instanceName: state?.instanceName, shape: { lists: { notes: state?.notes } } });
  if (notLoaded) return notLoaded;   // a MISSING collection means the state did not load; [] is real
  return describeNotes(state);
},
```



==============================================================================
# 5. The UI

```tsx
"use client";
import React from "react";
import { useAppCanEdit, usePluginEventDispatch, useWorkspaceTools } from "esoul-sdk/react";
import { noteAddedEvent, type StickyNotesData } from "../app";

export function StickyNotesUi({ state }: { state: StickyNotesData }) {
  const dispatch = usePluginEventDispatch();   // the ONLY way to change state
  const canEdit = useAppCanEdit();             // readers of a share see the app and cannot mutate
  const tools = useWorkspaceTools(state);      // other apps' tools, per the manifest's grants
  // …
}
```

- Props are `{ state }`: the folded state, live. You never fetch it.
- `dispatch(noteAddedEvent.dataCreator({ …identifier fields from state, …args }))` is a write.
  Disable writes when `!canEdit`.
- The schema module (`app.tsx`) is **never** `"use client"`; the UI module is. The schema imports
  the UI, not the other way around (it closes a module cycle).

## Theme

Read the `.dark` class on `<html>`, and **observe it** (the person toggles at runtime):

```ts
function useIsDark() {
  const [dark, setDark] = React.useState(false);
  React.useEffect(() => {
    const read = () => setDark(document.documentElement.classList.contains("dark"));
    read();
    const mo = new MutationObserver(read);
    mo.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
    return () => mo.disconnect();
  }, []);
  return dark;
}
```

Keep one palette object per app with `LIGHT` and `DARK` of the same shape. Light is warm sepia
(`#faf6f0` / `#efe7d8` / `#e8dfd0`, brown text). Dark is translucent data surfaces over the frame's
gradient, with editors, dialogs, popovers and sticky headers **opaque**.

## Responsive

The app renders inside the platform frame at any size: a desktop window, a maximised canvas, a
390 px phone.

- The root fills its frame: `width:100%; height:100%; overflow:hidden`, a flex column.
- Chrome rows `flexShrink:0`; the content area `flex:1; minHeight:0` with its own scroll.
- Measure the VISIBLE scroller for layout decisions (column counts), never a large inner canvas;
  re-measure on resize.
- Toolbars wrap; labels collapse on narrow widths; nothing needs a horizontal page scroll.
- Touch is first-class: tap to act (never double-tap), `touch-action: manipulation`, larger hit
  targets on `(pointer: coarse)`.
- Custom clickables are real buttons: `role="button"`, `tabIndex={0}`, Enter and Space,
  `aria-label` on icon-only controls. Distinct icons for distinct actions. Status is never
  colour-only.
- Popovers and menus portal to `document.body` with a solid backing.
- An empty state that says what to do first, in the app's own voice.

`look_at_app` in the workbench screenshots desktop-light, desktop-dark and phone-light. Open the
images; a phone shot with a horizontal scrollbar is a bug.

## Live data from a background task

```tsx
import { usePluginRealtime } from "esoul-sdk/react";
import { kickPluginTask } from "esoul-sdk";
import { stopwatchChannel } from "./channel";

const live = usePluginRealtime<{ runId: string; elapsedMs: number; serverNow: number }>({
  channel: stopwatchChannel,
  workspaceId: state.workspaceId,
  nodeId: state.nodeId,
  topics: stopwatchChannel.topicNames,
});
// live.latestData → { topic: "tick", data: {...} } — the newest message, or null.
// live.data       → everything received this mount, oldest first.

const start = () =>
  kickPluginTask({
    applicationType: "plugin_stopwatch",
    taskName: "tick",
    identifier: state,
    data: { runId, kickedAt: Date.now() },
  });
```

The subscription is per instance and read-only; the token the platform mints for it carries only
the topics your schema declares. Treat messages as nudges: what the UI must still show after a
refresh comes from state, so a task that changes anything durable dispatches an event as well
(docs/07 has the whole loop, including the stop).

## Cross-app from the UI

```ts
const { call, listApps, available } = useWorkspaceTools(state);
await call({ appType: "spreadsheet", tool: "add_row", args: { cells: { When: new Date().toISOString() } } });
```

In the workbench this works through the board's own tab, so you can test it before install;
installed, only the grants in `plugin.json` `workspaceTools` are allowed. Declare each as
`"<applicationType>:<tool base name>"`.

## Files

`usePluginWorkspaceFiles()`, `usePluginFileUpload()`, `useFileSources()`, `useFileSourceEntries()`
— docs/09.

## Character

The platform is built as craft: a sticky-notes wall is linen and paper with a gummed strip, not a
grid of yellow rectangles. Derive any randomness from stable ids, never `Math.random()` in
render, so nothing twitches between renders. Motion is brief and respects reduced-motion.

## Pictures

`generateAppImage` is one call: it generates, brings the bytes to web weight and
returns an **https URL** to store on your own row.

```ts
const pic = await generateAppImage(ctx, {
  name: product.sku ?? product.id,
  prompt: "A small dish of loose-leaf black tea beside a glass cup of amber tea.",
  // THE SAME style for every picture in the app. This is what makes a shelf
  // look photographed on one table instead of bought from a library.
  style: "On warm oatmeal linen, soft window light from the left, shallow depth of field.",
  shape: "square",                       // or "wide" for a hero, "tall"
});
if (pic.ok) await db.product.update({ where: { id }, data: { imageUrl: pic.url } });
```

It costs real money, so keep it behind an op only the owner may call. A
workbench refuses it on purpose — a preview that billed on every hot reload
would be a bad surprise, and one that returned a fake URL a worse one.

**Draw the empty case first.** A generated picture is the second version of a
screen; the first is the one with no picture at all, which is what every app
looks like on the day it is installed. An `aspect-square` box with a small
inline SVG pattern and the thing's icon reads as "not photographed yet"; a grey
rectangle reads as broken. Fix the aspect ratio in both branches and nothing
moves when a photograph arrives.



==============================================================================
# 6. The server half — `server.ts`

Only if you declare `ops`, `webhooks` or `fileProviders`. Marked `"server-only"`, it never
reaches the client graph.

```ts
import "server-only";
import { handleOp } from "esoul-sdk";
import { readAppState, callWorkspaceTool, emitPluginAppEvent, type PluginOpContext, type PluginServerModule, type PluginWebhookContext } from "esoul-sdk/server";
import { ops, type OpIn } from "./ops";                             // what every op TAKES, declared once

async function readNotes(ctx: PluginOpContext) {
  const app = await readAppState(ctx.nodeId);                    // folded to head; null = no such app
  if (!app) throw new Error(`no app ${ctx.nodeId}`);
  const s = app.state as Partial<StickyNotesData>;
  if (!Array.isArray(s.notes)) throw new Error("the wall did not fold (notes missing)");   // MISSING ≠ empty
  return { notes: s.notes };
}

// The handler receives PARSED input — never `ctx.args` by hand.
async function addProduct(ctx: PluginOpContext, input: OpIn<"add-product">) { /* … */ }

export const pluginServer: PluginServerModule = {
  ops: {
    "read-notes": handleOp(ops, "read-notes", readNotes),
    "add-product": handleOp(ops, "add-product", addProduct),
  },
  webhooks: { inbound: async (ctx: PluginWebhookContext) => { /* verify, validate, kick a task, ACK */ } },
};
```

## Ops — server truth for a tool

`POST /api/plugins/<id>/op/<name>` with `{ nodeId, args }`. The route resolves the caller
(`ctx.viewer`), checks the op's declared access level and that `nodeId` is an instance of THIS
plugin's type, then calls your handler with `ctx = { nodeId, workspaceId, viewer, args, notify,
emit, apps, … }`.

**Declare what an op takes once** — `defineOps` in `ops.ts` (docs/04) — and wrap the handler
with `handleOp(ops, name, run)`: `run(ctx, input)` gets the parsed input, and a call carrying a
field the op does not take is refused as **`invalid`** with the field named ("add-product: does
not take "colour" — it takes name, priceCents, imageUrl"). The tool in app.tsx is derived from
the same declaration (`opTool`), so the two cannot drift; the UI sends the same fields. A missing
body is `{}`, so an op declared `z.object({})` is callable with no arguments.

Ops are for reads that must be true now and for actions that need a credential or the app's
tables; they must be idempotent (a tool call can be retried).

## Webhooks — push in

`POST /api/plugins/<id>/webhook/<hook>`. **Verify first** (a shared secret with
`timingSafeEqual`), validate the body, then **ACK and hand the work to a task** through
`ctx.sendInngestEvent("<applicationType>/<task>", payload)`. Never do the work in the webhook: a
sender retries, a request has a time limit, and a task is durable. Give every push an
idempotency key and derive the event's id from it (`deterministicReducerId`), so a redelivery
folds to one item. Fail CLOSED when no secret is configured.

## `readAppState(nodeId)`

One app, folded to head: `{ nodeId, workspaceId, applicationType, foldedSeq, state }`, or `null`
when absent. Use it for your own instance and, with care, for other apps in the same workspace.
Never a raw database read — the import wall refuses `prisma` and the state column lags the log.

## `callWorkspaceTool` — orchestrate other apps

```ts
const r = await callWorkspaceTool({
  pluginId: "research-graph", nodeId: ctx.nodeId,
  appType: "my_computer", tool: "claude_task",
  args: { prompt: "Summarise the three papers in ~/reading", cwd: "~/reading" },
});
// r = { ok, text }
```

Gated exactly like the UI: the manifest must declare `"my_computer:claude_task"` in
`workspaceTools`, and the target must live in the calling app's own workspace. Name a specific
instance with `targetNodeId` instead of `appType`. For a `my_computer`, prefer `computer(ctx, nodeId)`
below, which parses the answers and knows the waits. This is how an app runs a `my_computer`
(commands, Claude Code sessions, results), fills a spreadsheet from a job, or books a calendar.

## `computer(ctx, machineNodeId)` — a paired machine, from server code

A `my_computer` app is the analyst's own computer. Its tools answer JSON in a string, every
command is approval-gated unless the owner set the app to Auto, a wait is at most 55 s and a
command at most 900 s, and a long task comes back "running" with a commandId to ask for again.
`computer` holds all of that:

```ts
import { computer } from "esoul-sdk/server";

const box = computer(ctx, machineNodeId);                 // an op's or a task's ctx; the machine by nodeId
const st  = await box.status();                           // { paired, online, hostname, autonomy, pendingApproval }
const r   = await box.run("cd ~/proj && make", { timeoutSeconds: 600 });   // → { status, commandId, exitCode, stdout, stderr, message }
if (r.status === "pending_approval") say(r.message);     // the owner approves in the My Computer app
const done = await box.runToEnd("python -m stream.replay …", { deadlineMs: 300_000 });   // asks again until terminal
const said = await box.claudeToEnd("Read README.md; list the run steps", { cwd: "~/proj", permissionMode: "no_writes" });   // → { answer, sessionId, costUsd }
const file = await box.readFile("/home/me/brief.md");     // → { ok, text }
const api  = await box.fetchJson("http://localhost:8600/health");   // a service on the MACHINE's localhost — curl runs there
```

**Big answers.** The My Computer app keeps at most 8,000 characters of a command's output
(`OUTPUT_LIMIT`). For anything big — a database query, a series to plot, a log — do the heavy part
ON the machine and print only what the app needs:

```ts
const r = await box.python<{ rows: number; series: [number, number][] }>(`
import json, sqlite3
db = sqlite3.connect("file:/data/telemetry.db?mode=ro", uri=True)
rows = db.execute("SELECT ts, v FROM readings WHERE device=? ORDER BY ts", (143,)).fetchall()
print(json.dumps({"rows": len(rows), "series": rows[-200:]}))
`, { python: "/opt/conda/envs/lab/bin/python" });
if (!r.ok) return r.error;          // a cut answer says so (`truncated`), never parses half
```

`runJson(command)` is the same for any command that prints one JSON document. Pass parameters in
as a JSON literal (`json.loads(${JSON.stringify(JSON.stringify(params))})`): a JSON string is a
valid Python string literal, so nothing a caller sends can break the script. A pending approval
comes back with a plain `message` (`APPROVAL_WAIT`) you can show a person as it is.

## Charts — `chartSvg` and `renderChartImage`

`chartSvg(spec)` (from `esoul-sdk`, pure) draws stacked time panels sharing one x axis, with
markers across every panel: `{ title, xStart, xEnd, xTicks, panels: [{ label, unit, kind: "line"|"step",
points, impossible: { below: -20 } }], markers: [{ x, label, tone: "page"|"warn"|… }], now, theme }`.
Words are glyph outlines, so it renders the same in the browser and on a server; impossible
readings sit on a red rail with a count instead of flattening the scale; lines break across gaps.
Use it on the app's screen (`dangerouslySetInnerHTML`) AND in a tool's answer:

```ts
const img = await renderChartImage(ctx, { name: `c${customer}-${event}`, svg });   // esoul-sdk/server
return { text, ...(img.url ? { imageUrls: [img.url] } : img.base64 ? { images: [img.base64] } : {}) };
```

Installed, `url` is a stored PNG the chat shows full size and the model can read; in a Forge box it
is `base64` (nowhere to store a file). Stream times are naive local strings — `naiveMinutes(ts)` /
`naiveTicks(start, end)` keep them off `new Date()`, which would shift them by the viewer's timezone.

Declare the four grants: `"my_computer:computer_status"`, `"my_computer:run_on_computer"`,
`"my_computer:get_computer_result"`, `"my_computer:claude_task"`. Ops answer within a request, so
in an op leave `waitForApproval` off and report a pending approval; put long waits in a task
(`runToEnd` / `claudeToEnd` with a `deadlineMs`, one step per wait). A workspace may hold several
machines: name the one you mean, never "the first".

## In a Forge box

`callWorkspaceTool`, `computer` and `readAppState` of another app all reach the owner's REAL
workspace from a box — through the Forge board's tab, the same credential-free path the UI uses
(the box holds no secret; the board runs the call behind its own wall). Two things follow:
the preview must be open ON THE BOARD (a headless `look_at_app` cannot carry a call — you get
"no board is connected to this preview", not a wrong answer); and the manifest's `workspaceTools`
is enforced in the box with the same sentence production uses, so a call you never declared fails
in the Forge exactly as it would after install.

## `ctx.emit` — record on your OWN timeline

Anything a person can cause through your UI, an agent can cause through a tool,
and the server is the only place that sees both. So when a change belongs on the
fold, the OP records it, not the screen:

```ts
async function addProduct(ctx: PluginOpContext) {
  const p = await (await pluginDb<ShopDb>(ctx)).product.create({ data: … });
  // Derive the change id. A retry — and the UI's own optimistic dispatch of the
  // same fact — is then a no-op rather than a second bump.
  await ctx.emit("plugin_shop_catalogue_changed", { changeId: `product:${p.id}`, tags: p.tags });
  return { id: p.id };
}
```

It is your own event (`eventName` from your schema), it goes through the
platform's spine — your `dataCreator` mints, your reducer folds, triggers fire —
and it lands on THIS instance.

**The failure this exists to prevent.** An app offered its departments from the
fold and recorded them only in the owner's add-product FORM. Stocked by its
agent instead, it therefore had a full catalogue and no departments at all,
live on a customer's site. If a fact belongs on the timeline, the op is where
it is written — a screen is one of its callers, never the only one.

Treat it as a courtesy around a completed write, like `notify`: catch a failure
and report it, rather than letting it undo a product that exists.

## `emitPluginAppEvent`

Emit ANOTHER app's own events (its `dataCreator` shape) into the same workspace, actor-stamped as
your plugin — for mirroring into a native app whose processors you cannot call directly.
Same-workspace only.

## Connections in server code

`ctx.cloudConnectionId` is the instance's bound connection; resolve it with
`getPluginConnectionCredentials(connectionId, pluginId)` (docs/08).

## What server code may import

Only `esoul-sdk` / `esoul-sdk/server`, relative files, `server-only`, and npm packages the
platform already depends on. No `prisma`, no `node:*`, no `next`, no internals — the import wall
(docs/11) refuses them, and a reviewer relies on that.

## Routes — the backend your app brings with it

An op answers one JSON question. A **route** owns the whole Response: it can stream, return
bytes, set headers, and run for as long as one request lasts (minutes on Fluid compute). It is
how a user app gets what a native app gets from its API routes — mounted on install at
`GET|POST /api/plugins/<id>/route/<name>?nodeId=<instance>`.

```json
// plugin.json
"routes": ["ticks"]
```

```ts
// server.ts
import { readAppState, sseStream, type PluginServerModule } from "esoul-sdk/server";

export const pluginServer: PluginServerModule = {
  routes: {
    // A clock streamed straight from the server: one Node process, no scheduler hops.
    ticks: async (ctx) =>
      sseStream(async (send, signal) => {
        while (!signal.aborted) {
          const app = await readAppState(ctx.nodeId);           // the fold, ~0.3 s here
          const cur = (app?.state as { current?: { runId: string; kickedAt: number } }).current;
          if (cur) send("tick", { runId: cur.runId, elapsedMs: Date.now() - cur.kickedAt });
          await new Promise((r) => setTimeout(r, 1000));
        }
      }, { signal: ctx.request.signal }),
  },
};
```

```tsx
// ui — the session rides along; a public-share viewer can watch, not write.
import { pluginRouteUrl } from "esoul-sdk";
const es = new EventSource(pluginRouteUrl("stopwatch", "ticks", state.nodeId));
es.addEventListener("tick", (e) => setTick(JSON.parse((e as MessageEvent).data)));
```

The platform resolves the instance, the enabled flag and the caller's access before your
handler runs — READ to reach the route at all, and `ctx.canWrite` says whether the caller may
mutate (check that one boolean before you `emitPluginAppEvent`). An internal caller
(`INTERNAL_TOOL_SECRET`) is a writer.

### A door for a machine — `mintRouteToken`

A route is READ-gated, and a laptop process has no session. Declare the route `token` and mint
its key in the op that starts the machine's process:

```json
"routes": { "ingest": { "access": "token" } }
```

```ts
const grant = await mintRouteToken(ctx, { route: "ingest", ttlSeconds: 7 * 86_400, label: "laptop bridge" });
// grant.url is the route on the origin THIS op was called on — a box's preview domain in the
// Forge, the platform after install — so the machine reaches the same app either way.
await computer(ctx, machineNodeId).run(`python bridge.py --push '${grant.url}' --token '${grant.token}'`);
```

The machine sends `Authorization: Bearer <token>`. Inside the route `ctx.viewer.kind` is
`internal` (your app calling itself) and `ctx.viewer.viewerIds[0]` is `token:<label>`, so a row
can record which machine wrote it. The token is stateless, signed by the platform, bound to one
route of one instance, and expires (30 days at most) — expiry is the only revocation, so keep it
short. Inside the handler use `pluginDb(ctx)` for your tables and `emitPluginAppEvent` (target =
your own nodeId) for your timeline; a route context has no `emit` of its own.

**Route or task?** A route lives exactly as long as a request: close the tab and the clock in
the example stops streaming — nothing durable happened unless the handler wrote events. A
task (docs/07) survives everything and costs seconds per hop. The stopwatch ships both and
records which one drove each run; measure before you choose.



==============================================================================
# 7. Background tasks — durable work

Tasks are declared on the schema and run on the platform's durable executor (Inngest). Each task
becomes an event `<applicationType>/<taskName>`.

```ts
tasks: [
  {
    taskName: "ingest",
    description: "Fold one pushed item — idempotent by pushId.",
    concurrency: { limit: 1, scope: "per-app" },
    handler: async (ctx) => {
      await ctx.step.run("fold-pushed-item", async () => {
        const { text, pushId } = ctx.eventData ?? {};
        if (typeof text !== "string" || typeof pushId !== "string") return;
        await ctx.dispatchEvent("plugin_todo_add_item", { itemId: `push-${pushId}`, text: text.trim(), createdAt: Date.now() });
      });
    },
  },
],
```

## The context

- `ctx.identifier` — workspaceId, nodeId, applicationType, instanceName.
- `ctx.eventData` — the kick's payload.
- `ctx.step` — the durable step API; `await ctx.step.run("name", fn)` memoises `fn`'s result.
- `ctx.getState()` — the app's state, fresh.
- `ctx.dispatchEvent(eventName, eventData)` — through the full pipeline (append, fold, watermark),
  using YOUR processors, so a task's mutation is identical to a tap's.
- `ctx.notify(topic, data)` — publish on the app's realtime channel (see *Live tasks* below). A
  nudge, never the truth: the UI hears it while mounted; a refresh only sees the timeline.
- `ctx.logger`.

## The replay model — read this twice

The executor **re-runs your handler from the top** after every step boundary, replacing each
completed `step.run` with its cached result. Anything outside a `step.run` runs again on every
replay. So: **every side effect lives inside a `step.run`** — a dispatch, a fetch, an emit — or
it fires N+1 times. `nanoid()` and `Date.now()` outside a step produce different values per
replay; mint them inside. Step names are unique per logical operation; loops include the index.

## How a task gets kicked

- **From a webhook**: `ctx.sendInngestEvent("<applicationType>/<task>", payload)` (docs/06).
- **From the browser or a tool**: list the task in `kickableTasks`, then
  `kickPluginTask({ applicationType, taskName, identifier, data })` (from `esoul-sdk`; works in
  a component and in a tool's `execute`). The platform's send-event route allows only listed
  tasks and stamps nothing — `data` is exactly what `ctx.eventData` sees.
- **In a Forge preview** the same call runs the task IN the preview's dev server, behind the
  same front door, over the workbench store — `getState`, `dispatchEvent`, `notify` and
  `callWorkspaceTool` / `computer` / `readAppState` of other apps all work (the last three through
  the Forge board's tab, so the preview must be open on the board). What the preview does not give
  you: durability across a process death, retries, a scheduler, and the platform's `if` on
  `waitForEvent` (the preview matches the event name and your node). `step.run` is not a
  memoization barrier there either — an unwrapped side effect that would fire N+1 times on the
  platform fires once in a box.


## Task or route? Measured (2026-09-10, the stopwatch)

| | a server route (docs/06) | a durable task |
|---|---|---|
| kick → first tick | 0.2 s | 2–15 s |
| stop landed → run finished | 0.8 s | 0.7–12 s |
| tick cadence | 1 s | ~3 s |
| a fold read | 60 ms | ~2.8 s |
| survives the tab closing | no — nothing outlives the request | yes — everything |
| survives a deploy / crash | no | yes |

Every step of a task is a round trip through the scheduler into the platform's function.
So: **the user's time is measured on the user's clock** (the two presses), the task is the
durable witness, and the route is the live view. Ship both when the difference matters, and
record which one drove each run — the timeline is the measurement. Never make a task keep
sub-second time; never make a route keep a promise past its request.

## Concurrency

`concurrency: { limit, scope: "per-app" | "global" }`. Keep the limit small; a parked wait holds
no slot.

## Testing tasks

Unit-test the handler with a fake `ctx` (`step.run` that just calls the function, a recording
`dispatchEvent`), and assert idempotency by running it twice with the same `eventData` (docs/10).



==============================================================================
# 8. Connections and OAuth — tokens the platform holds for you

An app that talks to an outside service declares the connection; the person grants it once in
Account settings; the platform stores the tokens sealed and refreshes them; your code asks for a
credential when it needs one. **Secrets never live in your package**: the manifest names
environment variables, not values.

```json
"connections": [{
  "key": "github", "kind": "oauth2", "label": "GitHub",
  "authorizeUrl": "https://github.com/login/oauth/authorize",
  "tokenUrl": "https://github.com/login/oauth/access_token",
  "oauthScopes": ["repo"],
  "clientIdEnv": "GITHUB_CLIENT_ID", "clientSecretEnv": "GITHUB_CLIENT_SECRET"
}]
```

`kind: "apiKey"` instead declares `headerNames` — the header names the app will send; the person
pastes the key once.

## Using a credential

```ts
import { getPluginConnectionCredentials } from "esoul-sdk/server";

async function listRepos(ctx: PluginOpContext) {
  if (!ctx.cloudConnectionId) throw new Error("connect GitHub in Account settings first");
  const cred = await getPluginConnectionCredentials(ctx.cloudConnectionId, "my-app");
  if (cred.kind !== "oauth2") throw new Error("expected an OAuth connection");
  const r = await fetch("https://api.github.com/user/repos", { headers: { Authorization: `Bearer ${cred.accessToken}` } });
  // …
}
```

The platform unseals, checks expiry and refreshes with the stored refresh token before handing
you `accessToken`. Never log it, never put it in an event, never return it from a tool.

An instance is **bound** to one connection (`ctx.cloudConnectionId`); a person with two GitHub
accounts adds two instances. File providers you contribute receive `ctx.connectionId` per active
connection (docs/09).

## The platform's own connections

The platform already holds the person's Google connection for its mail and calendar apps. Reusing
it from an app ("the mail app needs the Google tokens") is designed and not yet built: the
manifest would declare `platformConnections` with scopes, the person would consent per app, and
the SDK would hand out a token scoped to those scopes. Until then an app declares its own Google
OAuth connection with the platform's client id and secret named as env vars, and the person
grants it once more.



==============================================================================
# 9. Files — workspace files, Drive, your own provider

Files are a consented surface. The manifest declares what the app may read:

```json
"fileSources": { "workspace": "read", "providers": ["google-drive"] }
```

- `workspace: "read" | "readwrite"` — the workspace's own files.
- `providers` — provider keys the app may browse (the person's connected sources).
- Absent = no file access at all. The person sees the declaration at install.

## In the UI

`usePluginWorkspaceFiles()` (the workspace's files, live), `usePluginFileUpload()` (upload as the
person), `useFileSources(workspaceId)` and `useFileSourceEntries(source, path)` for browsing
sources with entries.

## In server code

`pluginFiles(ctx)` / `filesForOp(ctx)` give a `FilesApi`: list a source, read a file (capped at
`FILE_READ_CAP_BYTES`), resolve a `FileRef`. Source ids are `"workspace"`, `"google-drive"`,
`"local:<mountId>"`, or your own provider's key; `parseSourceId` splits them.

## Contributing a provider

```json
"fileProviders": [{ "key": "dropbox", "connectionKey": "dropbox", "label": "Dropbox" }]
```

`server.ts` exports `fileProviders: { dropbox: impl }` where `impl` implements
`PluginFileProviderImpl` (`list`, `read`, …). The host derives one mount per ACTIVE connection
of `connectionKey` and calls you with `ctx.connectionId` set; resolve the credential with
`getPluginConnectionCredentials`. Reads are capped; errors are typed (`FileSourceError`,
`FileSourceErrorKind`) so the UI can say "not found" or "too large" instead of failing blank.



==============================================================================
# 10. Testing — the fold contract as tests

The workbench runs your tests with jest (`test_app`, seconds; `check_app` adds the platform's
suites and a type check). Write the contract the reviewer wants to trust:

```ts
import { noteAddedEvent, noteTextSetEvent, pluginSchema, type StickyNotesData } from "./app";

const IDENT = { workspaceId: "ws1", nodeId: "node1", applicationType: "plugin_sticky_notes", instanceName: "My wall" };
const fresh = (): StickyNotesData => pluginSchema.stateCreator(IDENT as any, {} as any);
const apply = (def: any, s: StickyNotesData, args: Record<string, any> = {}) => def.processor(s, def.dataCreator({ ...IDENT, ...args }));

it("starts empty, adds exactly what it says, and a replay is a no-op", () => {
  expect(fresh().notes).toEqual([]);
  const once = apply(noteAddedEvent, fresh(), { noteId: "n1", text: "milk" });
  const ev = noteAddedEvent.dataCreator({ ...IDENT, noteId: "n1", text: "milk" });
  const twice = noteAddedEvent.processor(noteAddedEvent.processor(fresh(), ev), ev);
  expect(once.notes.map((n) => n.id)).toEqual(["n1"]);
  expect(twice).toEqual(noteAddedEvent.processor(fresh(), ev));
});

it("refuses a payload it cannot trust, and ignores an unknown id", () => {
  expect(noteAddedEvent.processor(fresh(), { eventData: { noteId: 42 } } as any)).toEqual(fresh());
  expect(apply(noteTextSetEvent, fresh(), { noteId: "ghost", text: "x" })).toEqual(fresh());
});

it("no processor mints an id or a time: two folds of one log are identical", () => {
  const log = [noteAddedEvent.dataCreator({ ...IDENT, noteId: "n1", text: "a" }), noteTextSetEvent.dataCreator({ ...IDENT, noteId: "n1", text: "b" })];
  const fold = () => log.reduce((s, e) => (e.eventName === noteAddedEvent.eventName ? noteAddedEvent : noteTextSetEvent).processor(s, e as any), fresh());
  expect(fold()).toEqual(fold());
});

it("the description never claims an emptiness it could not read", () => {
  expect(pluginSchema.getStateDescription({ ...IDENT } as any)).toMatch(/not loaded|incomplete/i);
  expect(pluginSchema.getStateDescription(fresh())).toContain("No notes yet");
});
```

A UI test renders once with a fixed state and checks the visible chrome and the empty state.
Keep suites fast; they run beside the live preview on the same machine.

## Tools

Call `execute` with a recording `eventCallback` and assert the events it emitted and the text it
returned — including the refusal text for a bad id.

**Ops and their tools are checked for you.** `check_app` runs a scanner over every plugin in
the box: an op whose handler is not `handleOp(ops, …)` (it reads `ctx.args` by hand, so a tool
could lag it) and a derived tool that names an op the manifest does not declare are both red, with
the fix in the message. `runOp` throws the same `invalid` refusal a live call would for an
undeclared field — `await expect(runOp(pluginServer, "add-product", { viewer, args: { colour: "x" } })).rejects.toMatchObject({ code: "invalid" })`.

## Tasks

Fake the context: `step.run` that calls its function, a recording `dispatchEvent`. Run the
handler twice with the same `eventData`; the second run must not add a second item.

## Connections

`esoul-sdk/testing` ships `startMockOAuth()` — a local OAuth server that issues, refreshes and
revokes tokens, so a connection-backed op can be tested end to end without a real provider.

## The fold corpus

Once an app has real history, record it (`scripts/plugins/record-fold-corpus.mjs` in the
platform) and commit `fold-corpus.json` + hashes. From then on the checks refuse a change that
alters what history MEANS — the strongest protection an app with data can have. Re-recording is
declaring a migration; say so in the changelog.

## What runs in a Forge preview (parity)

Since 2026-09-10 a workbench keeps an in-process stand-in for the database, Inngest and the
broker, so before the app is installed:

| | in the preview | not in the preview |
|---|---|---|
| events, tools (`call_app_tool`), `read_app_state` | yes | |
| tasks (`kickPluginTask`, from the UI or a tool) | yes — same `ctx`, in-process | durability, retries, a scheduler; `waitForEvent`'s `if` (name + node only) |
| ops (`callPluginOp`, `readAppState`) | yes — on a preview-only route, over the preview's fold | a real database |
| routes (`pluginRouteUrl` → a preview-only route) | yes — the caller is a writer | auth (the sandbox is single-tenant) |
| realtime (`ctx.notify` → `usePluginRealtime`) | yes — polled from the store | the broker |
| `emitPluginAppEvent` from a route or op | yes | cross-app targets outside the preview |

The board is told which of these a box has: the preview announces `tasks`, `ops`, `routes`,
`realtime` in its greeting once the store answers, and the frame reloads itself when the
server side is a newer build than the bundle it runs.



==============================================================================
# 11. Shipping — submit, review, release, install

## The path

1. **Build and test in the Forge workbench** (docs/01). No repository access is needed: the
   platform clones with its own installation for the app arm.
2. **Submit** with `ship_app`. It refuses unless every check is green, commits, pushes the app's
   branch and opens (or updates) a pull request labelled `user-app` and `submitted-by:<you>`.
   The board shows "submitted — awaiting review". An app id already on the base branch under
   another author is refused before a pull request exists — pick another id.
3. **The owner reviews** the diff on GitHub and approves.
4. **One script releases it**: checks the pull request out cleanly, runs the import wall, the
   sync, your tests and the type check, merges any dependencies you declared onto your branch so
   the reviewer sees them, squash-merges, waits for the production deploy, grants you the
   entitlement, and tells your board "released — add it to a workspace".
5. **Add it** in any of your workspaces from the app picker, by chat (`add_app`), or over MCP.
   Its tools are live in chat, voice, agents and MCP; its events ride the timeline.

## The import wall

Review is the security boundary — your server code will run with the platform's credentials.
Review is only tractable if nothing can reach around the SDK, so the wall refuses at check time,
at sync and at release:

- allowed: `esoul-sdk` (and `/server`, `/react`, `/testing`), relative files in your folder,
  `server-only`, npm packages the platform already depends on;
- refused: `@/…` platform internals, `node:*` and the node built-ins, `prisma`, `next`,
  `inngest`, the Vercel SDKs, and any package not in the platform's `package.json`.

Need something the SDK lacks? Ask for it in the SDK — that is the review's pressure valve. Need
an npm package? Declare it (below); it becomes a visible line in the pull request.

## Declaring npm dependencies

Put a `package.json` in your app folder with only `dependencies`:

```json
{ "dependencies": { "date-fns": "^4.1.0" } }
```

The release script merges them into the platform's `package.json`, updates the lockfile on your
branch, and pushes that commit onto your pull request before merging. In the workbench the
package is not yet installed until that happens; a later platform version merges declared
dependencies at `open`.

## Entitlement — your app on your instance

A released app is available to **its submitter** and to no one else until the owner grants
everyone (`--public`). A plugin that predates entitlements stays public. The picker only offers
what you may add; the add path enforces it.

## Versions and upgrades

Bump `version` on every submission. Events are forever: a change that alters what an existing
event MEANS rewrites every workspace's history on the next fold — record a fold corpus (docs/10)
so the checks catch it, and treat such a change as a migration with its own events.

## Dev and deployed are symmetric

In the workbench your app can already call other apps (through the board's tab) and its own
tools can be called (`call_app_tool`) before install. Installed, the same calls go through the
manifest's grants, and the platform mints your tools natively. Exposing an in-development app's
tools to the whole workspace — so chat could call them before install — is the next step on
the platform's side (the board minting proxy tools per app under construction).

## Cost and lifetime

A workbench dies ten minutes after the last touch (a tool call, or a board tab watching it).
`close_workbench` stops it at once. Files and commits persist; reopening resumes and updates the
platform it runs on.



==============================================================================
# 12. Rules and failures — every rule with the failure that earned it

| Rule | The failure it prevents |
|---|---|
| Processors are pure and idempotent | a replay duplicated items; a scrub showed a state that never existed |
| Ids and timestamps are minted in `dataCreator`, never in a processor | two folds of one log disagreed; snapshots diverged from replay |
| A processor refuses a bad payload instead of throwing | one malformed webhook took a whole workspace view down |
| Whole-replace and burst events carry a collapse key per entity and field | fifty timeline rows per sentence; two notes edited together merged into one |
| `reconstructStateFromEventLog: true` | an app hydrated from a stale column and lost its last edits |
| `getStateDescription` uses `incompleteStateNotice`; missing ≠ empty | an agent "saw" an empty list, invited a duplicate, and the notebook crashed on a throw |
| Every tool has a real `onClient` (`= execute`) | the voice agent said "added the note" while nothing ran — an empty stub reads as success |
| Tool results say what was DONE, refuse what was not | "updated" for an id that did not exist |
| Server truth through a plugin op, never `fetch("/api/v1/…")` | the token-gated route refused the tool with "not readable" |
| Cross-app calls only through `useWorkspaceTools` / `callWorkspaceTool` with manifest grants | an app could act on any app in the workspace unseen |
| Server code reaches the platform only through `esoul-sdk/server` (the import wall) | a demo plugin read the database directly; a reviewer would have had to read every line |
| Webhooks verify, validate, kick a task, ACK; idempotent by the sender's key | a retried push duplicated an item; a slow webhook timed out mid-work |
| Every task side effect lives in a `step.run` | a dispatch fired four times, once per replay |
| No per-app crons; `pollTasks` at 5-minute granularity | Inngest function ids and the plan's concurrency cap |
| Secrets are env-variable NAMES in the manifest, never values | a client secret in a package that becomes public |
| The schema module is never `"use client"` | the schema became a server proxy and every processor vanished at build |
| The UI never imports the store or the registry, only `esoul-sdk/react` | a module cycle that crashed the client on load |
| Root fills the frame, `overflow:hidden`, content `flex:1 minHeight:0` | the whole app scrolled sideways on a phone |
| Measure the visible scroller, not the canvas | a 2400 px canvas laid new notes off the right edge |
| Observe `.dark` at runtime | wrong colours until the person clicked something |
| Bound every collection and string | an app that could no longer be folded |
| Bump the manifest version; record a fold corpus once there is data | a "small" event change rewrote every workspace's history |

## Symptom → rule

- "It works in the preview and nothing changes after install" → the tool only had `onClient`, or
  the event was `Server`-typed and dispatched from the UI.
- "The timeline has hundreds of rows for one edit" → no collapse key.
- "State reverts after reload" → `reconstructStateFromEventLog` unset, or a processor minted ids.
- "check_app is red on registry" → the manifest failed validation or the import wall refused a
  file; the detail names it.
- "My tool needs the database" → declare the tables in the manifest's `db` and write an op over
  `pluginDb(ctx)`; call it with `callPluginOp`. The workbench runs it over in-memory tables with
  the same rules, so VIEW AS shows what each person may read.



==============================================================================
# 13 · People and access

Your app will be used by people with different relationships to it: the person who installed it,
the people they invited, and everyone else. This page is how the platform tells them apart, and
how you say what each may do — without writing a single access check.

## The viewer

Every seam of your app receives a `viewer`. The UI reads it with `useViewer()`; the server gets
`ctx.viewer` on an op, a route and a tool; a task carries `ctx.kickedBy` (who asked) and runs as
your app's own code.

```ts
viewer.kind      // "owner" | "member" | "visitor" | "anonymous" | "agent" | "internal"
viewer.userId    // the account, or null
viewer.role      // YOUR app's word for them (see below)
viewer.canWrite  // may they change the workspace at all
```

- **owner** — whose workspace this is.
- **member** — someone the owner invited, with edit or read-only access.
- **visitor** — signed in, but not in the workspace: someone on a share link.
- **anonymous** — not signed in. Still has an identity (a cookie) so rows they create can be
  theirs, and stay theirs after they sign in.
- **agent** — a run acting for one of the above. It gains nothing: everything about what it may
  see comes from the person it acts for.
- **internal** — your own app's server code (a task, the install job). Rules do not apply to it;
  scope still does.

The platform resolves this. An app cannot supply, widen or forge one — the import wall keeps you
from reading a cookie or a header to invent an identity.

## Who they actually are

A viewer is an identity, not a person's details. When your app needs the details — a name to put
on a confirmation, an address to send one to — ask for the CALLER's own account:

```ts
import { viewerProfile } from "esoul-sdk/server";

const me = await viewerProfile(ctx.viewer);   // { userId, email, name, picture } | null
```

Server only, one database read, and only ever about the caller: there is no argument for whose
profile to read, so an app cannot look somebody up. It is null for anyone without an account,
which is the same thing `requires: "account"` is about. Use it to pre-fill a form rather than
asking a signed-in person to type what the platform already knows.

In a test, `fakeViewer("visitor", { userId: "u_ada", role: "requester", name: "Ada", email: "ada@x.test" })`
is what `viewerProfile` answers for that viewer; a fake viewer with no name or email answers null.
No test ever reaches a database for it.

## Roles — your app's own vocabulary

The platform's words are about a workspace. Your app's words are about your app. A help desk has
requesters and agents; a library has readers and librarians; a clinic has patients and staff.

```json
"roles": {
  "vocabulary": ["requester", "agent", "supervisor"],
  "default": {
    "owner": "supervisor",
    "member-edit": "agent",
    "member-readonly": "agent",
    "visitor": "requester",
    "anonymous": "requester",
    "agent": "inherit"
  },
  "describe": {
    "requester": "raises tickets and sees their own",
    "agent": "answers every ticket; never the billing notes",
    "supervisor": "everything, including who handled what"
  }
}
```

`default` maps the platform's kinds onto your words. Two sentinels are the platform's, not yours:
`inherit` (an agent takes the role of whoever it acts for) and `none` (this app has no word for
that kind of caller, so no rule can match them — the right answer when a stranger has no business
here at all).

**The workspace owner can override it per person, per app.** In workspace sharing, an app that
declares a vocabulary gets a picker showing your words and your descriptions. So one colleague is
an `agent` in the help desk and another a `supervisor`, in the same workspace, and everyone
outside is a `requester` whether or not they are signed in.

A role is a WORD, never a permission. It decides what your rules mean. Whether someone may write
the workspace at all is still the platform's answer: a read-only collaborator you call `agent`
still cannot write.

## Access levels — nothing opens by default

Every op, route and task is `write` unless you say otherwise: the owner and editing members only.

```json
"ops": {
  "list-public-articles": { "access": "public" },
  "raise-ticket":         { "access": "public", "requires": "account" },
  "my-tickets":           { "access": "public", "requires": "account" },
  "close-ticket":         {}
},
"routes": { "queue-stream": { "access": "read" } },
"kickableTasks": { "escalate": { "access": "write" } }
```

| level | who reaches it |
|---|---|
| `write` (default) | the owner and members who may edit |
| `read` | anyone who can SEE the workspace, including read-only members |
| `public` | anyone holding the app's share link, with no workspace access at all |
| `public` + `requires: "account"` | the same, but they must be signed in |
| `token` (routes only) | a MACHINE holding a token your app minted — no session, no share |

**`read` is not "outsiders".** It means workspace members. Someone on a share link is reached with
`public`. Getting this wrong is the commonest mistake: an app that declares "my own records" as
`read` refuses the very people it was written for.

**`requires: "account"` is the sign-in wall.** Without it an anonymous caller gets `forbidden`,
which a UI can only render as an error. With it they get `login-required` and a way back, and
`useSignInWall()` turns it into a wall:

```tsx
const wall = useSignInWall();
try { await op("raise-ticket", args); }
catch (e) { wall.raise(e); }   // login-required → the wall; anything else rethrows
```

Every `public` door is listed on the install card, by name, before anyone installs your app.

**`token` is the door for a machine.** A laptop pushing readings, a device phoning home, a
process on a server of yours: none of them has a person's session. Declare the route
`{ "access": "token" }`, mint the token in server code behind an op only the owner reaches, and
hand the machine the `url` and `token` together (docs/06, "A door for a machine"). A session
never opens a `token` route, however privileged.

## What a refusal looks like

One shape everywhere, with a code your UI can act on:

| code | status | means |
|---|---|---|
| `forbidden` | 403 | the rules say no, and signing in would not change it |
| `login-required` | 401 | sign in and try again; `signInPath` says where |
| `not-bound` | 409 | a slot this app needs is not filled yet |
| `rate-limited` | 429 | too many calls at a public door |
| `invalid` | 400 | the call itself is malformed |

In a workbench the refusal also carries `detail`, written for YOU: which rule refused and what to
change. It is never returned in production, and never contains the caller's data.

## Seeing it before anyone installs

A workbench has **VIEW AS**: a switcher for the platform's kinds — owner, member, read-only
member, two different visitors, anonymous, agent. Your app resolves each one through your own
`roles`. Two visitors on purpose: the question worth asking is not "does a person see their own
record" but "does the OTHER one see it".

`look_at_app` takes the same personas, so you can photograph the screen each of them gets — the
one screen an author can otherwise never see, because the author is always the owner.

## Who has an account: ASK, never assume

`viewer.signedIn` is the platform's guess from THIS PAGE's capabilities. On a
shared link it can disagree with the session your ops actually run under — so
an app that gates its reads on it shows a signed-in person an empty basket and
a sign-in wall while the server is holding their order. That is a real bug, seen
on a real shop.

So never gate a read. Attempt it, and let the refusal answer:

```tsx
const wall = useSignInWall();

const load = useCallback(() => {
  // `ask` runs the call whatever this page believes, and hands back `null`
  // when the SERVER says there is no account — which also raises the wall.
  wall.ask<Cart>(() => callPluginOp(PLUGIN_ID, "view-cart", nodeId)).then((c) => c && setCart(c));
}, [wall, nodeId]);
```

`wall.serverSays` is `null` until the server answers, then `"account"` or
`"no-account"`. Use `viewer.signedIn` for WORDING if you like (it saves a
flicker) and `serverSays` for anything that hides a screen. And if you hold
data the server already gave you — lines in a basket — show it: a wall over a
full basket is never right.

## Linking a person to what is theirs — attributes

`owner: "creator"` answers "whose row is this?" when the person wrote it: a customer's order is
theirs because they placed it. It cannot answer when somebody else wrote the row on their behalf —
a machine pushing a pool's readings, an import, the company's own staff. Customer 204's faults were
raised by the lab's rules, not by customer 204.

For that, the manifest declares what a grant may say about a person, **typed**, and a rule scopes a
role by it:

```json
"roles": {
  "vocabulary": ["guest", "customer", "company"],
  "default": { "owner": "company", "member-edit": "company", "member-readonly": "company", "visitor": "guest", "anonymous": "guest", "agent": "inherit" },
  "attributes": { "customer": "int" }
},
"db": {
  "Fault": {
    "fields": { "customer": "int", "ts": "string", "event": "string" },
    "indexes": [["customer", "ts"]],
    "rules": {
      "read": ["company", { "role": "customer", "where": { "customer": "viewer.customer" } }],
      "write": ["company"]
    }
  }
}
```

The company links a person to a number, once, by email:

```ts
await setAppRole(ctx, { email: "ada@example.com", role: "customer", attrs: { customer: "204" } });
```

From then on, on every read and write, in both database clients:

- **Reads** — Ada's `db.fault.findMany()` returns customer 204's rows; `count`, `aggregate` and
  `groupBy` count only those. The company, holding a plain grant on the same rule, sees every row.
- **Absent, not refused** — another customer's row is `null` from `findUnique` and "no row" from an
  update. Ada never learns that an id exists.
- **Creates land inside the scope** — a create that omits `customer` gets 204; a create that names
  205 is refused as `forbidden`, naming the field.
- **Missing attribute** — a `customer` who was never linked sees nothing and may write nothing. A
  scope never falls back to everything.
- **Typed at the boundary** — `"204"` becomes `204` on `ctx.viewer.attrs.customer`; `"two"` is
  refused when the owner types it (`"customer" must be a whole number — got "two"`) and is never
  stored.

The rules of a scope, each refused at build time with the key path:

| | |
|---|---|
| `role` | a word from your vocabulary — `anyone`, `creator` and the rest cannot be scoped |
| `where` | at least one field; every field declared **and indexed** (a scope is on every read); a value, a list of values, or `viewer.<attribute>` |
| `viewer.<attribute>` | declared in `roles.attributes` as `string`, `int` or `boolean` |
| alternatives | a rule may not hold `creator` beside a scoped role, or scope one role twice — both would mean OR, and a scope narrows by AND; merge the `where`, or split the rule |

`useViewer().attrs` carries the typed attributes to the browser for wording ("Customer 204") —
never for deciding.

**Why a rule and not a composed role.** A composed role (below) is the owner's narrowing, made at
runtime on top of what the manifest allows. Which customer a person may see is *your app's*
invariant: it must hold in every install without the owner doing anything, and a `customer` without
a number must see nothing — which a role that narrows a word already allowed everything cannot promise.

**Realtime.** A `role:customer` topic is ONE channel for every customer. Address a customer's
messages to their accounts (`ctx.notify(topic, data, { to: { viewerIds } })`), never to the role.

In the Forge, VIEW AS gives every persona one field per declared attribute:
`look_at_app viewer: "visitor-a?customer=204"` shows customer 204's screen.

## Roles the owner composes — a packer who sees only what is being prepared

The vocabulary is the developer's. A business is not: a shop owner wants a "packer" who sees only
the orders being prepared, never the customer's note, and may mark them shipped — and no developer
was there when they decided it. So the manifest declares an ENVELOPE, and the owner composes roles
inside it at runtime. The platform enforces the composition in every read, write and op.

```json
"roles": {
  "vocabulary": ["customer", "staff", "owner"],
  "custom": {
    "attributes": ["branch"],
    "models": {
      "Order": { "where": ["status", "branch"], "hide": ["note"], "update": { "fields": ["note"], "transitions": "status" } }
    },
    "ops": ["set-order-status", "fulfil-order"]
  }
},
"ops": { "set-order-status": { "access": ["staff", "owner"] } }
```

The envelope is the ceiling: which fields of which models a composed role may be **scoped by**
(`where` — they must be indexed), which it may be **denied** (`hide`), which it may be **allowed
to change** (`update.fields`), whose **transitions** it may be handed, which **surfaces** it may
call, which per-person **attributes** a grant may carry. Nothing outside it can be composed.

A composed role stands on a base word — every rule naming that word still applies — and can only
take away:

```ts
await defineAppRole(ctx, {
  name: "packer", base: "staff", describe: "packs what is being prepared",
  models: { Order: { where: { status: ["preparing"], branch: "viewer.branch" }, hide: ["note"], update: { transitions: { preparing: ["shipped"] } } } },
  ops: ["set-order-status"],
});
await setAppRole(ctx, { email: "sam@example.com", role: "packer", attrs: { branch: "prague" } });
```

Sam then opens the shop as `staff` with the narrowing on top: `db.order.findMany()` returns only
orders in `preparing` in Prague with `note` read as null; `update({ status: "refunded" })` is
refused by name ("this role may move status from preparing to shipped"); an order that leaves
`preparing` leaves Sam's list; and `refund`, which the role was not handed, is refused at the door.
A role scoped by an attribute Sam was never given sees nothing — not everything.

`ctx.viewer.role` is still the base word (`staff`), `ctx.viewer.customRole` is `"packer"`, and
the browser's `useViewer()` carries `customRole` and a `can` summary (ops, hidden fields, moves)
for hiding buttons — never for deciding: every call is decided again on the server.
`listAppRoles(ctx)` returns the people, the words, the composed roles and the envelope, so a
screen can offer the owner exactly what may be composed.

**`access: ["staff", "owner"]`** on an op, route or task opens it to the app's own words —
a granted outsider holding `staff` gets in, a workspace editor the owner never named does not,
the owner always does. Until this existed a desk op declared `write` refused everyone the owner
had granted by email, because a grant changes the app's word, never the platform's capabilities.

In the Forge, every role the owner composes in the box appears in the VIEW AS strip, so the
packer's screen can be looked at before anyone is one.

## Giving one person access to one app

An owner can hand another esoul account one of YOUR role words, by email:

```ts
const r = await setAppRole(ctx, { email: "helper@example.com", role: "staff" });
if (!r.ok) throw new Error(r.error);      // "no esoul account has that email"
const { people, roles } = await listAppRoles(ctx);
```

The platform does the deciding: only the app's owner may call it, the email is
resolved once against a real (non-guest) account, and the role must be one your
manifest declares. The grant lands on this instance's own timeline, so it can be
read back, explained and scrubbed. Next time that person opens the app,
`ctx.viewer.role` is the word you gave them and your `db` rules do the rest —
it does not make them a writer of the workspace, and it can never demote the
owner.



==============================================================================
# 14 · Your own tables

The fold (docs/03) is for what is shared, small and worth scrubbing. Records that belong to one
person, that grow without limit, and that must never revert because somebody scrubbed a timeline
are none of those. Those go in your app's own tables.

You declare them. The platform generates the schema, the typings and the rules, applies the
migration on install, and scopes every query. You never write a migration, an ORM, or a
`WHERE userId = …`.

## Declaring

```json
"db": {
  "Article": {
    "fields": { "title": "string", "body": "text", "published": "boolean=true" },
    "unique": [["title"]],
    "indexes": [["published"]],
    "rules": { "read": ["anyone"], "write": ["supervisor"] }
  },
  "Ticket": {
    "owner": "creator",
    "fields": { "status": "string=open", "subject": "string", "detail": "text", "article": "ref:Article?" },
    "indexes": [["status"], ["createdAt"]],
    "rules": {
      "read":   ["creator", "agent", "supervisor"],
      "create": { "roles": ["requester", "agent"], "requires": "account" },
      "update": { "roles": ["agent", "supervisor"], "creatorMay": ["detail"] },
      "delete": ["supervisor"]
    }
  },
  "ContactDetails": {
    "scope": "user",
    "sealed": ["phone"],
    "fields": { "label": "string", "phone": "string" }
  }
}
```

**Field types.** `string`, `text`, `int`, `float`, `boolean`, `datetime`, `json`, `ref:Model`.
A trailing `?` is optional; `=value` is a default; `[]` is a list. Platform columns (`id`,
`workspaceId`, `nodeId`, `ownerId`, `createdBy`, `createdAt`, `updatedAt`, `deletedAt`) are added
for you and may not be declared.

**Scope** decides what "this app's rows" means:

| scope | rows belong to | use it for |
|---|---|---|
| `instance` (default) | ONE app instance | this help desk's tickets |
| `workspace` | every instance in the workspace | something shared between apps |
| `user` | one person, across every instance | contact details that follow them |

**`owner: "creator"`** makes each row belong to whoever made it, which is what `creator` in a rule
matches against. It matches every id that person has acted under, so a record created before
signing in is still theirs afterwards.

**`sealed`** fields are encrypted at rest and readable only by the row's owner (and your app's own
internal code, which is how a background job can still use one). Anyone else reading a sealed
field gets null, not ciphertext.

## Rules

A rule names PRINCIPALS: `"anyone"`, `"creator"`, a role from your vocabulary, or `"apps"` (apps
bound to yours — see docs/16). The long form adds `requires: "account"` and `creatorMay`, which
lists the fields a row's creator may change even when they may not otherwise update it.

A role may be **scoped** to the rows it may reach:
`{ "role": "customer", "where": { "customer": "viewer.customer" } }` gives a customer only the rows
carrying the number their grant holds (`roles.attributes`, docs/13). Use it when rows are written
on someone's behalf; use `creator` when the person writes them. A scoped read adds conjuncts, a
scoped create is filled in or refused, a missing attribute grants nothing.

Rules are compiled once, at build time, and the SAME compiled artefact drives the in-memory client
your tests use, the Prisma client production uses, and the workbench. A rule that names a role
your app does not declare fails the build, with the key path.

## Using

```ts
import { pluginDb } from "esoul-sdk/server";
import type { HelpdeskDb } from "./.esoul/db";   // generated from your manifest

async function myTickets(ctx: PluginOpContext) {
  const db = await pluginDb<HelpdeskDb>(ctx);
  return db.ticket.findMany({ orderBy: { createdAt: "desc" }, take: 50 });
}
```

That is the whole access story. The same call returns one person's own tickets and an agent's
whole queue, because `ctx.viewer` is already in the client. There is no argument you could pass to
read someone else's rows: `workspaceId`, `nodeId` and `ownerId` are injected, and naming one in a
query is refused as `invalid` rather than quietly overridden.

Ordering and filtering are limited to the fields you indexed — an unindexed `orderBy` is a compile
error in your editor, not a slow query in production.

### The whole surface

Your generated type is the reference (open `.esoul/db.d.ts`), and this is all of it:

| | |
|---|---|
| read | `findMany` · `findFirst` · `findUnique({ where: { id } })` · `count` |
| summarise | `aggregate({ where?, _count, _sum, _avg, _min, _max })` · `groupBy({ by, … })` |
| write | `create` · `createMany` · `update({ where: { id }, data })` · `updateMany` · `upsert` · `delete` · `deleteMany` |
| together | `$transaction(fn)` |

`findMany` takes `where`, `orderBy`, `take`, `skip`, `cursor: { id }`. Every `where` — including
an `aggregate`'s — obeys the index wall above: a field you did not index is not a question, and
asking it is refused as `invalid` rather than answered slowly. **Count and sum in the database**
rather than paging rows to add them up in JavaScript; `groupBy` still returns only the rows this
viewer may read, so a customer's own total is their own and an aggregate is never a way around a
rule.

### Transactions

`$transaction` gives you the one guarantee a pair of writes cannot give itself: either both
happened, or neither did.

```ts
const order = await db.$transaction(async (tx) => {
  const written = await tx.order.create({ data: { totalCents, shipTo } });
  for (const l of lines) await tx.orderLine.create({ data: { order: written.id, ...l } });
  await tx.cartLine.deleteMany();   // the basket that made it
  return written;
});
```

Every gap between two writes is a real state somebody's session can end in. An order committed
and a basket emptied a moment later is not a detail: the moment in between is "paid for, still in
the basket", which is how a person buys the same thing twice. Put the writes that must be true
together in one call, and let a throw undo all of them.

Rules still apply inside, per statement, for the same viewer — a transaction is atomicity, never
elevation.

**What a transaction cannot hold.** A call into ANOTHER app (`ctx.apps.<slot>.call(…)`, an email,
a payment) is outside it by construction: the other app's writes are its own. For those, hold →
write → and **release on failure**, yourself:

```ts
const held = [];
try {
  for (const l of lines) { await stock.call("reserve_stock", l); held.push(l); }
  return await db.$transaction(…);
} catch (err) {
  for (const h of held) await stock.call("release_stock", h);   // never throws out of here
  throw err;
}
```

A reservation no order ever used is worse than a refusal: nothing marks it stale, so the shelf
reads empty while the goods sit there.

## Indexes for a catalogue

A plain group is a btree: equality, ranges, ordering. Two other kinds exist because a real
catalogue asks two questions a btree cannot answer.

```json
"indexes": [
  ["active", "createdAt"],
  { "fields": ["tags"], "kind": "contains" },
  { "fields": ["title"], "kind": "text" }
]
```

| kind | the field | what it lets you ask |
|---|---|---|
| `btree` (a plain group) | any | `where: { active: true }`, `orderBy: { createdAt: "desc" }` |
| `contains` | a LIST | `where: { tags: { has: "gifts" } }` |
| `text` | a string or text | `where: { title: { contains: "grey" } }` — **regardless of case** |

```ts
// A department and a search term, both as a WHERE — with a cursor, so the
// hundredth page costs what the first one did.
db.product.findMany({
  where: { active: true, tags: { has: dept }, title: { contains: term } },
  orderBy: { createdAt: "asc" },
  take: 24,
  cursor: after ? { id: after } : undefined,
});
```

`contains` ignores case in both clients (`ILIKE`, which a trigram index still serves), because a
search box that finds "Earl Grey" and not "earl grey" is broken in the quietest possible way — the
shopper just reads an empty shelf.

**A list takes one question and a scalar takes the others.** `{ tags: { has: … } }` on a list,
never a bare value and never `contains`; `{ title: { contains: … } }` on text, never `has`. Asking
the wrong one is refused as `invalid` with the right one named, because an empty result would look
like an empty shelf. (A refusal's `message` is the code; the sentence written for you is on
`err.detail`.)

Both of the new kinds become GIN indexes, and neither is led by the scope column — a GIN index
cannot be, so the database combines it with the scope index instead. That is the right plan, and
it is why `contains` and `text` cover exactly one field each.

**Why this matters more than it looks.** Without them, a shop with 100 000 products can only
return a page and filter it in the browser, so a department with nothing on the first page looks
empty. The declaration is the whole difference between a catalogue and a list.

## Migrations

On install the platform computes what your declaration means for the live database and applies it
in one transaction, recording it in a ledger. **Additive only.** Adding a table, a column or an
index is applied; changing a column's type, or adding a required column with no default, is
REFUSED with the column named, and the install does not proceed. A field you removed keeps its
column and its data — dropping it is a separate, deliberate act.

Uninstalling never drops a table. The rows are somebody's records.

## Testing

```ts
import { fakeViewer, memoryDb, runOp } from "esoul-sdk/testing";

const db = memoryDb(manifest);           // your rules, compiled from your own plugin.json
const ada = fakeViewer("visitor", { userId: "u_ada", role: "requester" });
const lin = fakeViewer("visitor", { userId: "u_lin", role: "requester" });

await runOp(pluginServer, "raise-ticket", { viewer: ada, args: TICKET, db: db.as(ada) });
expect(await db.as(lin).ticket.count()).toBe(0);
```

The in-memory client and the production one are proven equal by a differential test on every
build, so a rule you prove here is a rule the database keeps.



==============================================================================
# 15 · Realtime, and who hears it

Your app can push. A screen that is already open moves without anyone asking it to, which is the
difference between an application and a form.

Two declarations, both needed. The manifest says WHO hears each topic; the schema says what the
topics are and what rides on them.

```json
"channel": {
  "topics": {
    "notice":        { "description": "something everyone watching should see" },
    "ticket-status": { "audience": "viewer", "mayAddress": ["agent", "supervisor"] },
    "new-ticket":    { "audience": "role:agent", "mayAddress": ["requester", "agent", "supervisor"] }
  }
}
```

```ts
export const channel = definePluginChannel({
  applicationType: APP_TYPE,
  topics: {
    notice: { schema: z.object({ what: z.string() }) },
    "ticket-status": { schema: z.object({ ticketId: z.string(), status: z.string() }) },
    "new-ticket": { schema: z.object({ ticketId: z.string(), subject: z.string() }) },
  },
});
```

## Audiences

| `audience` | the channel |
|---|---|
| `all` (default) | one per instance — anyone watching the app |
| `viewer` | one per person — "your ticket was answered" |
| `role:<name>` | one per role — the queue everyone on duty watches |

The platform mints a token PER CHANNEL, and the browser asks for a KIND of channel, never for an
identifier. The server fills in whose channel that is from the viewer it resolved. So one person
cannot ask for another's channel: the id is not theirs to supply, and a role's channel is simply
not minted for someone outside that role. Nothing is filtered on arrival, because nothing wrong
ever arrives.

An app that declares no audiences keeps the single channel it always had.

## Sending

```ts
await ctx.notify("ticket-status", { ticketId, status });                                   // the CALLER's own channel
await ctx.notify("ticket-status", { ticketId, status }, { to: { viewerIds: [row.ownerId] } });
await ctx.notify("new-ticket",    { ticketId, subject }, { to: { role: "agent" } });
```

Unaddressed, a message goes where the topic says. Addressed, **aiming is a separate permission
from hearing**: a caller may address only ITSELF unless the topic's `mayAddress` names its role.
Your app's own tasks always may, which is why a follow-up task can tell the person who waited.

Two traps worth naming. Both cost the reference app a live drive, and both are easy to repeat:

- **Everyone who may DO the thing must be allowed to announce it.** An app that let two roles
  create a record but only one of them announce it refused the others their own action — by their
  own announcement. List every role your `create` rule allows.
- **A role channel is shared by everyone holding the role.** When a role is scoped by an attribute
  (a customer who sees only their own readings, docs/13), `role:customer` reaches every customer.
  Address those messages to the accounts they concern.
- **A courtesy must not undo a completed write.** The record is already in the table when you
  announce it. Catch a failed notify and report it; do not let it throw out of the op, or a person
  is told "forbidden" about something that exists and tries again.

## Listening

```tsx
const live = usePluginRealtime<{ ticketId?: string; status?: string }>({
  channel,
  workspaceId: state.workspaceId,
  nodeId: state.nodeId,
  topics: channel.topicNames,
  enabled: !!state.nodeId && viewer.signedIn,
});

useEffect(() => {
  if (live.latestData?.topic === "ticket-status") reload();
}, [live.latestData, reload]);
```

**Treat a message as a nudge, not as data.** Re-read through your op, so the rules decide what
comes back. A payload that carried the row would be a second way to learn about it, and only one
of them is checked.

In a workbench the preview shows a persona only what their channels would carry, so VIEW AS tells
you the truth: switch to the other visitor and the message is not there.



==============================================================================
# 16 · Bindings — leaning on another app

An app is an island until it can use another one. A booking app that wants real room availability
either keeps its own counts and guesses, or names one particular rooms app and is married to it.
Neither is what a person means by "use my room list for this".

So you declare a SLOT and the CONTRACT that must stand in it. The owner picks which app fills it.

## Declaring

The consumer:

```json
"uses": { "rooms": { "contract": "rooms/v1", "label": "Rooms", "optional": true } }
```

The provider:

```json
"provides": {
  "rooms/v1": { "tools": ["hold_room", "release_room"], "events": ["room_freed"], "models": ["Room"] }
}
```

A consumer must also fold the binding event, because the owner's choice lives on your app's own
timeline — a binding is CONSENT, and consent that is only a column cannot be scrubbed, explained
or audited:

```ts
export const bindingSetEvent = defineBindingEvent<BookingData>({ applicationType: APP_TYPE, slots: ["rooms"] });
// …and put it in the schema's `events`.
```

The build refuses an app that declares `uses` without it.

## What the platform checks, and when

At BIND time, once, loudly — never at call time in front of somebody using the app:

- The provider must claim the same contract NAME at a version at least as high. **Versions grow by
  adding**, so a `rooms/v2` provider fills a `rooms/v1` slot; the reverse is refused, because v1
  never heard of what v2 added. That rule is what lets your app keep working while its provider
  moves on.
- The provider must really HAVE what it claims: the tools it actually mints, the events its schema
  declares, the tables its `db` generates. A manifest is a claim, and a claim that is short is
  refused with the missing part named.

## Using

```ts
const rooms = ctx.apps?.rooms;          // absent when nothing is bound
if (rooms) {
  const held = await rooms.call("hold_room", { roomId, from, to });
  if (!held.ok) throw new Error(`cannot take this booking: ${held.text}`);
}
```

- **An unfilled slot is ABSENT**, not present and broken, so `ctx.apps.rooms?` reads as the
  question it is. An optional slot means your app still works without one; a required slot that is
  empty refuses at the seam with `not-bound`, which a UI should render as "connect one" rather
  than as an error.
- **A slot reaches the CONTRACT's tools, not the provider's toolkit.** A consumer bound through
  `rooms/v1` may hold a room and release it; it may not call the rooms app's `retire_room`, though
  it has one. The binding is consent to a contract.
- **The caller travels.** The provider's rules meet the actual person, so a visitor reaching the
  rooms app through your app sees what a visitor may see.
- **Writes never cross directly.** The provider's own tools and ops are the only writers of its
  tables, which is how a ledger keeps refusing to oversell no matter who asked.

## Being a good provider

A provider's whole value is usually one refusal: you cannot hold what is not free. Keep it in ONE
place — the app's own server — so it holds however the hold was asked for: through a binding, a
tool, or a person working in the app itself. That is what makes an app worth binding to. An app
that counted the same thing in its own fold could not make the promise, because two people can
read the same fold in the same instant.

Say no in your own words, too. A refusal that reads `cannot hold 2: only 1 free (1 free, 1 already
held)` reaches the consumer, and the consumer can put it in front of a person instead of a shrug.

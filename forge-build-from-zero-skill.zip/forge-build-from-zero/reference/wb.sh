#!/usr/bin/env bash
# Call one Forge workbench tool over the PAT — the MCP path a user's own Claude uses.
#   wb.sh <tool-suffix> '<json args>'      e.g. wb.sh open_workbench '{"pluginId":"sticky-notes"}'
set -uo pipefail
PAT="${ESOUL_PAT:?set ESOUL_PAT}"; BOARD="${ESOUL_BOARD:?set ESOUL_BOARD}"; BASE="${ESOUL_BASE:-https://externalsoul.com}"
TOOL="${1:?tool}"; ARGS="${2:-{\}}"
python3 -c "
import json,sys
print(json.dumps({'appId':'$BOARD','toolName':'${TOOL}_'+'${ESOUL_BOARD_NAME:-Forge}','arguments':json.loads(sys.argv[1])}))
" "$ARGS" > /tmp/wb-req.json
curl -sS -X POST -H "Authorization: Bearer $PAT" -H "Content-Type: application/json" \
  -H "Idempotency-Key: wb-$$-$(date +%s%N)" --data-binary @/tmp/wb-req.json \
  "$BASE/api/v1/app-tools" --max-time 800 | python3 -c "
import sys,json
try: d=json.load(sys.stdin)
except Exception as e: print('non-JSON reply'); raise SystemExit(1)
r=d.get('result', d)
print(r if isinstance(r,str) else json.dumps(r,indent=1)[:4000])"

# Lessons from building real apps in the Forge with the owner (2026-09-10 → 09-14)

Every line here was paid for. Read all of it once before your first write; come back to the
section that matches what just went wrong. "Stream Lab" is a replay/telemetry lab that drives
the owner's laptop over `computer()`; "the shop" is a 100 000-product store with staff roles.

## A. Working the Forge

- **The ⚠ paragraph is the loop.** Every changing or observing answer starts with the problems
  the running app hit since your last call, each with an id. It exists because the owner had to
  photograph "the bridge did not come up: " for the model. Read it first, fix it first, then
  `resolve_problem` with one honest line. Rows are keyed by identity (source|kind|where|message):
  a repeat is a count, not a new row; a recurrence after you resolved it is "↩ came back" — a fix
  that did not hold stays red.
- **`app_problems` lists two things**: the box's journal (restarts with the preview) and the
  BOARD's rows (outlive restarts). When the person says "I see five red rows", list, then resolve
  only what is fixed or was your own probe — and say which remain and why.
- **Park on issues before you stop.** `wait_for_workspace_event` on `forge/app_problem` with
  `{pluginId, origin:"frame"}` wakes you on a failure the PERSON hit; rows your own tool calls
  recorded are `origin:"tool"` and never wake you (you read them in the answer). Arming the same
  wait twice reuses it.
- **A near-miss tool name is healed, not refused** (`scrub-timeline` → `scrub_timeline`,
  `inspect_fault_Stream_Lab` → `inspect_fault`); the answer names the right one. Use the base
  name the app mints; never the op's hyphenated name; never the board suffix.
- **A box behind main cannot know a new host function.** "`X is not a function`" from an op is
  the box's clone lagging the platform: `open_workbench` merges main. The preview's boot script
  is the platform's: a boot change reaches a box only after close → open → preview.
- **A file that does not compile takes the whole preview down** — every route 500, including
  the store. The journal survives (it has its own route, `/internal/plugin-preview/problems`),
  and the dev-log watcher posts the compile error as a `dev` row once the door answers. The card
  on the board says the verdict first ("the dev server is not running (185 of 8403 MB used)") —
  "memory 185 MB" means NOTHING is running, not OOM; an "oom:" line with nothing after it is
  not an OOM. Errors listed are since the last start; a fixed error does not linger.
- **The person's tool loop and yours fight over one box.** If the chat is calling `preview_app`
  / `look_at_app` while you write files, the sandbox's shell stops answering ("non-JSON reply",
  "The workbench answered 502"). Stop your side, let one boot finish, then continue.
- **Never break the box a person is using.** A drive that writes `export const broken = ;` to
  prove the compile-error row, run on the box the owner had open, cost them fifteen minutes of
  "Booting the preview". Destructive drives go on a separate app or wait for an idle board.
- **Pipelines lie about exit codes** (`cmd | tail` exits as tail); every `grep … | tail` in a
  script whose answer you believe sets `pipefail`. A tool answer cut to 400 characters hid the
  `Preview:` line more than once — never truncate an answer you are about to act on.
- **A long job is a background job.** `check_app` takes minutes; `open_workbench` the first time
  takes minutes; a deploy after a push ~10 min. Run them in the background, poll for a terminal
  state, never sleep-chain.

## B. Access: two levels, hundreds of customers, done at the SDK level

- The manifest declares `roles` (`guest`, `customer`, `company`) and typed `roles.attributes`
  (`customer: "int"`); an admin links a customer id to an esoul email with a grant carrying that
  attribute; a rule principal is `{ role: "customer", where: { customer: "viewer.customer" } }`
  and the SDK compiles it into a narrowing every read and write passes through (`withinScope`
  on create fills or refuses; `mergeWhere` intersects; missing attr fails CLOSED).
- **Every field a rule or a `where` names must be indexed**, or the compiler refuses the manifest
  ("`event` has no index — a rule scoped by it would scan the table"). Query by the indexed
  pair and match the rest in memory when a lookup needs an unindexed field.
- Per-op `access` is the front door (`public` / `account` / a role list); the same decision runs
  in the box, so `look_at_app` as `visitor-a` really is the sign-in wall.
- VIEW AS is `?viewer=` on the preview URL and one header on every call the page makes; settle it
  at module load — a hook's first fetch leaves before your effect runs. A persona with a grant:
  `visitor-a?grant=customer&customer=143`. The access drive is written to FAIL if visitor-b
  sees visitor-a's row; keep it that way.
- Per-person state (a timeline, a cursor) is a `scope: "user"` table; a company-wide record is
  `instance`. Emit events only for the company; a customer's inspection is theirs and off the
  timeline.

## C. Data and ops

- Ops declared once: `defineOps` (zod, `.describe` everything) → `handleOp` → `opTool` with a
  `say`. Strict on both sides; the coherence scanner in `check_app` catches drift.
- The op owns the timeline: `ctx.emit` in the op, never a dispatch in the tool (it double-records
  with an id the reducer cannot dedupe). An op reads its bindings; folding the app to read one
  field is a paged rebuild paid by a stranger pressing "browse".
- Ask the database the person's question (a `where` over an indexed field, cursor paging);
  `db.$transaction` for an order and its basket; compensate a hold in ANOTHER app's ledger on
  any failure; a json column is a receipt, sales are a table (price at the time).
- **One row per moment.** "Show me" twice is the same inspection refreshed and brought to the
  top, not a list filling with the same line. Dedupe by the thing's identity (customer + at +
  kind), not by request.
- A range model: a customer's record is every stream of theirs across days; dedupe faults by
  id, keep the NEWEST bucket for a moment, count on the server (a partial sample said "no
  faults"), ticks from a `fault-days` op, coverage from `coveredDays`.
- Remember what the person chose in a one-row table (the lab's machine) so no caller — least of
  all the assistant — has to know a nodeId. An op given none reads it; none remembered is an
  honest refusal that says where to pick it.

## D. Machines, bridges, tokens, charts

- `computer(ctx, machineNodeId)`: `status()`, `run/runToEnd`, `readFile`, `fetchJson` against
  the machine's localhost, `python()/runJson()`; a `pending_approval` is a wait, not a failure;
  the machine keeps 8 000 characters of output — compute there, print little, and treat a cut
  answer as unknown. **A machine that does not answer is named as such** ("no app X in this
  workspace"), never blamed on the server it never asked.
- **A refusal never has an empty reason.** "the bridge did not come up: " with nothing after
  the colon was the first bug the owner photographed. When a start printed nothing: the
  command's own status (`exit 0 but the health check never answered in 20 s`), then the
  process's log tail (`.esoul/bridge.log`), then "log empty or missing". Prefer bringing the
  dependency up yourself ("Stream" starts the server first) to telling the person to do it.
- A route with `access: "token"` is a machine's door: `mintRouteToken(ctx, { route, ttlSeconds,
  label })` → the machine pushes to `url` with the bearer; `ctx.origin` names the origin the call
  arrived on, so a token minted in a box still dials a URL a laptop can reach.
- `chartSvg` + `renderChartImage`: text as glyph outlines (no fonts on a serverless
  rasteriser); in a box there is no blob store → `imageUrl` null → the chart lives on a page of
  the app and the answer says so. **Never hand base64 to a chat** — it prints as text.

## E. UI craft the owner asked for (Apple-grade, not templated)

- The order of cards follows the person's thought: choose (customer, days) at the top, then
  play; never make them translate. A two-handle window slider is "nice and informative": month
  ticks, the days that hold faults as marks, a footer with what is recorded ("5 of 15 days —
  the rest shows as gaps"), the words "4 days · streams in about 10 min at ×600".
- Dropdowns: white text on black when open in dark; `scale`, not `size`, for a Select prop (a
  native `<select size>` is a number of rows — the collision made every select a listbox).
- A player is a clock over a record: play/pause/seek/speed are re-anchorings; the head is a
  ceiling; "faults until now" is a binary search; the slider above and the playback below MUST
  show the same range (they did not, until the range became the model's).
- "Show me when it happened" means the SCREEN: switch to the Inspect page, open the newest
  inspection, chart FIRST then the words, scroll it into view, glow for two seconds. The tool's
  answer: one line, "on screen now" — never numbered instructions on where to click.
- A warning is for the person's problem; the app's own job is a muted note ("Streaming starts
  the server first, about 20 s"). Amber only when the last attempt actually failed, with the
  reason and a "Try again".
- Status pills fold to dots when the toolbar is narrow (measure the CONTAINER, not the
  viewport); a resolved row leads with what was done and the failure steps back beneath it; a
  badge shows a count only when it is not zero; past ten rows, group by place.
- Never `font: inherit` after `fontSize` in a style object — the shorthand resets it. Read the
  console, not the picture: a duplicate React key is invisible in a screenshot.

## F. Testing and proving

- Local jest is `isolatedModules`: types are inert. `check_app` on the box (sync + tests +
  platform suites + tsc) is the bar. A shared conformance suite runs the memory client AND
  Postgres; a source-scan test proves text, a drive proves behaviour — write both.
- Drive both surfaces (company and customer), read the console, count what happened vs what
  was asked ("no faults" from a partial sample; a dropped persona header). Prove a new gate
  BITES: inject the violation and watch it go red.
- Fixtures lie: a shared fake window lacking `from/to` for a new customer fails a test that has
  nothing to do with your change — assert the point (the machine was ASKED), not the fixture's
  accident.
- Fire real failures at the box and read the journal: a bad-typed input, a made-up machine, a
  dead kick — each must be a row with a useful message. Then resolve them as "my probe".

## G. Shipping and the platform's rhythm

- Work on main; commit as you go; run the full gate and a heap-capped `tsc` before a push;
  batch pushes (each is a 7–10 minute build). Never push while an install job is in flight.
- After a deploy that touches a task: `PUT /api/inngest` and read the answer; a task description
  over 255 characters fails the whole app sync while Vercel says READY.
- The app's own repo: Push on the board exports the app directory as one commit; the commit
  message carries the resolutions since the last push — write them as a changelog.
- Memory for the next session lives in the repo's docs and plans; the skill you are reading is
  the distilled version. When you learn something that cost you, write it down where the next
  model will read it BEFORE the next write.

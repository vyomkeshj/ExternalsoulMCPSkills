// DRIVE A FORGE PREVIEW AND REFUSE TO CALL IT CLEAN WHILE THE CONSOLE SAYS OTHERWISE.
//   node scripts/forge/page-check.mjs <preview url> <out.png> [steps.json]
// A screenshot proves layout, not health: this collects console errors and warnings, uncaught throws
// and failed or 4xx app op/route calls while it drives the page, and exits 1 on any (2026-09-14).
// steps: [{ "select": ["select[aria-label=\"Customer\"]", "143"] }, { "keys": ["<selector>", "ArrowRight", 7] },
//         { "click": "<selector>" }, { "wait": 3000 }, { "say": "<selector>" }] — append &viewer=<persona> to the url for VIEW AS.
// Exit 1 when the page logged a console error, threw, or an app call failed; every one is printed.
import puppeteer from "puppeteer-core";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const [url, out, stepsFile] = process.argv.slice(2);
const steps = stepsFile ? JSON.parse(fs.readFileSync(stepsFile, "utf8")) : [];
const chromeDir = path.join(os.homedir(), ".cache/puppeteer/chrome");
const chrome = fs.readdirSync(chromeDir).sort().map((d) => path.join(chromeDir, d, "chrome-linux64/chrome")).filter((p) => fs.existsSync(p)).pop();
const b = await puppeteer.launch({ executablePath: chrome, headless: true, args: ["--no-sandbox"] });
const p = await b.newPage();
await p.setViewport({ width: 1180, height: 1500, deviceScaleFactor: 1 });
await p.emulateMediaFeatures([{ name: "prefers-color-scheme", value: "dark" }]);
const problems = [];
p.on("console", (m) => {
  if (m.type() === "error" || m.type() === "warning") problems.push(`console.${m.type()}: ${m.text().slice(0, 300)}`);
});
p.on("pageerror", (e) => problems.push(`uncaught: ${String(e).slice(0, 300)}`));
p.on("requestfailed", (r) => { if (/\/internal\/plugin-preview\/(op|route)\//.test(r.url())) problems.push(`app call failed: ${r.url().split("/internal/plugin-preview/")[1]} — ${r.failure()?.errorText}`); });
p.on("response", async (r) => { if (/\/internal\/plugin-preview\/(op|route)\//.test(r.url()) && r.status() >= 400) problems.push(`app call ${r.status()}: ${r.url().split("/internal/plugin-preview/")[1]} ${(await r.text().catch(() => "")).slice(0, 200)}`); });
await p.goto(url, { waitUntil: "domcontentloaded", timeout: 120000 });
await p.evaluate(() => document.documentElement.classList.add("dark"));
await new Promise((r) => setTimeout(r, 6000));
for (const s of steps) {
  if (s.wait) await new Promise((r) => setTimeout(r, s.wait));
  if (s.select) { await p.waitForSelector(s.select[0], { timeout: 60000 }); await p.select(s.select[0], s.select[1]); await new Promise((r) => setTimeout(r, 2500)); }
  if (s.keys) { await p.focus(s.keys[0]); for (let i = 0; i < (s.keys[2] ?? 1); i++) await p.keyboard.press(s.keys[1]); await new Promise((r) => setTimeout(r, 800)); }
  if (s.click) { await p.click(s.click); await new Promise((r) => setTimeout(r, 1500)); }
  if (s.say) console.log(`— ${s.say}:`, await p.evaluate((sel) => (document.querySelector(sel)?.innerText ?? "(not on the page)").replace(/\n+/g, " | ").slice(0, 400), s.say));
}
await new Promise((r) => setTimeout(r, 2000));
// The Next dev overlay counts issues the console already showed; read its number as a cross-check.
const overlay = await p.evaluate(() => { const el = document.querySelector("nextjs-portal"); return el?.shadowRoot?.textContent?.match(/(\d+)\s*Issues?/)?.[1] ?? null; });
await p.screenshot({ path: out, fullPage: true });
await b.close();
const unique = [...new Set(problems)];
console.log(`next overlay issues: ${overlay ?? "none"}`);
if (unique.length) {
  console.log(`✗ ${unique.length} problem(s):`);
  for (const x of unique) console.log("  " + x);
  process.exit(1);
}
console.log("✓ no console errors, no throws, no failed app calls");

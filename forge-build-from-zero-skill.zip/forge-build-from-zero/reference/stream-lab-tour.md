# Stream Lab — the reference app that uses the SDK's breadth (a tour, not the source)

Stream Lab replays a pool-telemetry fleet from the analyst's own laptop, records faults with
its own rules, and answers "which customer had which fault, when — show me the sensors" for a
company and for each customer who may see only their own. It lives in a workbench (pluginId
`stream-lab`) and its files are the shape to copy.

```
plugin.json        roles guest/customer/company · attributes {customer:int} · db tables with
                   scoped rules and indexes · ops with access · routes (ingest: token) · channels
ops.ts             defineOps: every op's zod input, .describe on every field, the constants
server.ts          handleOp; helpers: box(ctx, machine), machineFor(ctx, given), isCompany(ctx),
                   db(ctx) = pluginDb<StreamLabDb>; the ingest route; the bridge's start command
machine-scripts.ts BRIDGE_PY (stdlib Python, written to the laptop), sensorWindowScript, auditScript
detectors.ts       the rules that judge five-minute buckets (pure, tested)
app.tsx            the schema: events (machineSet, serverChanged, play, live, inspected, note,
                   scrubbed), the fold, describe(), opTool per op with a `say`
player.ts          the clock over the record (pure); window-math.ts the slider's arithmetic (pure)
ui/stream-lab-ui.tsx  the shell, pages (Stream, Inspect, People, Brief, Machine, Log), the player
ui/stream-player.tsx  charts around the cursor; ui/window-slider.tsx; ui/select.tsx (scale, not size)
*.test.ts          runOp over a memory db with a fake machine; access.test.ts as five people
```

## Patterns worth lifting

- **Access in the manifest, enforced by the SDK.** `Fault.rules.read = ["company", { role:
  "customer", where: { customer: "viewer.customer" } }]`; `Timeline` is `scope: "user"`. Ops
  say `access: ["company"]` or `["company","customer"]`; `me` is public+account and answers who
  the viewer is and which customer they are linked to. `link-customer` is how the company maps
  a customer id to an esoul email (`setAppRole` with typed attrs).
- **The machine reports, the lab remembers, the lab reasons.** `select-machine` writes the one
  `Lab` row; `machineFor(ctx, input.machineNodeId)` defaults every machine op to it. The bridge on
  the laptop pushes buckets to the `ingest` route with a minted token; the rules stamp faults at
  the five minutes a threshold was crossed; `source: app | machine` keeps the machine's own
  verdicts beside the lab's.
- **Play starts what it needs.** `startPlay` checks the machine answers (named as such if not),
  brings the server and the bridge up through `serverStart` (which records the header's truth),
  then plays. A failure to start says the command's status and the bridge's log tail.
- **A player is a clock over a record.** `faults-range` / `samples-range` by customer across
  days, dedupe by id, newest bucket per moment; `scrub` moves a per-person timeline; `asOf`
  makes "until now" mean the scrubbed moment for `find_faults`/`fault_details`.
- **"Show me" shows.** `inspect_fault`: samples first, the machine's database otherwise; one
  inspection per (customer, at, kind); the newest inspection switches the app to Inspect, opens,
  scrolls the chart into view and glows; the answer is a line; the chart image is a URL or
  nothing — never bytes.
- **Everything has words.** `describe()` tells the assistant the machine, the server/bridge
  state, the last play, and the debugging journey (`whats_new` → `find_faults` → `fault_details`
  → `inspect_fault` → `audit_findings`); every refusal says what to do next.

## What to copy for a new app

Start from the scaffold `open_workbench` gives you, then bring in: the ops/handleOp/opTool
triangle; a `me` op; roles + attributes + scoped rules the moment two kinds of people exist;
a `Lab`-style row for anything the person chose once; pure modules for arithmetic with their
own tests; a `say` for every op that speaks like a colleague; and the access drive as five
people.

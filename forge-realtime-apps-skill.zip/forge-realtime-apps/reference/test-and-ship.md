# Testing a backend app in the Forge, then shipping it to its own repo and installing it

## 1. Unit tests that matter (`<id>.test.ts`, run with `test_app` in seconds)

- **Reducers idempotent by id**: apply the same event twice, assert one run.
- **The task with a fake ctx**: `step.run` calls the function, `getState` returns a scripted
  fold, `dispatchEvent`/`notify` record. Assert: `started` is the first dispatch, ticks arrive,
  `finished` follows `stopping`, an ABANDONED continuation hears no tick, and a slow read (60 ms)
  does not freeze the cadence (≥ 8 ticks where a chained loop manages one).
- **The face reads no clock**: `String(shownMs)` never contains `Date.now`, `performance.now`,
  `requestAnimationFrame`, `setInterval`, `setTimeout`.
- Every task `description` ≤ 255 characters.

Tests must not import `node:*` (the import wall runs over test files too). Read the module's
source through `String(fn)` if you need to assert on code.

## 2. Driving the backend in the workbench (board tools)

```
call_app_tool  {pluginId, tool:"start_stopwatch", args:{}}     → "Started run …" (the preview's runtime kicked)
read_app_state {pluginId}                                        → current.status "running" within a second
call_app_tool  {pluginId, tool:"read_stopwatch", args:{}}      → the op answered from the preview's fold
   (the frame shows ticks arriving — usePluginRealtime over the preview's realtime buffer)
call_app_tool  {pluginId, tool:"stop_stopwatch", args:{}}
read_app_state {pluginId}                                        → runs[0].status "finished", elapsedMs, taskElapsedMs
```

The route: the frame's own `EventSource`; from the box, `curl -N <preview>/internal/plugin-preview/route/<id>/<name>?nodeId=preview-<type>`.
The stream arm: set the source, start, hold the route open, stop — the route finishes the run.

**What to assert** (the platform's parity drive does exactly this for the stopwatch): the kick
answered; the fold shows the run; ticks accumulate in the buffer; the op answers; the stop folds;
the route streams; the stream run finishes. If any arm is refused, the message names why — a
box that predates a capability says so in its greeting; reopen it.

## 3. `check_app` — what the release will check

The import wall over every file, the registry sync (manifest ↔ schema agree: id, applicationType,
entry), the app's tests plus the platform's boundary suites, a type check. A `skipped` is not a
pass. Fix every red line before shipping.

## 4. Ship to the app's own repository (the board's REPOSITORY row)

- **create repo** — a form: name (seeded from the plugin id), private by default, description.
  The platform creates it on GitHub as the author and grants it to the esoul GitHub App. (The
  App needs its Administration: Read & write permission; if GitHub refuses, the row says so and
  offers *link an existing repo*.)
- **link existing** — `owner/repo` already granted to the author's esoul GitHub App.
- **Push** — exports ONLY the app directory as one commit on the repo's `main`, parented on the
  repo's current main, never forced: the repo holds `plugin.json`, `app.tsx`, `server.ts`, `ui/`,
  tests at its root. A main moved by hand is reported, not overwritten. The row shows
  "pushed abc1234 · 2 min ago · changes since" and lights when the app changed. Push after each
  round the user is happy with; the repo's history reads like the build.

The other path, `ship_app`, opens a pull request into the platform repository for apps that
belong there (the owner's own).

## 5. Installing it from a link (the owner, Settings → Apps)

Paste `https://github.com/<owner>/<repo>` (or `owner/repo@tag`) → **Inspect**: the platform
fetches the commit, checks the manifest, that the entry names the manifest's type, the import
wall over every file, undeclared dependencies, size — and shows what would be installed (tasks,
ops, routes, connections, workspace tools, files) with every refusal verbatim → **Install**. One
durable job: a one-line commit to the platform's `apps.lock.json` (the app is fetched at that
pinned commit by the build, never vendored), the build (about seven minutes; the invariant suite
runs — a schema/manifest mismatch fails here and the job puts the lock back itself), the
function sync's answer, the entitlement. The page follows every step.

Then `app_create(application_type="plugin_<type>", instance_name="…")` puts an instance on a
workspace; its tools are live in chat, voice, agents and MCP; its tasks run on the platform's
executor; its routes are mounted.

**Updates** are asked for, never watched: **Check for updates** compares the repo's head with
the pin → "N commits ahead · view changes" → **Update to <sha>** (the same job). **Uninstall**
removes the lock line and the installer's access; instances keep their timelines and reinstalling
brings them back. Nothing else in the platform's codebase moves for any of this.

## 6. The trust line, plainly

An installed app's server code runs inside the platform's process; its UI in every user's
browser. The wall stops it reaching platform internals; it does not stop `fetch` or a task that
spends credits. Install only what you (or your reviewers) have read. A workbench holds a
checkout of the platform — the person building in it can read platform source.

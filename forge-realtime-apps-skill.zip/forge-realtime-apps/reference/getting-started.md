# From zero to an installed app — what a person needs, and the two ways an app reaches a platform

## 1. What the author needs (once)

1. **An ExternalSoul account** and a workspace. The Forge is an app on that workspace:
   `app_create(application_type="forge", instance_name="Forge")` — one board builds one app.
2. **GitHub connected**: Account settings → GitHub → "Login with GitHub" installs the esoul
   GitHub App on the author's account (Contents + Pull requests; the App also needs its
   Administration permission granted by the operator for **create repo** from the board — until
   then the board offers *link an existing repo*). The connection is what the board's own-repo
   row uses; the workbench itself needs no repository access from the author (a friend without
   access to the platform repository gets the platform's own token for the app branch).
3. **A way to drive the board**: chat inside ExternalSoul, or MCP from Claude Desktop/Code:
   `pip install esoul[mcp]`, an access token from Sharing → Access Tokens (read+write, scoped to
   the workspace), and this skill. The board's tools are `<verb>_<board name>`; find the board
   with `list_workspaces`/`app_list`, confirm names with `get_app_tools(<board id>)`, call with
   `call_app_tool(<board id>, "<tool>", {…})`.

## 2. The loop (one board, one app)

`open_workbench` → read the scaffold → write `app.tsx`, `ui/`, `server.ts`, `plugin.json`,
tests → `preview_app` → `look_at_app` → drive it (`call_app_tool`, `read_app_state`, the route)
→ `test_app` → `check_app` → ship. Every step and its arguments are in the `forge-app-builder`
skill; what changes for an app with a backend is in `SKILL.md` and `task-and-realtime.md` /
`server-ops-and-routes.md` here. The person watches the board: the frame shows the live preview,
the panel every file, change, checkpoint and tool call.

## 3. Two ways an app reaches a platform

| | **Own repository → install by link** | **Pull request into the platform** |
|---|---|---|
| who | anyone with a Forge (a friend) | someone the owner lets into the platform repo |
| the board's tool | REPOSITORY row: create repo / link · **Open pull request** | `ship_app {pluginId, message}` |
| what moves | the app directory, as a PR from `forge/<app>` on the app's repo; merged on GitHub | a branch + PR on the platform repo, checks green |
| review | the owner reads the Inspect card in Settings → Apps | the owner reads the PR diff |
| landing | `apps.lock.json` gains ONE line; the build fetches the app at that commit | `merge_app` squash-merges the source in |
| after | entitlement to the installer; `app_create(application_type="plugin_<type>")` | production deploy; `app_create(...)` |
| updates | the author pushes; the owner presses **Check for updates** → **Update** | a new PR |
| removal | **Uninstall** (one line removed; instances keep their timelines) | a removal PR |
| codebase impact | none beyond the lock file | the app's source lives in the platform |

Both end the same way: the app is in the platform's build, its tools are live in chat, voice,
agents and MCP, its tasks run on the platform's executor, its routes are mounted, and it is
private to its installer until the entitlement is widened to everyone (`*`).

## 4. Install by link, step by step (the owner)

1. Settings → Apps → paste `https://github.com/<owner>/<repo>` (or `owner/repo@v1.2`).
2. **Inspect**: the platform fetches that commit and shows the app — name, version, type, tasks,
   ops, routes, connections, workspace tools, files — and every refusal in the gate's words
   (manifest schema and limits; the entry names its type; the import wall over every file;
   undeclared dependencies; size). Fix in the repo, push, inspect again.
3. **Install**: one durable job — a one-line lock commit, the platform build (about seven
   minutes; the invariant suite runs and a failing app reverts its own lock line), the function
   sync's answer, the entitlement. The page follows the steps; a failure says why, verbatim.
4. `app_create(application_type="plugin_<type>", instance_name="…")` on any workspace.
5. Later: **Check for updates** → **Update to <commit>** (the same job); **Uninstall**.

## 5. What to tell the person, honestly

- "installed" only with the lock commit and a READY build; "live" only after the sync answered.
- The trust line: an installed app's server code runs inside the platform's process and its UI in
  every user's browser; the wall keeps it out of platform internals, not off the internet.
  Install what you have read.
- A workbench holds a checkout of the platform: the author can read platform source there.

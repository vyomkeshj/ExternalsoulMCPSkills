# Every capability an app can declare — the manifest, field by field, with the code behind it

`plugin.json` is validated by the workbench's checks, at release, and by the install gate. What
you declare is what the person sees at install and what the platform mounts. Nothing undeclared
runs.

```json
{
  "manifestVersion": 1,
  "id": "sticky-notes",                       // lower-case, hyphens; = the folder name; never changes
  "name": "Sticky notes", "version": "0.1.0", "description": "one honest paragraph (≤ 500)",
  "applicationType": "plugin_sticky_notes",   // plugin_ + id with underscores; never changes; the schema must name it
  "entry": "app", "icon": "StickyNote",
  "ops": ["read-notes"], "routes": ["feed"], "webhooks": ["inbound"],
  "kickableTasks": ["sync"], "pollTasks": [{ "task": "refresh", "everyMinutes": 30 }],
  "workspaceTools": ["spreadsheet:add_row", "my_computer:claude_task"],
  "connections": [{ "key": "github", "kind": "oauth2", "label": "GitHub", "authorizeUrl": "…", "tokenUrl": "…", "oauthScopes": ["repo"], "clientIdEnv": "GITHUB_CLIENT_ID", "clientSecretEnv": "GITHUB_CLIENT_SECRET" }],
  "fileSources": { "workspace": "read", "providers": ["google-drive"] },
  "fileProviders": [{ "key": "dropbox", "connectionKey": "dropbox", "label": "Dropbox" }],
  "platformApi": { "min": "1.1.0" }
}
```

## 1. Events and state (`app.tsx`) — always

The heart of the contract (SDK docs/03). State is the fold of the app's events; the UI renders
the fold; a task, a tool and a tap all dispatch the same events through the same processors.

- `dataCreator` mints ids and stamps (`nanoid`, `Date.now`); a processor never does — a fold
  must replay to the same state.
- Processors are pure and idempotent by id; an unknown id is ignored, never invented.
- Bursts (typing, dragging) carry a **collapse key** namespaced by instance and item
  (`<app>:<noteId>:text`); whole-replace events must.
- Server-typed events (`EventTypes.Server`) are what only tasks/webhooks/routes emit.
- `reconstructStateFromEventLog: true` for anything that must survive a reload from the log.
- `getStateDescription(state)` is what agents read every turn: compact, with ids, and
  **never a count or an emptiness you could not read** — a missing collection means the state
  did not load; return `incompleteStateNotice(...)`, not "0 notes".

## 2. Tools (`toolkitCreator`) — always

Every UI action has a tool twin, minted per instance as `<verb>_<instance name>`. `execute`
runs on the server (chat, agents, MCP, the workbench's `call_app_tool`); `onClient` in the
browser (voice, WebMCP). `onClient = execute` is the simplest correct form — never an empty
stub (the voice runtime reports a tool that returns nothing as SUCCESS). Flags: `readOnly`
(a read-scoped token may call it), `publicSafe` (safe on a public storefront). Results are what
you DID; refuse what you could not do, with the next step named. Server truth comes from an op
(`callPluginOp`), never a self-fetch of `/api/v1`.

## 3. Cross-app calls — `workspaceTools`

The grant wall for calling OTHER apps' tools: `"<applicationType>:<tool base name>"`. From the
UI `useWorkspaceTools()`; from server code `callWorkspaceTool({ pluginId, nodeId, appType |
targetNodeId, tool, args })` → `{ ok, text }`. Same workspace only. This is how an app fills a
spreadsheet, books a calendar, or runs a `my_computer` Claude task. Absent = no cross-app access;
the person sees the grants at install and on the Inspect card.

## 4. Background tasks — `tasks` on the schema, `kickableTasks`, `pollTasks`

`tasks: [{ taskName, description (≤ 255 — it is the Inngest function name), concurrency,
handler(ctx) }]`. `ctx.step.run/sleep/sendEvent`, `ctx.getState()` (the fold), `ctx.dispatchEvent`,
`ctx.notify(topic, data)` (the realtime channel), `ctx.eventData`, `ctx.identifier`. Every side
effect inside a step (the replay model). Kick from a tool or the browser with `kickPluginTask`
(only names in `kickableTasks`), from a webhook with `ctx.sendInngestEvent`, on a cadence with
`pollTasks` (5-minute granularity, minimum 5; handlers idempotent — sweeps and pushes overlap).
Live UI: `definePluginChannel` + `ctx.notify` + `usePluginRealtime` — `task-and-realtime.md`.

## 5. Server ops — `ops` + `server.ts`

`POST /api/plugins/<id>/op/<name>` `{ nodeId, args }`, platform-gated (write access, the node is
this type). For reads that must be true now and actions that need a credential; idempotent (a
tool call can be retried). `readAppState(nodeId)` is the fold; never a database read.
`server-ops-and-routes.md`.

## 6. Routes — `routes` + `server.ts`

`GET|POST /api/plugins/<id>/route/<name>?nodeId=…`, READ to reach, `ctx.canWrite` says whether
the caller may mutate, `sseStream` for streaming, 300 s budget. The UI reaches it with
`pluginRouteUrl`. A route ticks for whoever is connected; nothing outlives the request.

## 7. Webhooks — `webhooks` + `server.ts`

`POST /api/plugins/<id>/webhook/<hook>`. **Verify first** (a shared secret, `timingSafeEqual`),
validate, then **ACK and hand the work to a task** (`ctx.sendInngestEvent("<type>/<task>",
payload)`) — never do the work in the webhook (senders retry, requests time out, tasks are
durable). Every push carries an idempotency key; derive the event id from it
(`deterministicReducerId`) so a redelivery folds to one item. Fail CLOSED with no secret.

## 8. Connections — `connections` (OAuth2 / API key)

The person grants once in Account settings; the platform holds the tokens sealed and refreshes
them. The manifest names **env vars, never values**. An instance is bound to one connection
(`ctx.cloudConnectionId`); `getPluginConnectionCredentials(connectionId, pluginId)` in server
code returns `{ kind: "oauth2", accessToken }` or the API key. Never log a token, never put it
in an event, never return it from a tool. In a Forge preview connections are NOT available yet
(designed, not built) — test the op's shape with a fake credential, install to run it for real.

## 9. Files — `fileSources`, `fileProviders`

`fileSources: { workspace: "read" | "readwrite", providers: [...] }` is consent; absent = no file
access. UI: `usePluginWorkspaceFiles()`, `usePluginFileUpload()`, `useFileSources`,
`useFileSourceEntries`. Server: `pluginFiles(ctx)` → list, read (capped), resolve a `FileRef`.
Contribute a provider with `fileProviders` + `server.ts` `fileProviders: { key: impl }` (one
mount per active connection; typed errors so the UI says "not found" or "too large").

## 10. Sharing and public viewers

`publicSharing` on the schema: `policy: "never"` for private data, or a `redactState` that is the
ONLY wall between the app and the internet. A route checks `ctx.canWrite`; a `publicSafe` tool
never writes. Design for the reader who is not the owner: a viewer's face follows the same
events.

## 11. Dependencies, versions, the platform contract

A `package.json` in the app folder declares npm dependencies the platform lacks — a visible
change a person merges (the install gate refuses undeclared ones). `version` is semver, bumped
per submission. `platformApi: { min, max }` refuses install outside the contract range.

## 12. What the workbench proves, capability by capability

| capability | in the preview | how you see it |
|---|---|---|
| events, tools, UI | yes | `call_app_tool` → `read_app_state`, `look_at_app` |
| tasks + realtime | yes (in-process runtime, the store's realtime buffer) | ticks in the frame; `read_app_state` after a kick |
| ops | yes (the preview's op route over its fold) | a tool that calls the op answers |
| routes | yes (`/internal/plugin-preview/route/<id>/<name>`) | the frame's `EventSource`; `curl -N` from the box |
| webhooks | the handler runs; no external sender reaches a box | unit-test the verify + hand-off; install to receive |
| poll cadences | no scheduler in a box | unit-test the handler's idempotency; install to observe |
| connections | not yet | fake credential in tests; install |
| files | the workspace's files through the board's tab | `usePluginWorkspaceFiles` in the frame |
| cross-app tools | through the board's tab, then by grant when installed | `useWorkspaceTools` in the frame |

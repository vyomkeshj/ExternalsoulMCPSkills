# Server functions: ops and routes (`server.ts`)

An app may bring a server half. It is one module, `server.ts`, exporting `pluginServer`, written
against `esoul-sdk/server` and nothing else (the import wall refuses `@/…`, `node:*`, prisma,
next, inngest…). Declare each op and route in `plugin.json` (`"ops": ["read-state"]`,
`"routes": ["ticks"]`) — undeclared names are not mounted.

```ts
import "server-only";
import { emitPluginAppEvent, readAppState, sseStream } from "esoul-sdk/server";
import type { PluginOpContext, PluginRouteContext, PluginServerModule } from "esoul-sdk/server";
import { APP_TYPE, type StopwatchData } from "./app";

async function readState(ctx: PluginOpContext) {
  const folded = await readAppState(ctx.nodeId);            // the FOLD — the same truth the UI renders
  if (!folded) throw new Error(`no Stopwatch app ${ctx.nodeId}`);
  const s = folded.state as Partial<StopwatchData>;
  if (!Array.isArray(s.runs)) throw new Error("stopwatch did not fold (runs missing)");   // missing ≠ empty: never floor to []
  return { current: s.current ?? null, runs: s.runs };
}

async function ticks(ctx: PluginRouteContext): Promise<Response> {
  const pollMs = Math.max(250, Number(ctx.searchParams.get("pollMs") ?? 1000));
  return sseStream(async (send, signal) => {
    const openedAt = Date.now(); let n = 0;
    while (!signal.aborted && Date.now() - openedAt < 280_000) {      // inside the route's 300 s budget
      const app = await readAppState(ctx.nodeId);
      const cur = (app?.state as Partial<StopwatchData> | undefined)?.current ?? null;
      if (!cur) send("idle", { runs: 0 });
      else if (cur.status === "stopping" && ctx.canWrite) {
        await emitPluginAppEvent({ source: { pluginId: ctx.pluginId, workspaceId: ctx.workspaceId, nodeId: ctx.nodeId, applicationType: APP_TYPE }, targetNodeId: ctx.nodeId, eventName: "plugin_stopwatch_finished", eventData: { runId: cur.runId, elapsedMs: Date.now() - cur.kickedAt, taskEndedAt: Date.now() } });
        send("stopped", { runId: cur.runId });
      } else send("tick", { runId: cur.runId, elapsedMs: Date.now() - cur.kickedAt, serverNow: Date.now(), tick: ++n });
      await new Promise((r) => setTimeout(r, pollMs));
    }
  }, { signal: ctx.request.signal });
}

export const pluginServer: PluginServerModule = { ops: { "read-state": readState }, routes: { ticks } };
```

## Ops — server truth for a tool

`POST /api/plugins/<id>/op/<name>` with `{ nodeId, args }`, platform-gated. A tool calls one
with `callPluginOp(pluginId, op, nodeId, args)` from `esoul-sdk`:

```ts
[`read_stopwatch_${base}`]: {
  parameters: z.object({}), readOnly: true, publicSafe: true,
  execute: async () => {
    const { callPluginOp } = await import("esoul-sdk");
    const s = await callPluginOp<Pick<StopwatchData, "current" | "runs">>("stopwatch", "read-state", identifier.nodeId);
    return describe(s);                                       // words, from the fold — never from a cached column
  },
},
```

Why an op and not a self-fetch of `/api/v1/state`: an op runs with the platform's identity and
reads the fold; a plugin tool that fetches the public API from inside a tool needs a token it
does not have. In a Forge preview `callPluginOp` reaches the preview's own op route
(`/internal/plugin-preview/op/<id>/<op>`), answering from the preview's fold; installed, the
platform's. The host's copy refused every op in a box for a day until it learned the preview
route — if a tool in the workbench says "needs server truth… not installed", the box predates
that; reopen it.

## Routes — the backend your app brings with it

`GET|POST /api/plugins/<id>/route/<name>?nodeId=…` — mounted on install, READ access to reach,
`ctx.canWrite` says whether the caller may mutate (a public viewer cannot; a route must check
before it emits). Streaming via `sseStream(async (send, signal) => …, { signal })`: `send(event,
data)` writes one SSE frame; stop when `signal.aborted`; stay inside the 300 s budget and let
the client reconnect. The UI opens it with `pluginRouteUrl(pluginId, routeName, { nodeId })` —
in a preview that is `/internal/plugin-preview/route/<id>/<name>` — and an `EventSource`:

```tsx
const es = new EventSource(pluginRouteUrl("stopwatch", "ticks", { nodeId, pollMs: 1000 }));
for (const t of ["tick", "stopped", "idle"]) es.addEventListener(t, (e) => setMsgs((m) => [...m.slice(-200), { topic: t, data: JSON.parse((e as MessageEvent).data) }]));
es.onerror = () => setNotice("The ticks route is not answering — in a preview it compiles on first use; installed, reload.");
```

A route ticks **for whoever is connected** and nothing outlives the request — if the run must
finish when nobody is looking, that is a task's job. The route may still be the one that finishes
a run started FOR the route (a writer only) — say so on the run.

## `emitPluginAppEvent` — a server-origin event, through the full pipeline

Append → fold → realtime invalidation → the trigger matcher: identical to a tap, attributed to
the app. Use it from routes, webhooks and ops that mutate; use `ctx.dispatchEvent` inside tasks.
Any field not named in the event's `dataCreator` is dropped on the way in — carry what you need.

## `readAppState(nodeId)`

The fold, fresh. In a task it costs a scheduler hop's worth (~3 s from the platform's function
region); in a route ~50 ms. Read it to DECIDE (is the run stopping?), never to keep time.

## What server code may import

`esoul-sdk/server`, relative files of the app, `server-only`, packages the platform already
lists in its `package.json`. A new dependency is a visible `package.json` change in the app's
directory that a person merges — the install gate refuses one the platform does not have.

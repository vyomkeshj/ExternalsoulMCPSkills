# A background task that updates the UI live

The pattern, taken from the stopwatch (`src/plugins/stopwatch`, the platform's measured
instrument): a durable task that ticks once a second on the server clock, publishes each tick on
the app's channel, watches the fold for a stop, and records the result as events.

## 1. The channel — declare what the task will say

```ts
import { definePluginChannel } from "esoul-sdk";
import { z } from "zod";

export const APP_TYPE = "plugin_stopwatch";

export const stopwatchChannel = definePluginChannel({
  applicationType: APP_TYPE,
  topics: {
    tick: { schema: z.object({ runId: z.string(), elapsedMs: z.number(), serverNow: z.number(), tick: z.number() }) },
    stopped: { schema: z.object({ runId: z.string(), elapsedMs: z.number(), taskEndedAt: z.number() }) },
  },
});
```

One channel per app INSTANCE (the platform names it `plugin:<type>:<workspace>:<node>`); topics
carry a zod schema each. Put the result on the schema as `channel: stopwatchChannel`.

## 2. The events — the truth the task writes

```ts
const startRequested = { eventName: "plugin_stopwatch_start_requested", dataCreator: (args) => envelope(..., { runId: args.runId, kickedAt: args.kickedAt ?? Date.now(), source: args.source ?? "task" }), processor: (state, e) => … };
const started  // the task records "I am ticking" — idempotent by runId
const stopRequested  // the user's Stop — an EVENT the task observes on the fold, never a kick
const finished // the task's own interval and stamps — the authoritative record
```

Rules: `dataCreator` mints ids and stamps (`nanoid`, `Date.now`) — a processor never does;
processors are idempotent by id (a retried dispatch is not a second run); a stop is an event on
the timeline that the task sees on its next fold read — never "send the task a message".

## 3. The task — two cadences, not one loop

```ts
tasks: [{
  taskName: "tick",
  description: "The clock. Records started, then ticks once a second on the server clock with a fold read in flight beside it; finishes when the fold says stopping.", // ≤ 255 chars: this IS the Inngest function name
  concurrency: { limit: 1, scope: "per-app" },
  handler: async (ctx) => {
    const runId = String(ctx.eventData.runId);
    const kickedAt = Number(ctx.eventData.kickedAt);
    let startedAt = ctx.eventData.startedAt as number | undefined;   // a continuation carries the clock
    for (let c = 0; c < CHUNKS_PER_RUN; c++) {
      const out = await ctx.step.run(`chunk-${c}`, async () => {
        let began = startedAt;
        let confirmed = began !== undefined ? false : true;          // a fresh run may tick at once
        let startedWrite: Promise<void> | null = null;
        if (began === undefined) {
          began = Date.now();
          await ctx.notify("tick", { runId, elapsedMs: 0, serverNow: began, tick: 1 });     // the first tick before the record
          startedWrite = ctx.dispatchEvent("plugin_stopwatch_started", { runId, startedAt: began, kickedAt }); // beside the ticks
        }
        const until = Date.now() + CHUNK_MS; let n = 1, lastTickAt = began, readMs: number | undefined;
        let inflight: Promise<State> | null = null, readStartedAt = 0, nextReadAt = 0;
        for (;;) {
          const now = Date.now();
          if (!inflight && now >= nextReadAt) { readStartedAt = now; inflight = ctx.getState() as Promise<State>; }
          if (confirmed && now - lastTickAt >= TICK_MS) {
            lastTickAt = now; n += 1;
            try { await ctx.notify("tick", { runId, elapsedMs: now - began, serverNow: now, tick: n }); } catch { /* -1 on the next tick; the host warned */ }
          }
          if (Date.now() >= until) { if (startedWrite) await startedWrite; return { done: "chunk", tick: n, startedAt: began }; }
          const untilTick = Math.max(0, TICK_MS - (Date.now() - lastTickAt));
          const landed = await Promise.race([
            inflight ? inflight.then((state) => ({ state })) : new Promise<{ state?: State }>((r) => setTimeout(() => r({}), Math.min(untilTick, POLL_MS))),
            new Promise<{ state?: State }>((r) => setTimeout(() => r({}), untilTick)),
          ]);
          if (landed.state) {
            readMs = Date.now() - readStartedAt; confirmed = true; inflight = null; nextReadAt = Date.now() + POLL_MS;
            const cur = landed.state.current;
            if (!cur || cur.runId !== runId) { if (startedWrite) await startedWrite; return { done: "gone", tick: n, startedAt: began }; }
            if (cur.status === "stopping") { if (startedWrite) await startedWrite; return { done: "stop", tick: n, startedAt: began, stopRequestedAt: cur.stopRequestedAt, taskEndedAt: Date.now() }; }
          }
        }
      });
      startedAt = out.startedAt;
      if (out.done === "gone") return;
      if (out.done === "stop") {
        await ctx.step.run("finish", async () => {
          const elapsedMs = out.taskEndedAt - out.startedAt;
          await ctx.notify("stopped", { runId, elapsedMs, taskEndedAt: out.taskEndedAt }).catch(() => {});
          await ctx.dispatchEvent("plugin_stopwatch_finished", { runId, elapsedMs, taskEndedAt: out.taskEndedAt, stopRequestedAt: out.stopRequestedAt, kickedAt });
        });
        return;
      }
    }
    await ctx.step.sendEvent("continue", { name: `${APP_TYPE}/tick`, data: { ...ctx.eventData, runId, startedAt, chunkFrom: CHUNKS_PER_RUN } }); // hand the clock to a fresh run
  },
}],
```

Why each line is there:
- **One step per 25-second chunk**, not one per tick: every step is a scheduler hop.
- **The read runs beside the ticks** (`Promise.race`): chained behind a ~3 s fold read the clock
  ticked once per read.
- **No tick before the run is confirmed** unless THIS chunk minted `started`: a continuation of a
  run the fold no longer holds (abandoned) must not hear a tick.
- **The `started` record is awaited before every return** — never orphaned, never in the tick's way.
- **`sendEvent("continue")`** hands the clock to a fresh function run every 96 chunks: the step
  budget is finite.

## 4. Kicking it — from a tool, from the UI

```ts
// a tool (chat, voice, agents, MCP) — in toolkitCreator
[`start_stopwatch_${base}`]: {
  parameters: z.object({}),
  execute: async () => {
    const runId = nanoid(); const kickedAt = Date.now();
    const kicked = await kickPluginTask({ applicationType: APP_TYPE, taskName: "tick", identifier, data: { runId, kickedAt } });
    if (!kicked.ok) return `The clock was refused (HTTP ${kicked.status}).`;
    eventCallback(startRequested.dataCreator({ ...idArgs, runId, kickedAt }));   // record the run only after the kick was accepted
    return `Started run ${runId}; the durable clock is ticking.`;
  },
},
```

List the task in `plugin.json` `kickableTasks`. The browser calls the same `kickPluginTask`; in a
preview it reaches the box's in-process runtime; installed, the platform's send-event route. A
stop is `eventCallback(stopRequested.dataCreator(...))` — an event, which the task sees.

## 5. Hearing it — the UI

```tsx
const live = usePluginRealtime<TickMsg | StoppedMsg>({
  channel: stopwatchChannel, workspaceId, nodeId, topics: stopwatchChannel.topicNames,
  enabled: !!current,                      // subscribe only while a run exists
});
// fold every new message into a pure face; the face never reads a clock
useEffect(() => { for (const m of (live.data ?? []).slice(seen.current)) setFace((f) => foldClockMessage(f, m)); seen.current = live.data?.length ?? 0; }, [live.data]);
const display = shownMs(face, current, lastFinishedMs);
```

`shownMs`: the fold's recorded time for the current run (a stop that folded) → the last tick heard,
for the current run OR a run this tab has not learned yet (a viewer hears the tick before the
fold's invalidation lands) → a known run with no tick yet shows 0 → the final time heard → the
last finished run. Pin it with a test that the module never calls `Date.now`, `performance.now`
or a timer.

## 6. What it measures on production (2026-09-10/11, 5 runs of 10 s)

| | Inngest task | server route (docs/06) |
|---|---|---|
| kick → first tick | 1–14.5 s (the hop itself) | 0.15 s |
| cadence, worst gap | 1000 ms, 1002 ms | 1050 ms, 1900 ms |
| tick fired late | 0 ms | — |
| fold read | ~3.4 s from the task's region | 50 ms |
| stop seen | 1.5–7.6 s (one read) | 0.3 s |

So: the task is the durable witness and the route is the live view; ship both when the
difference matters and record which drove each run. In a Forge preview all of this runs
in-process (reads ~0 ms) — the numbers you see there are not the production numbers.

## 7. Traps, each paid for once

- A `void ctx.notify(...)` inside a step never leaves the task on production.
- A task description over 255 characters fails the platform's whole function sync silently.
- Interpolating the face between ticks hides a dead publisher for a day.
- A viewer tab that requires its fold to know the run before showing a tick shows nothing while
  tools drive the clock.
- Waiting for the first read before the first tick loses 3 of 5 short runs on the Inngest arm.

---
name: forge-realtime-apps
description: Build a COMPLETE ExternalSoul app in the user's Forge over MCP/SDK and get it installed — every capability an app can declare (events and tools; background tasks on Inngest that update the UI live over the realtime channel; server ops and streaming routes; webhooks; poll cadences; OAuth/API-key connections; workspace files and file providers; cross-app tool grants; public sharing), how to test each one in the workbench before install, and the two ways an app reaches a platform (its own GitHub repo → Settings → Apps by link, or a pull request). The companion to forge-app-builder; read this one for anything beyond a plain UI app.
---

# Apps with live background tasks and server functions, built in the Forge

You are writing a real ExternalSoul app: state as events on the shared timeline, tools every
surface calls, a UI in the user's frame — plus two things this skill exists for:

1. **A background task** that runs on the platform's durable executor (Inngest), mutates the app
   through the same events a tap would, and **tells the mounted UI live** over the app's realtime
   channel.
2. **Server functions**: **ops** (a tool that needs server truth calls one) and **routes** (an
   endpoint the app brings with it, plain or streaming).

The Forge gives you a workbench where all of that runs before the app is installed anywhere:
tasks, ops, routes and realtime answer inside the preview; you drive them with tools and read
the fold. The references are the contract — read the ones your app needs before writing a line:

| Reference | Read it when |
|---|---|
| `reference/getting-started.md` | the person is starting from zero (account, GitHub, a Forge, MCP), or you need the two install paths side by side |
| `reference/capabilities.md` | choosing what the app declares: every manifest field with the code behind it — events, tools, tasks, poll cadences, ops, routes, webhooks, connections, files, cross-app grants, sharing |
| `reference/task-and-realtime.md` | a background task must update the UI live (the two-cadence pattern, the channel, the face rule, the measured numbers, the traps) |
| `reference/server-ops-and-routes.md` | a tool needs server truth, or the app needs an endpoint (plain or streaming) |
| `reference/test-and-ship.md` | testing every arm in the workbench, then pushing to the app's own repo and installing it from a link (updates, uninstall, the trust line) |

If you have the `forge-app-builder` skill, its loop (open → write → preview → look → drive →
test → check → ship) is the base; this skill is what changes when the app has a backend.

## The shape, in one screen

```
plugin.json     id, applicationType (plugin_<snake>), entry, icon,
                kickableTasks: ["tick"], ops: ["read-state"], routes: ["ticks"]
app.tsx         events (dataCreator mints ids; processors are pure and idempotent),
                a channel (definePluginChannel), tasks: [{ taskName, handler }],
                toolkitCreator: tools that kick the task / call an op / dispatch events
ui/<id>-ui.tsx  usePluginRealtime({ channel, topics, enabled }) → the live nudge;
                the fold (props.state) is the truth the nudge points at
server.ts       pluginServer = { ops: { "read-state" }, routes: { ticks } }
<id>.test.ts    reducers idempotent; the task handler with a fake ctx; a slow-read case
```

## The six rules that are not negotiable

1. **Events are the truth; realtime is a nudge.** A task changes the app only through
   `ctx.dispatchEvent(...)`. `ctx.notify(topic, data)` tells mounted UIs something happened; a
   refresh sees only the timeline. Never put state in a notify that is not also on the timeline
   (or derivable from it).
2. **Everything a task does with the world lives inside `ctx.step.run`.** The executor replays
   your handler from the top after every step; anything outside a step fires N+1 times.
   `nanoid()`/`Date.now()` outside a step differ per replay — mint inside.
3. **Inside a step, never `void` a promise that must land.** A fire-and-forget `notify` or
   `fetch` inside a step is orphaned when the step returns — on production not one tick reached
   the channel while the awaited `stopped` always did. `await` it (the platform time-boxes a
   publish to 1 s, so a slow broker costs one tick, never the step).
4. **A task's `description` is its Inngest function name: ≤ 255 characters.** Longer fails the
   whole platform's function sync silently (the site deploys, the functions stay old). The
   platform now clips it, and the install gate refuses it — keep it short anyway.
5. **Tasks are seconds, routes are milliseconds.** Every step is a scheduler round trip (kick →
   task 2–15 s; a fold read inside a task ~3 s). A per-second clock must not wait on the fold:
   tick on the server clock with a read in flight beside it; use a route for a live view; make
   the task the durable witness. Measure elapsed on ONE clock (the presser's), never across hops.
6. **A UI moves only when a tick arrives.** No `requestAnimationFrame` sweep, no `Date.now() −
   startedAt`, not even for the tab that pressed Start. A stalled task then shows as a stalled
   hand, which is what an instrument owes its reader — and it is how a missing publish gets
   found. A VIEWER tab follows ticks for a run its fold has not learned yet.

## The loop for these apps (board tools, `<verb>_<board>`)

1. `open_workbench {pluginId, name, description, icon}` — the box, warm in seconds after the
   first app. The frame's greeting names what the box can do: `tasks, ops, routes, realtime`.
   If it does not, the workbench predates them — `close_workbench` then open again.
2. Write `app.tsx` (events, channel, task, tools), `server.ts` (ops, routes),
   `ui/<id>-ui.tsx` (the hook + the fold), `plugin.json` (`kickableTasks`, `ops`, `routes`),
   `<id>.test.ts`. Every write answers with the preview's health — fix `DOWN` first.
3. `preview_app` → `look_at_app`. Then **drive the backend from the shell of tools**:
   - `call_app_tool {tool:"start_<x>"}` — the tool calls `kickPluginTask` → the preview's task
     runtime runs your handler in-process; its `dispatchEvent`s land in the frame; its `notify`s
     reach `usePluginRealtime` (the preview polls its store's realtime buffer).
   - `read_app_state` — the fold, with or without a tab open.
   - `call_app_tool {tool:"read_<x>"}` — a tool that calls an op; the preview's op route answers
     from its own fold.
   - a route: the frame opens `pluginRouteUrl(id, name, {nodeId})` — in a preview it is
     `/internal/plugin-preview/route/<id>/<name>`; `curl` it from the box if you need to see it.
4. `test_app` (the app's tests, seconds) → `check_app` (the wall, the sync, tests, types).
5. Ship: `ship_app` for a pull request into the platform, **or** the app's own repository: the
   board's REPOSITORY row creates or links a GitHub repo and **Open pull request** proposes the
   app directory from the branch `forge/<app>` (an open PR is updated; nothing is forced; the
   first commit to an empty repo is a PR too). It reaches `main` when the person merges it. The owner then installs it from Settings → Apps by
   link, checks for updates when they want, uninstalls cleanly — `reference/test-and-ship.md`.

## What the preview does not give — install for these

Durability across a process death, retries, the scheduler's `if` on `waitForEvent`, real auth
on routes (a preview is single-tenant), the platform's connections. The numbers in the preview
are the box's (fold reads ~0 ms); the production numbers are in `reference/task-and-realtime.md`.

## Honest reporting

- "the task ticks" means you read a tick in `read_app_state` or heard one through a tool result;
  "the UI updates live" means the user saw it or `look_at_app` did.
- A refused op in the workbench names the reason; relay it, do not work around it.
- A route that "did not answer" in a preview is usually compiling on first use (up to a minute);
  say so and retry once.

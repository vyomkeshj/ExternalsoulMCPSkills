# The 2D set pieces — what to put on screen

> Use when choosing WHAT to put on screen for a 2D maths beat — the classic explainer set pieces: the linear-map grid, graph stories, Riemann refinement, moving points with trails, counters, camera zooms, callouts. Each is a verified no-LaTeX recipe for manim CE in the sandbox. This is the shot vocabulary under SKILL.md; HOW things move is `reference/manim-motion-craft.md`; real 3D is reference/manim-3d-scenes.md. Colors below are placeholders — use your film's theme palette (drip or paper).

**LaTeX note (measured 2026-08-10).** Where this file says LaTeX is
unavailable and `MathTex`/`Tex`/`DecimalNumber`/`get_graph_label` crash, read that as
*until you install it*. The sandbox is Debian 12 with passwordless sudo:
`sudo apt-get install -y --no-install-recommends texlive-latex-base texlive-latex-extra dvisvgm`
takes ~56s and 255MB, after which `MathTex` renders (verified: `manim -ql` exit 0, real mp4).
Every no-LaTeX idiom below remains correct if you skip that install — and remains the right choice
for captions, which want Pango `Text` regardless.

PICK THE SHOT BY THE STORY BEAT
- "this transformation ACTS on space" (matrices, eigenvectors, complex multiplication) → THE LINEAR MAP.
- "this quantity ACCUMULATES or refines" (integrals, sums, limits) → RIEMANN REFINEMENT / AREA REVEAL.
- "this function CHANGES with a parameter" (families, derivatives, fits) → GRAPH STORY on a ValueTracker.
- "this thing MOVES through a space" (trajectories, iteration, gradient descent) → MOVING POINT with a trail.
- "how much / how many" (probability, samples, convergence) → COUNTER + BAR.
- "look closer / step back" (detail vs context) → CAMERA ZOOM.
- "THIS part right here" (naming a piece of a diagram) → CALLOUT.
A mystery opening = zoom into the odd detail FIRST, explain second. The refinement and limit shots ARE the aha — spend run_time there, not on entrances.

THE LINEAR MAP (verified) — matrices act on space
  static = NumberPlane(x_range=[-8,8], y_range=[-5,5],
      background_line_style={"stroke_color": GREY, "stroke_width": 1, "stroke_opacity": 0.3},
      axis_config={"stroke_color": GREY, "stroke_opacity": 0.4})
  live = NumberPlane(x_range=[-8,8], y_range=[-5,5],
      background_line_style={"stroke_color": INK, "stroke_width": 1.4, "stroke_opacity": 0.7})
  bi = Arrow(ORIGIN, RIGHT, buff=0, color=HOT, stroke_width=6)
  bj = Arrow(ORIGIN, UP, buff=0, color=GRN, stroke_width=6)
  self.add(static, live, bi, bj)
  self.play(live.animate.apply_matrix(M), bi.animate.apply_matrix(M),
            bj.animate.apply_matrix(M), run_time=3)
The FAINT STATIC COPY underneath is what makes the motion legible — the eye needs the before while watching the after. Basis vectors ride the same matrix; their landing spots ARE the matrix columns (say so in narration). Determinant beat: add a unit Square with fill and let it shear — its area is det. Eigenvector beat: draw the eigen-line first; the map leaves it in place while everything else swings. Ranges wider than the frame ([-8,8]) keep corners covered after the map. NONLINEAR maps: live.prepare_for_nonlinear_transform() first (subdivides lines so they can bend), then live.animate.apply_function(f).

THE GRAPH STORY (verified)
  ax = Axes(x_range=[-3,3,1], y_range=[-1,4,1], x_length=8, y_length=5,
            axis_config={"color": GREY, "include_tip": True, "tip_width": 0.18, "tip_height": 0.18})
  f = ax.plot(lambda x: 0.5*x*x, color=INK, stroke_width=4)
  self.play(Create(ax, lag_ratio=0.05)); self.play(Create(f))
Labels: ax.get_graph_label(f, label=Text("f"), x_val=2) — the DEFAULT label is MathTex and CRASHES; ALWAYS pass a Text. Free placement: Text(...).next_to(ax.input_to_graph_point(x, f), UR, buff=0.2).
Morph f→g by Transform(f, g2) on the SAME axes — the held frame is what shows "same question, different function". Area: self.play(FadeIn(ax.get_area(f, x_range=[a,b], color=INK, opacity=0.25))). Parameter families: k = ValueTracker(1); curve = always_redraw(lambda: ax.plot(lambda x: k.get_value()*np.sin(x), color=INK)); self.play(k.animate.set_value(3)) — cheap 2D redraw, sanctioned.

RIEMANN REFINEMENT (verified) — the integral aha
  rects = ax.get_riemann_rectangles(f, x_range=[0,2], dx=0.5,
      color=[INK, HOT], fill_opacity=0.5, stroke_width=1)
  fine  = ax.get_riemann_rectangles(f, x_range=[0,2], dx=0.125,
      color=[INK, HOT], fill_opacity=0.5, stroke_width=0.5)
  self.play(LaggedStartMap(FadeIn, rects, lag_ratio=0.1))
  self.play(Transform(rects, fine), run_time=1.5)
Two refinement steps read as a limit; narrate over the Transform, then swap in the smooth get_area as the destination. Thin the stroke_width as dx shrinks or the fine pass reads black.

THE MOVING POINT (verified)
  dot = Dot(color=HOT)
  trail = TracedPath(dot.get_center, stroke_color=HOT, stroke_width=3, dissipating_time=0.6)
  self.add(trail, dot)
  self.play(MoveAlongPath(dot, path), run_time=2.5, rate_func=rate_functions.ease_in_out_sine)
path is any VMobject — a plotted curve's .copy(), a ParametricFunction. dissipating_time = comet tail; omit it for pen ink (the whole trace stays — right for "the set of all points visited"). Iteration and descent beats: precompute the points (numpy/scipy), build a smooth path with VMobject().set_points_smoothly([...]), and MoveAlongPath over it — never simulate inside an updater. The dot is the drip skill's character slot: give IT the eyes.

COUNTER + BAR (verified — DecimalNumber and Integer CRASH without LaTeX)
  t = ValueTracker(0)
  num = always_redraw(lambda: Text(f"{t.get_value():.0f}", font_size=64).move_to(UP*1.5))
  bar = always_redraw(lambda: Rectangle(width=max(t.get_value()*0.06, 0.01), height=0.6,
        fill_opacity=0.8, stroke_width=0).move_to(DOWN*0.5 + RIGHT*t.get_value()*0.03))
  self.play(t.animate.set_value(100), run_time=2.5, rate_func=rate_functions.ease_out_expo)
ease_out_expo makes the count LAND. Full idiom + the emphasize-the-final-value handoff: motion-craft skill.

THE CAMERA ZOOM (verified) — the scene class must be MovingCameraScene
  self.camera.frame.save_state()
  self.play(self.camera.frame.animate.scale(0.35).move_to(spot),
            run_time=1.6, rate_func=rate_functions.ease_in_out_cubic)
  ...
  self.play(Restore(self.camera.frame), run_time=1.4)
Follow a moving dot: self.camera.frame.add_updater(lambda m: m.move_to(dot.get_center())) — and clear_updaters() BEFORE the Restore (verified: a live follow updater fights it). A zoom is a beat: lean in on the odd detail for the mystery opening, Restore for the reveal-in-context. Cannot be mixed with ThreeDScene — 2D zooms and 3D orbits live in different scene classes.

THE CALLOUT (verified constraint)
  brace = Brace(target, DOWN)
  label = Text("width", font_size=24).next_to(brace, DOWN, buff=0.1)
Brace itself is a pure path and safe; brace.get_text() typesets LaTeX and CRASHES — always place your own Text. Alternatives: SurroundingRectangle(m) for boxing, CurvedArrow(a.get_bottom(), b.get_bottom()) for "this becomes that".

STAGE MANAGEMENT ACROSS BEATS
- Progressive disclosure: never show the finished diagram at once — build it element by element as the narration introduces each, in the order the narration names them.
- Color is meaning, film-wide: fix the mapping once (e.g. input INK, result HOT, success GRN) and never reuse a colour for a second meaning — the drip skill's rule, and it holds on paper too.
- Position is meaning: left→right = cause→effect and time; top→bottom = derivation; center = the current hero, ONE per frame.
- SCALE is meaning too, and it is the one that silently ships wrong. manim's frame is only
  ~14.2 units wide, so the 1:1 data-to-manim default in these recipes (Arrow(ORIGIN, RIGHT),
  NumberPlane(x_range=[-8,8])) yields a diagram at ~30% of frame width — geometrically
  perfect and far too small. Choose an explicit unit scale per scene (SKILL.md step 3's
  Stage helper): live area 45-65% of frame width, a unit basis vector >=10%.
- Between beats: FadeOut(done_stuff, shift=DOWN*0.3), but let the axes or plane PERSIST as the stable stage — re-creating the stage every beat reads as a reset, and the held stage is what makes two beats feel like one investigation.
- The end card is the emotional close: restate the one claim that was earned, and hold it longer than feels natural — the viewer is writing it down.

FRAME DISCIPLINE — the camera is 14.2 × 8.0 units and it CROPS, it never shrinks (two shipped-defect classes)
- SAFE AREA: keep every mobject inside |x| ≤ 6.5, |y| ≤ 3.5 (~0.6-unit margin). The frame clips silently — a label nudged past the top edge renders half-missing in the mp4 and errors nowhere.
- Axes must leave room for their LABELS: x_length ≤ 11, y_length ≤ 6, and place axis labels INTO the frame, never off the tip — x-label next_to(ax.x_axis.get_end(), DOWN, buff=0.2), y-label next_to(ax.y_axis.get_end(), RIGHT, buff=0.2). get_x_axis_label's default sits AT the tip: on near-full-frame axes that is already outside the safe area (a half-clipped "x₂" shipped exactly this way).
- Guard every composed group before animating:
    def fit_frame(m, w=13.0, h=7.0):
        if m.width > w: m.scale_to_fit_width(w)
        if m.height > h: m.scale_to_fit_height(h)
        return m
  and in a -ql draft, one assert per hero (m.get_top()[1] <= 3.6) costs nothing; a clipped final costs a render cycle.
- BANDS — the screen is three horizontal bands: TITLE (top ~1.2 units), FIELD (the middle), CAPTION (bottom ~1.0, the hud slot). ONE occupant per band at a time, film-wide. A formula appearing mid-beat lives in the FIELD — or REPLACES the title via the swap idiom — never on top of a persisting title: title cards EXIT (FadeOut) before anything else enters the top band. Two texts sharing a band is how "MULTIPLICATION IS ROTATION" shipped with z ↦ e^{iθ}z stamped straight through it.
- PROVE the bands clear in a -ql draft — manim knows its own boxes, no pixels needed:
    def assert_hud_clear(*mobs, pad=0.15):
        from itertools import combinations
        for a, b in combinations(mobs, 2):
            if (a.get_right()[0] + pad > b.get_left()[0] and b.get_right()[0] + pad > a.get_left()[0]
                and a.get_top()[1] + pad > b.get_bottom()[1] and b.get_top()[1] + pad > a.get_bottom()[1]):
                raise AssertionError(f"HUD overlap: {a} vs {b}")
  Call it on (title, formula, caption) after composing each beat's statics. One assert per beat costs nothing; stamped-through text costs a re-render and shipped twice before this rule.

---
name: math-explainer-video
description: Make a narrated animated explainer VIDEO that teaches a technical or mathematical idea — a concept, formula, theorem, proof, distribution or method — with real manim animation of the maths itself, formula cards, a voiceover synced to the shots, and one mp4 delivered. Dark 3blue1brown look by default; handles a requested length ("a 5 minute video"). Triggers on "make a math explainer video about IID datasets", "animate the central limit theorem", "explain eigenvalues in a 3 minute video with narration", "video explaining the Hessian". Requires an ExternalSoul MCP connection (list_workspaces / get_app_tools / call_app_tool / create_app) to a workspace you own that is exposed with 'tools' access; it creates the sandbox, video editor and canvas it needs. NOT for animating a story or an essay, and NOT for a slide deck.
---

# Explain a technical idea as a narrated animated video

You are driving an ExternalSoul workspace over MCP. Everything you do to an app is
`call_app_tool(workspace_id, app_id, tool_name, arguments)`.

## WHAT THIS COSTS

Manim rendering is FREE and deterministic. Narration is pennies. Do NOT use a video model
(`generate_video`) for maths: it bills ~$0.40/second and cannot draw a defined motion. **If the
motion can be written as a function, write the function.**

## THE COMPANION FILES — read them, they are the craft

Four vocabularies ship next to this file. Read a file when its beat comes up; do not try to
recall its contents.

- `reference/drip-style.md` — the DEFAULT look: dark glow, height-coloured surfaces, an animated
  character. Read it at step 1 and follow it instead of step 2.
- `reference/manim-motion-craft.md` — HOW motion feels: easing, stagger, entrances, emphasis,
  transform choice, updaters, the no-LaTeX counter.
- `reference/manim-2d-set-pieces.md` — the classic 2D shots: linear-map grid, Riemann refinement,
  graph stories, moving points, camera zooms, callouts.
- `reference/manim-3d-scenes.md` — real 3D: surfaces, solids, trajectories, orbiting cameras, ML
  architecture shots.
- `reference/sandbox-mechanics.md` — how the code sandbox actually behaves: the 60-second rule,
  detached rendering, the restart lifecycle, getting files in and out, seeing your own output.

## STEP 0 — find the apps you can actually drive

`list_workspaces` for the workspace id, then read its apps. You need three: a **code sandbox**
(`e2b_sandbox`) for manim, a **video editor** (`video_editor`) for assembly, and — on the LIGHT
theme only — a **drawing canvas** (`tldraw_canvas`) for typeset formula cards.

`get_app_tools` on each to learn its EXACT per-app tool names. They are suffixed with the app's
base name (`run_code_<base>`, `draw_on_page_<base>`, `add_clip_<base>`). Never guess a tool name;
read it.

**If an app type is missing, create it — but offer it in the same call:**

```
create_app({ workspace_id, application_type: "e2b_sandbox", name: "...", offer: true })
```

`offer: true` is load-bearing and easy to miss. Without it the app IS created but stays invisible
over MCP ("Created. It is NOT offered over MCP yet") — `list_workspaces` won't show it and
`call_app_tool` refuses it as `not_visible`. If you already created one without the flag, do NOT
create a second: creation is idempotent on (workspace, type, name), so re-issue the SAME call with
`offer: true`.

Then `get_app_tools` on it and start calling. **The new app's tools are callable immediately, in
this same session** — `call_app_tool` is one static tool that takes `app_id` as an argument, so
nothing in the MCP tool list changes and there is nothing to refresh. (Guidance written for
ExternalSoul's in-app chat tells you to call `resume_session('vercel')` after adding an app. That
hazard does not exist on this surface; ignore it.)

Two refusals mean something you must act on rather than retry:

- *"exposed read-only"* / `no_tools_access` — the workspace is exposed without `tools` access.
  Reads work, tool calls never will. You own this storefront: flip that workspace to `tools`
  access in its settings, or build in one that already has it. Retrying will not help.
- `policy_never` — that app type opts out of public sharing entirely (slideshow, contacts). It is
  unreachable over MCP however it is configured. Pick a different app or do that part in-app.

**You are the owner of this storefront** — `create_app` is owner-only and you have it, so a
missing app is never a reason to stop or to repurpose an unrelated app. Create it and carry on.

If your connection has NO `call_app_tool` at all — only the SDK-style tools (`read_app_state`,
`dispatch_event`, `spreadsheet_*`) — then this pipeline is not reachable from here. Say that
plainly instead of improvising; the sandbox and video editor cannot be driven by raw events.

A video editor that already holds a timeline: clear it clip by clip with `remove_clip` before
building. A leftover clip is nearly invisible and silently ends up in the export.

## STEP 1 — plan the FILM: length, arc, beats, theme

**LENGTH.** If the user named one, plan to it: beats ≈ minutes × 5 (a beat runs 10–14s), total
narration ≈ 2.4 words × total seconds, budgeted per beat BEFORE writing any line. No stated
length → 2–3 minutes (10–14 beats).

**ARC.** A film is a story, not a list of facts. Open with the question or the tension (what
breaks or surprises without this idea), build the intuition IN MOTION before any formal card, end
with the payoff — the moment the idea pays rent. Write the beat plan as that arc: one sentence
per beat describing what is SEEN.

**MOTION FLOOR.** Animations carry the story; cards carry formulas. Alternate them, keep cards
well under half the runtime, and treat a beat whose animation is "fade in and hold" as a card in
costume — give it real motion (a camera move counts).

**THEME — DARK DRIP is the default.** Read `reference/drip-style.md` and follow it INSTEAD of
step 2: glow on near-black, height-coloured surfaces, an animated character. That is the
"beautiful" / "cinematic" / "3blue1brown" look, and it ships unless the maths forbids it.

Heavy formulas no longer force the theme. The old rule — "a nested integral or a matrix needs
LaTeX, and LaTeX typesets only on a light tldraw card, so that film must go light" — rested on
LaTeX being unavailable in the sandbox. It is 56 seconds away (step 3), and `MathTex` produces
ordinary mobjects you can `set_color` to your palette and place on a dark background like anything
else. So a dark drip film CAN carry a nested integral natively.

**And when a formula resists Unicode, change the MATHS before you change the theme.** This is the
move, not a consolation prize: a Fourier film looks light-theme because `e^{-2πixξ}` has no honest
Unicode — but writing the same idea as `cₖ = ⟨f, eₖ⟩` over sines and cosines keeps it dark AND is
more intuitive for the audience. Reformulating usually improves the film. `scripts/glyph_check.py`
tells you in ten seconds whether the premise is even true.

Go LIGHT PAPER (step 2: LaTeX cards on white) when you want that aesthetic, or when the film is
mostly formula cards and the canvas's measured-box layout is genuinely easier than composing them
in manim. Not merely because the maths is dense.

Say which theme you picked. **Never mix — a film has ONE theme.**

## STEP 2 — draw the formula cards (LIGHT PAPER theme only)

One PAGE per card via `add_drawing_page`, then `draw_on_page`. Every card starts with a frame
rect as the FIRST shape in the array:

```json
{"kind": "rect", "x": 0, "y": 0, "w": 1232, "h": 672, "color": "white", "fill": "semi"}
```

That size is load-bearing. The snapshot pads 24 canvas px per side then supersamples 2×, so
1232×672 renders to exactly 2560×1440 = 16:9. **Any other size gets BLACK BARS** from the
export's pad filter.

Lay out inside it at left margin x=140: a small grey ALLCAPS kicker, the `{"kind":"latex"}`
formula, an optional grey note beneath.

`fill:"semi"` is opaque PAPER white and HIDES what is behind it; `fill:"solid"` is the pale tint.
Backwards makes a shaded region read as empty.

`draw_on_page` returns each equation's MEASURED box and an overlap report. Read it; if two
collide, move one and redraw with `clear:true`.

Then `snapshot_drawing` each page with `saveAs` to get a workspace fileId. **Schema-valid is not
renders-correctly** — but on this surface you cannot see the snapshot (step 5). The measured boxes
and the overlap report ARE your check: assert every box sits inside the 1232×672 frame with its
margins, and treat any reported overlap as a defect. Name the card files in your reply so the user
can glance at them.

## STEP 3 — the manim scenes

`run_code` in the sandbox. First check the environment: `import manim, av`, and
`shutil.which('latex')`.

- The sandbox comes up BARE — manim is NOT preinstalled. `pip install manim av pillow scipy`; the
  manim wheels land in ~26s.
- **LaTeX is not installed either, but it is 56 seconds away.** The box is Debian 12 with
  passwordless sudo (verified 2026-08-10):

  ```bash
  sudo apt-get install -y --no-install-recommends texlive-latex-base texlive-latex-extra dvisvgm
  ```

  ~56s, 255MB, and `MathTex` then renders — measured end to end, `manim -ql` exit 0 with a real
  mp4 out. Fire it DETACHED alongside the pip install at the very start, before you write a single
  scene; both together are ~82s against a job that will spend 10–30 minutes rendering.

  Older guidance (including parts of the reference files) says LaTeX is simply unavailable. That
  described the cold image, not a limit. If you skip the install the no-LaTeX idioms still hold —
  `Text` (Pango) captions, formulas on cards, and the `DecimalNumber`/`get_graph_label` crashes
  the reference files warn about are all real WITHOUT LaTeX.
- Set `config.background_color` to your theme's background — `"#F9F9FB"` paper, or the drip
  skill's `"#0B0E14"`. Manim defaults to pure black, which matches neither.

**Four rules that each cost a full render cycle to learn:**

1. **NEVER `always_redraw` a Surface.** Rebuilding a 144-quad mesh across ~480 frames outruns the
   sandbox lifetime. Use `Transform(surf, mk(a2,b2))` between two prebuilt meshes of equal
   resolution — same picture, ~10× faster. 2D `Axes` + `axes.plot()` is cheap: there
   `always_redraw` with a `ValueTracker` is fine and is the natural way to animate a parameter.
2. **Captions must be registered with `add_fixed_in_frame_mobjects`, and RE-REGISTERED after any
   `.become()`** — fixed-in-frame belongs to the individual glyph submobjects, so `.become()`
   silently drops it and half a sentence orbits with the camera. Never build a caption inside the
   animation call, and never `always_redraw` one.
3. **`checkerboard_colors=False`, not `None`** (None throws).
4. **Camera azimuth is load-bearing** for saddle-like surfaces: sighting along a principal
   direction of `z = x² − y²` collapses it to a pinched bowtie. About −28° keeps both arms open;
   −52° does not.

START FROM THIS SKELETON (light theme; the drip file has its own). It obeys all four rules;
deviate only with a reason.

```python
from manim import *
import numpy as np
PAPER, INK, HOT, GREY, DARK = "#F9F9FB", "#3A57D8", "#E03131", "#7C8794", "#1D1D1F"
config.background_color = PAPER

def hud(txt, size=32, color=DARK):
    return Text(txt, font_size=size, color=color).to_edge(DOWN, buff=0.5)

def swap(scene, lbl, txt, **kw):
    # Re-word IN PLACE, and RE-REGISTER: .become() swaps the glyph
    # submobjects that carried the fixed-in-frame exemption.
    scene.play(lbl.animate.set_opacity(0.0), run_time=0.25)
    lbl.become(hud(txt, **kw)); lbl.set_opacity(0.0)
    scene.add_fixed_in_frame_mobjects(lbl)
    scene.play(lbl.animate.set_opacity(1.0), run_time=0.25)
    return lbl

def mk(a, b, R=1.9, ZS=0.38, RES=12):        # z = ZS*(a x^2 + b y^2), wireframe
    return Surface(lambda u, v: np.array([u, v, ZS*(a*u*u + b*v*v)]),
                   u_range=[-R, R], v_range=[-R, R], resolution=(RES, RES),
                   fill_opacity=0.0, stroke_width=1.9, stroke_color=INK,
                   checkerboard_colors=False)

class Demo(ThreeDScene):
    def construct(self):
        self.set_camera_orientation(phi=62*DEGREES, theta=-28*DEGREES, zoom=1.25)
        surf = mk(1, 1); self.add(surf, Dot3D(ORIGIN, radius=0.09, color=HOT))
        lbl = hud("both curvatures positive")
        self.add_fixed_in_frame_mobjects(lbl)          # register ONCE, here
        self.wait(1.2)
        lbl = swap(self, lbl, "now one goes negative")  # caption announces
        self.play(Transform(surf, mk(1, -1)), run_time=3)   # NOT always_redraw
        self.wait(1.1)
```

**FILL THE FRAME — the defect no correctness check catches.** A diagram can be geometrically
perfect, unclipped, correctly coloured, and still *wrong*: 31% of frame width, unit vectors at 7%,
two-thirds empty background. Every automated check passes; the viewer sees a postage stamp.

The cause is a default, not carelessness: `Arrow(ORIGIN, RIGHT)` and `NumberPlane(x_range=[-8,8])`
put one data unit on one manim unit, and manim's frame is only ~14.2 units wide. So build a stage
with an EXPLICIT scale instead of inheriting 1:1 —

```python
class Stage:                       # data space -> manim space, scale chosen ONCE
    def __init__(self, unit=2.6, origin=ORIGIN): self.u, self.o = unit, origin
    def p(self, x, y): return self.o + np.array([x*self.u, y*self.u, 0])
    def vec(self, x, y, **kw): return Arrow(self.o, self.p(x, y), buff=0, **kw)

S = Stage(unit=2.6)                # a unit basis vector is now ~18% of frame width
```

Targets, both one-line measurements from a still (`scripts/verify_frames.py` reports them): live
area **45–65% of frame width**, centred within ~5%; a unit basis vector **≥10% of frame width**.
Pick the scale per scene deliberately; never let it default.

**DEEPEN BY REFERENCE.** HOW the motion feels → `reference/manim-motion-craft.md`. The classic 2D
shots → `reference/manim-2d-set-pieces.md`. Real 3D → `reference/manim-3d-scenes.md`.

**RENDER DETACHED** — a blocking manim cell dies at the client timeout and takes the subprocess
with it:

```python
subprocess.Popen(['bash','-lc','setsid nohup /home/user/r.sh > /home/user/r.log 2>&1 < /dev/null &'],
                 start_new_session=True)
```

Put `set -euo pipefail` at the top of `r.sh` (else a failed render still writes its success
marker — a green light over a red run); append each finished filename to a PROGRESS file; SKIP
anything already on disk so a relaunch RESUMES; poll with `list_files`, which reads the disk and
does not need the blocked kernel. Full long-job discipline: `reference/sandbox-mechanics.md`.

Render `-ql` first for ALL scenes and run the frame assertions from step 5 over every draft — a
FLAT verdict means that scene rendered nothing, and catching it at 480p15 costs minutes instead of
a full final pass. Only then render `-qm` (720p30) finals.

**THE SANDBOX RESTARTS AND WIPES `/home/user`**, roughly every 15–30 minutes, pip installs
included. `save_to_workspace` EVERY clip the moment it finishes — never batch the saves.

**Save `film.py` too, every time you change it.** Clips are re-derivable from the source; the
source is not re-derivable from the clips. Running a 30-minute job with the only copy of 25KB of
scene code on a VM that wipes itself is the one unforced way to lose everything. On a reset:
reinstall, re-fetch the source from the workspace, re-render only what is missing.

**Restyle with an overlay module, not a rewrite.** A second file that does `from film import *`
and redefines only the scenes that change is cheap, and it keeps the original renderable for
comparison.

## STEP 4 — assemble: FOUR calls, not fifty

`add_clip` in beat order, always with a name carrying its extension (`".png"`, `".mp4"`) —
classification keys off it. Then the whole soundtrack and all timing is exactly this sequence:

1. **`narrate_script(lines)`** — the WHOLE voiceover in ONE call, one line per beat in beat order.
   Budget each line to its beat FIRST: a fixed manim clip holds ~2.4 words × its seconds (a 6s
   clip = ~14 words); cards stretch to fit, clips do not.
2. **`export_timeline`** once, purely to MEASURE — it probes every clip and writes real durations
   back. Ignore this mp4. **Skip this call when it is redundant**: `read_timeline` first, and if
   every clip already carries `sourceDuration` (`add_clip` often sets it), go straight to sync. A
   measuring export costs minutes and buys nothing you already have.
3. **`sync_narration_to_shots`** — deterministic and free: pairs line i with beat i, HOLDS each
   card for its line, SLOWS any manim clip its line outruns (floor 0.65×; 0.8–0.9 reads
   contemplative), re-places every offset. A line even the floor cannot fit comes back with a word
   budget: rewrite THAT line, `remove_clip` its old narration, `generate_speech` the new one,
   re-run sync. Cut words, never the picture, never mid-sentence.
4. **`export_timeline`** again.

**Done means ALL of:** `warnings` is empty; the reported length matches sync's total; and if the
user asked for a length, you are within ~10% of it — short means ADD BEATS (write, render, re-run
these four calls), never stretch clips or pad holds to fill time.

**A TIMEOUT IS NOT A FAILURE, AND RETRYING COSTS MONEY.** `narrate_script` and `export_timeline`
both run long enough to return *"the connector's server isn't responding"* while completing
perfectly server-side. Narration bills per character, so a reflexive retry double-charges for the
whole script. **After ANY error on a narrate or export call, `read_timeline` before doing anything
else** — narration clips already on the track mean it worked. Treat the error as "I lost the
receipt", never as "it didn't happen".

**Sync is asymmetric — budget both directions.** It SLOWS a clip its line outruns, but in extend
mode it never SHRINKS one, so a clip longer than its line leaves dead air that nothing warns you
about. Budget each shot at `clip_seconds ≈ words / 2.4 + 1.2` when you write it, rather than
trusting sync to fix a shot that is too long.

**Never hand-compute offsets or speeds** — that arithmetic lives in `sync_narration_to_shots`, and
by hand is how narration drifted in every early film. (Narration length without a probe: TTS is a
constant 128 kbps, so mp3 seconds = bytes / 16000.)

## STEP 5 — verify WITHOUT being able to look

**Hard constraint of this surface: you cannot see your own renders.** The sandbox returns images
as base64 in `images` and CDN links in `imageUrls`, but the storefront serialises every tool
result into ONE TEXT block capped at 20,000 characters — so the base64 arrives chopped, and a
base64 string inside a text block is not vision input even when it is whole.

**Do not spend turns trying to fetch the URL, decode the base64, or hope the harness renders it.
That loop always fails.** Verification here is programmatic, plus a human look. (Running this same
pipeline in-app, images DO come back — that is the surface the "make a contact sheet and LOOK"
instruction was written for.)

**Say it out loud the first time it happens** — "images are coming back truncated, switching to the
measurement battery" — and then switch. Do not proceed on faith, and do not quietly downgrade to
guessing.

### 0. Run the battery — it is shipped, do not reinvent it

`scripts/verify_frames.py` and `scripts/glyph_check.py` are in this skill. They were written from a
real film's post-mortem; every check exists because something shipped broken without it.

Get them into the sandbox by reading the file and writing it there base64-encoded:

```python
import base64
open('/home/user/verify_frames.py','wb').write(base64.b64decode("<paste base64 of the file>"))
```

**Encode it — do not paste the source into a Python string.** A non-raw string turns `\f` into a
formfeed and `\int` into a warning, and you will debug LaTeX or manim for an hour over a file the
shell corrupted in transit. Then:

```bash
python verify_frames.py film.mp4 --marks 3,12,25,37 --theme dark   # mid-beat seconds
python verify_frames.py card01.png --card --theme dark
python glyph_check.py "⟨u,w⟩=0" "θₜ₊₁=θₜ−η∇L"     # BEFORE committing to a dark film
```

What it prints, and why each line exists:

- **FLAT** — a uniform frame: that beat rendered nothing.
- **BARS** — pure-black border strips: a card not authored at 1232×672.
- **LIVE** — live-area extent as a % of frame. **This is the one that catches the defect every
  other check passes**: a diagram that is geometrically perfect and *too small*. Target 45–65% of
  frame width, centred within ~5%. 31% wide with two-thirds empty background is a defect the
  viewer sees and no correctness check flags.
- **BANDS** — contiguous horizontal ink bands with y/x extents, plus glyph-cluster counts. Clean
  gaps prove no collision; margins prove no overflow; a cluster count that moves (`⟨u,w⟩=0` should
  be 7) means a glyph silently vanished or fell back.
- **PALETTE** — pixels near each theme hue per beat. Proves colour continuity across cuts AND
  tracks the argument: a hue should first APPEAR on the beat that earns it (red when the second
  basis vector enters, green when projection first recovers a coordinate).
- **AUDIO** — per-beat narration RMS. A silent beat is invisible to every pixel check.

**Mask on SEMANTIC colour, not on "ink".** If you write your own check, match the caption's GREY
against the grid's DIM rather than "anything non-background" — a `NumberPlane` spans the full
frame, so its grid lines sit inside the caption band and a generic ink mask cries overflow on
exactly the scenes you care most about.

### 1. Read the tools that MEASURE — they are your eyes

- `draw_on_page` returns each equation's measured box and an overlap report.
- `export_timeline` returns real probed durations and a `warnings` array.
- `sync_narration_to_shots` returns word budgets for lines that do not fit.

A warning you did not read is a defect you shipped. None of these need vision.

### 2. Assert in the sandbox and PRINT the verdict

Decode frames and check numbers, then print a table — the text comes back to you intact:

```python
import av, numpy as np
c = av.open("/home/user/f.mp4"); fps = float(c.streams.video[0].average_rate)
want = {int(t*fps): t for t in MARKS}          # MARKS = mid-point second of each beat
for i, f in enumerate(c.decode(video=0)):
    if i in want:
        a = np.asarray(f.to_image().convert("L"), dtype=np.float32)
        flat = a.std() < 3.0                    # uniform frame = dead scene / black hole
        bars = a[:, :8].mean() < 4 and a[:, -8:].mean() < 4   # pillarbox suspicion
        print(f"t={want[i]:6.1f}s  mean={a.mean():6.1f}  std={a.std():6.1f}  "
              f"{'FLAT ' if flat else 'ok   '}{'BARS' if bars else ''}")
    if i > max(want): break
c.close()
```

`std < 3` on a beat means nothing rendered there. Side columns near zero on a light-theme film
means the pad filter added bars — a card that was not authored at 1232×672.

### 3. Glyph preflight — do this BEFORE rendering any Unicode formula

The drip theme puts formulas on dark cards as Pango `Text`, and a codepoint no installed font
covers renders as an empty tofu box — silently, in the final film. Check coverage first; this is
deterministic and needs no eyes (`pip install fonttools`):

```python
from fontTools.ttLib import TTFont
import glob
CHARS = "⟨⟩∫Σ√≠≈⊥→θ∇·×∞✓ₜ₊₁₀₂ᵢⱼₖ"
have = {c: [] for c in CHARS}
for path in glob.glob("/usr/share/fonts/**/*.tt[fc]", recursive=True):
    try:
        f = TTFont(path, fontNumber=0, lazy=True)
        fam = f["name"].getDebugName(1) or path       # the name Text(font=...) takes
        for c in CHARS:
            if ord(c) in (f.getBestCmap() or {}): have[c].append(fam)
        f.close()
    except Exception:
        continue
for c in CHARS:
    print(f"{'OK  ' if have[c] else 'TOFU'} U+{ord(c):04X} {c}  "
          f"{have[c][0] if have[c] else '— NO installed font has this glyph'}")
```

Any TOFU line means that character will be a blank box on screen. Fix it by choosing notation the
fonts cover, or install a font that does and pass `font="<family>"` to `Text`. Never ship a
formula whose glyphs you have not cleared.

### 4. Hand the picture to the HUMAN

Build the contact sheet anyway, `save_to_workspace` it, and TELL the user its file name — they can
look in seconds, and one human look is worth ten blind re-renders. If something matters and you
cannot verify it, ASK rather than assert.

```python
import urllib.request, av
from PIL import Image
urllib.request.urlretrieve(URL, "/home/user/f.mp4")
c = av.open("/home/user/f.mp4"); fps = float(c.streams.video[0].average_rate)
want = sorted(int(t*fps) for t in MARKS)     # MARKS = mid-point second of each beat
grab = {}
for i, f in enumerate(c.decode(video=0)):
    if i in want: grab[i] = f.to_image()
    if len(grab) == len(want): break
c.close()
ims = [grab[i] for i in want if i in grab]
tw = 300; th = int(ims[0].size[1]*tw/ims[0].size[0]); cols = 4
sheet = Image.new("RGB", (tw*cols, th*((len(ims)+cols-1)//cols)), "white")
for n, im in enumerate(ims):
    sheet.paste(im.resize((tw, th), Image.LANCZOS), ((n % cols)*tw, (n//cols)*th))
sheet.save("/home/user/sheet.png")
```

Then `save_to_workspace` it and name it in your reply.

### 5. The one check you CAN make unaided — does the film build?

Vision is not what tells you whether the story works; your own beat plan is. Re-read it as a
stranger would: does each beat earn the next, or is it a list of facts? A beat that only restates
its card is dead weight — cut it or re-animate it. That judgement needs no pixels.

**DELIVER, don't describe:** report the file name, the duration, the theme, what you verified and
HOW (measured / asserted / not verified), and what you would change. Never claim you looked at
something you could not see. Over ~45MB, re-encode in the sandbox first (`ffmpeg -crf 28`).

## IF YOU DO USE A VIDEO MODEL ANYWAY

Only for atmosphere, never for defined motion.

- The result line must report anchor frames **greater than zero**. "0 anchor frames" means your
  keyframes never reached the model, it silently became text-to-video, and you were billed for a
  guess. Stop and fix the anchors rather than paying again.
- Durations are 4, 6 or 8 seconds only.
- Write POSITIVELY. Name the subject and state what PERSISTS ("the paper stays warm-white edge to
  edge"), never "no dark background". A negation-heavy prompt scored 0.25 on the built-in
  critique; the positive rewrite of the same shot passed. Read that critique in the tool result —
  it is your only eyes on a clip you cannot open.

## THINGS THAT GO WRONG, AND WHAT THEY MEAN

- **A tool name is not found** — you guessed it instead of reading `get_app_tools`. Names are
  per-app suffixed.
- **Export refuses with `unmeasurable_clips`** — a media URL was unreachable, or an image was
  filed as video because its name lacked ".png".
- **The film has black bars** — a card was not authored at 1232×672.
- **A caption drifts, rotates or splits mid-sentence** — not re-registered as fixed-in-frame after
  `.become()`, or built by `always_redraw`.
- **Rendering stalls with no manim process alive** — the cell was killed by the client timeout.
  Relaunch detached.
- **A success marker but no mp4** — the script lacked `set -euo pipefail`.
- **`/home/user` is empty** — the sandbox restarted. Whatever you already saved to workspace files
  survived; that is why you save as you go.
- **Narration drifts out of sync over the film** — durations were set from estimates instead of
  the measuring pass.
- **A 3D surface looks pinched or flat** — bad camera azimuth, not bad geometry. Rotate the camera
  (and since you cannot check by eye here, say so when you report it).
- **A tool result ends in `… [truncated N chars]`** — the storefront's 20,000-char cap. On
  `run_code` that is the base64 image array eating the budget, not your stdout being lost. Do not
  retry hoping for more; there is no more. See step 5.
- **You verified an export and it looked unchanged — you were looking at the PREVIOUS one.** This
  is the mirror of the re-download trap, and worse, because it silently confirms a stale cut.
  Auto-sync only fetches workspace files NOT YET copied to this sandbox, so a same-named
  replacement (`<name>-export.mp4`) never re-downloads. After re-exporting, read `lastExport.fileId`
  from the timeline and `copy_file_to_sandbox` it to a VERSIONED path (`export_v3.mp4`) before
  checking anything.
- **A narrate or export call errored** — do not retry. `read_timeline` first; it probably
  succeeded, and narration bills per character. See step 4.
- **A formula shows empty boxes in the film** — a Unicode codepoint no installed font covers.
  Preflight with the glyph check (step 5) BEFORE rendering, not after. If you installed LaTeX,
  `MathTex` sidesteps the whole class.
- **`MathTex` raises "latex error converting to dvi"** — read `media/Tex/*.log`. `! Missing $
  inserted` (or similar syntax noise) usually means the .py file on disk is CORRUPT, not that a
  package is missing: writing a scene through a non-raw Python string turns `\frac` into a
  formfeed. Print the line back from the file before blaming LaTeX. A genuinely missing package
  says `not found` in the log.
